import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const FederationPage: React.FC = () => {
  const { user: _user } = useAuth();
  const [activeTab, setActiveTab] = useState('associations');
  
  // Modal states
  const [showAddAssociationModal, setShowAddAssociationModal] = useState(false);
  const [showAddCompetitionModal, setShowAddCompetitionModal] = useState(false);
  
  // Form states
  const [newAssociation, setNewAssociation] = useState({
    name: '',
    president: '',
    contact: '',
    memberCount: 0
  });
  
  const [newCompetition, setNewCompetition] = useState({
    name: '',
    date: '',
    location: '',
    maxParticipants: 100
  });
  
  // Mock data for associations
  const [associations, setAssociations] = useState([
    {
      id: '1',
      name: 'İstanbul Süs Tavukları Derneği',
      president: 'Ahmet Yılmaz',
      memberCount: 45,
      status: 'active',
      registrationDate: '2023-01-15',
      contact: 'info@istankulub.org'
    },
    {
      id: '2',
      name: 'Ankara Süs Tavukları Derneği',
      president: 'Mehmet Kaya',
      memberCount: 32,
      status: 'active',
      registrationDate: '2023-02-20',
      contact: 'info@ankarakulub.org'
    },
    {
      id: '3',
      name: 'İzmir Süs Tavukları Derneği',
      president: 'Fatma Demir',
      memberCount: 28,
      status: 'pending',
      registrationDate: '2023-03-10',
      contact: 'info@izmirkulub.org'
    }
  ]);

  // Mock data for competitions
  const [competitions, setCompetitions] = useState([
    {
      id: '1',
      name: '2024 İstanbul Şampiyonası',
      date: '2024-06-15',
      location: 'İstanbul Fuar Merkezi',
      status: 'planned',
      registrationCount: 0,
      maxParticipants: 200
    },
    {
      id: '2',
      name: '2024 Ankara Kupası',
      date: '2024-07-20',
      location: 'Ankara Spor Salonu',
      status: 'open',
      registrationCount: 45,
      maxParticipants: 150
    },
    {
      id: '3',
      name: '2024 İzmir Yarışması',
      date: '2024-08-10',
      location: 'İzmir Fuar Alanı',
      status: 'ongoing',
      registrationCount: 78,
      maxParticipants: 100
    }
  ]);

  // Mock data for results
  const [results] = useState([
    {
      id: '1',
      competitionName: '2023 İstanbul Şampiyonası',
      date: '2023-06-15',
      totalParticipants: 156,
      categories: ['Büyük Irk', 'Orta Irk', 'Küçük Irk'],
      winners: [
        { category: 'Büyük Irk', winner: 'Ahmet Yılmaz - Sultan', score: 95 },
        { category: 'Orta Irk', winner: 'Mehmet Kaya - Altın', score: 92 },
        { category: 'Küçük Irk', winner: 'Fatma Demir - Gümüş', score: 89 }
      ]
    }
  ]);

  // Association management functions
  const handleAssociationStatusChange = (id: string, status: string) => {
    setAssociations(associations.map(assoc => 
      assoc.id === id ? { ...assoc, status } : assoc
    ));
    alert(`Dernek durumu ${status === 'active' ? 'aktif' : 'pasif'} olarak güncellendi`);
  };

  const handleEditAssociation = (id: string) => {
    const association = associations.find(a => a.id === id);
    alert(`Dernek düzenleme: ${association?.name}`);
  };

  const handleDeleteAssociation = (id: string) => {
    if (window.confirm('Bu derneği silmek istediğinizden emin misiniz?')) {
      setAssociations(associations.filter(a => a.id !== id));
      alert('Dernek başarıyla silindi');
    }
  };

  // Association management functions
  const handleAddAssociation = () => {
    if (!newAssociation.name || !newAssociation.president) {
      alert('Dernek adı ve başkan adı zorunludur!');
      return;
    }
    
    const association = {
      id: Date.now().toString(),
      name: newAssociation.name,
      president: newAssociation.president,
      memberCount: newAssociation.memberCount,
      status: 'pending',
      registrationDate: new Date().toISOString().split('T')[0],
      contact: newAssociation.contact
    };
    
    setAssociations([...associations, association]);
    setNewAssociation({ name: '', president: '', contact: '', memberCount: 0 });
    setShowAddAssociationModal(false);
    alert('Yeni dernek başarıyla eklendi!');
  };

  // Competition management functions
  const handleCreateCompetition = () => {
    if (!newCompetition.name || !newCompetition.date || !newCompetition.location) {
      alert('Yarışma adı, tarihi ve lokasyonu zorunludur!');
      return;
    }
    
    const competition = {
      id: Date.now().toString(),
      name: newCompetition.name,
      date: newCompetition.date,
      location: newCompetition.location,
      status: 'planned',
      registrationCount: 0,
      maxParticipants: newCompetition.maxParticipants
    };
    
    setCompetitions([...competitions, competition]);
    setNewCompetition({ name: '', date: '', location: '', maxParticipants: 100 });
    setShowAddCompetitionModal(false);
    alert('Yeni yarışma başarıyla oluşturuldu!');
  };

  const handleEditCompetition = (id: string) => {
    const competition = competitions.find(c => c.id === id);
    alert(`Yarışma düzenleme: ${competition?.name}`);
  };

  const handleCompetitionStatusChange = (id: string, status: string) => {
    setCompetitions(competitions.map(comp => 
      comp.id === id ? { ...comp, status } : comp
    ));
    alert(`Yarışma durumu ${status} olarak güncellendi`);
  };

  const handleDeleteCompetition = (id: string) => {
    if (window.confirm('Bu yarışmayı silmek istediğinizden emin misiniz?')) {
      setCompetitions(competitions.filter(c => c.id !== id));
      alert('Yarışma başarıyla silindi');
    }
  };

  // Results management functions
  const handlePublishResults = (id: string) => {
    alert('Sonuçlar yayınlandı!');
  };

  const handleExportResults = (id: string) => {
    alert('Sonuçlar Excel formatında dışa aktarıldı!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return '#10b981';
      case 'pending': return '#f59e0b';
      case 'inactive': return '#ef4444';
      case 'planned': return '#6b7280';
      case 'open': return '#3b82f6';
      case 'ongoing': return '#8b5cf6';
      case 'completed': return '#10b981';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Aktif';
      case 'pending': return 'Beklemede';
      case 'inactive': return 'Pasif';
      case 'planned': return 'Planlandı';
      case 'open': return 'Açık';
      case 'ongoing': return 'Devam Ediyor';
      case 'completed': return 'Tamamlandı';
      default: return status;
    }
  };

  return (
    <div className="federation-page">
      <div className="page-header">
        <h1>Federasyon Yönetim Paneli</h1>
        <p>TSHF Federasyon yönetim işlemleri</p>
      </div>

      <div className="admin-tabs">
        <button 
          className={`tab-button ${activeTab === 'associations' ? 'active' : ''}`}
          onClick={() => setActiveTab('associations')}
        >
          Dernek Yönetimi
        </button>
        <button 
          className={`tab-button ${activeTab === 'competitions' ? 'active' : ''}`}
          onClick={() => setActiveTab('competitions')}
        >
          Yarışma Yönetimi
        </button>
        <button 
          className={`tab-button ${activeTab === 'results' ? 'active' : ''}`}
          onClick={() => setActiveTab('results')}
        >
          Sonuç Yönetimi
        </button>
      </div>

      <div className="admin-content">
        {/* Associations Tab */}
        {activeTab === 'associations' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Dernek Yönetimi</h2>
              <button className="add-button" onClick={() => setShowAddAssociationModal(true)}>
                + Yeni Dernek Ekle
              </button>
            </div>

            <div className="associations-list">
              {associations.map(association => (
                <div key={association.id} className="association-item">
                  <div className="association-info">
                    <h3>{association.name}</h3>
                    <p><strong>Başkan:</strong> {association.president}</p>
                    <p><strong>Üye Sayısı:</strong> {association.memberCount}</p>
                    <p><strong>Kayıt Tarihi:</strong> {new Date(association.registrationDate).toLocaleDateString('tr-TR')}</p>
                    <p><strong>İletişim:</strong> {association.contact}</p>
                  </div>
                  <div className="association-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(association.status) }}
                    >
                      {getStatusText(association.status)}
                    </span>
                    <div className="action-buttons">
                      <button 
                        className="edit-btn"
                        onClick={() => handleEditAssociation(association.id)}
                      >
                        Düzenle
                      </button>
                      <button 
                        className="toggle-btn"
                        onClick={() => handleAssociationStatusChange(
                          association.id, 
                          association.status === 'active' ? 'inactive' : 'active'
                        )}
                      >
                        {association.status === 'active' ? 'Pasifleştir' : 'Aktifleştir'}
                      </button>
                      <button 
                        className="delete-btn"
                        onClick={() => handleDeleteAssociation(association.id)}
                      >
                        Sil
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Competitions Tab */}
        {activeTab === 'competitions' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Yarışma Yönetimi</h2>
              <button className="add-button" onClick={() => setShowAddCompetitionModal(true)}>
                + Yeni Yarışma Oluştur
              </button>
            </div>

            <div className="competitions-list">
              {competitions.map(competition => (
                <div key={competition.id} className="competition-item">
                  <div className="competition-info">
                    <h3>{competition.name}</h3>
                    <p><strong>Tarih:</strong> {new Date(competition.date).toLocaleDateString('tr-TR')}</p>
                    <p><strong>Lokasyon:</strong> {competition.location}</p>
                    <p><strong>Kayıt Sayısı:</strong> {competition.registrationCount}/{competition.maxParticipants}</p>
                  </div>
                  <div className="competition-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(competition.status) }}
                    >
                      {getStatusText(competition.status)}
                    </span>
                    <div className="action-buttons">
                      <button 
                        className="edit-btn"
                        onClick={() => handleEditCompetition(competition.id)}
                      >
                        Düzenle
                      </button>
                      <button 
                        className="toggle-btn"
                        onClick={() => {
                          const statuses = ['planned', 'open', 'ongoing', 'completed'];
                          const currentIndex = statuses.indexOf(competition.status);
                          const nextStatus = statuses[(currentIndex + 1) % statuses.length];
                          handleCompetitionStatusChange(competition.id, nextStatus);
                        }}
                      >
                        Durum Değiştir
                      </button>
                      <button 
                        className="delete-btn"
                        onClick={() => handleDeleteCompetition(competition.id)}
                      >
                        Sil
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Results Tab */}
        {activeTab === 'results' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Sonuç Yönetimi</h2>
            </div>

            <div className="results-list">
              {results.map(result => (
                <div key={result.id} className="result-item">
                  <div className="result-info">
                    <h3>{result.competitionName}</h3>
                    <p><strong>Tarih:</strong> {new Date(result.date).toLocaleDateString('tr-TR')}</p>
                    <p><strong>Toplam Katılımcı:</strong> {result.totalParticipants}</p>
                    
                    <div className="winners-section">
                      <h4>Kazananlar:</h4>
                      {result.winners.map((winner, index) => (
                        <div key={index} className="winner-item">
                          <span className="category">{winner.category}:</span>
                          <span className="winner-name">{winner.winner}</span>
                          <span className="score">({winner.score} puan)</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="result-actions">
                    <div className="action-buttons">
                      <button 
                        className="publish-btn"
                        onClick={() => handlePublishResults(result.id)}
                      >
                        Yayınla
                      </button>
                      <button 
                        className="export-btn"
                        onClick={() => handleExportResults(result.id)}
                      >
                        Excel İndir
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Add Association Modal */}
      {showAddAssociationModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Yeni Dernek Ekle</h3>
              <button className="modal-close" onClick={() => setShowAddAssociationModal(false)}>
                ×
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Dernek Adı *</label>
                <input
                  type="text"
                  value={newAssociation.name}
                  onChange={(e) => setNewAssociation({...newAssociation, name: e.target.value})}
                  placeholder="Dernek adını girin"
                />
              </div>
              <div className="form-group">
                <label>Başkan Adı *</label>
                <input
                  type="text"
                  value={newAssociation.president}
                  onChange={(e) => setNewAssociation({...newAssociation, president: e.target.value})}
                  placeholder="Başkan adını girin"
                />
              </div>
              <div className="form-group">
                <label>İletişim</label>
                <input
                  type="email"
                  value={newAssociation.contact}
                  onChange={(e) => setNewAssociation({...newAssociation, contact: e.target.value})}
                  placeholder="E-posta adresi"
                />
              </div>
              <div className="form-group">
                <label>Üye Sayısı</label>
                <input
                  type="number"
                  value={newAssociation.memberCount}
                  onChange={(e) => setNewAssociation({...newAssociation, memberCount: parseInt(e.target.value) || 0})}
                  min="0"
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowAddAssociationModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={handleAddAssociation}>
                Kaydet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Competition Modal */}
      {showAddCompetitionModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Yeni Yarışma Oluştur</h3>
              <button className="modal-close" onClick={() => setShowAddCompetitionModal(false)}>
                ×
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Yarışma Adı *</label>
                <input
                  type="text"
                  value={newCompetition.name}
                  onChange={(e) => setNewCompetition({...newCompetition, name: e.target.value})}
                  placeholder="Yarışma adını girin"
                />
              </div>
              <div className="form-group">
                <label>Tarih *</label>
                <input
                  type="date"
                  value={newCompetition.date}
                  onChange={(e) => setNewCompetition({...newCompetition, date: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>Lokasyon *</label>
                <input
                  type="text"
                  value={newCompetition.location}
                  onChange={(e) => setNewCompetition({...newCompetition, location: e.target.value})}
                  placeholder="Yarışma lokasyonunu girin"
                />
              </div>
              <div className="form-group">
                <label>Maksimum Katılımcı</label>
                <input
                  type="number"
                  value={newCompetition.maxParticipants}
                  onChange={(e) => setNewCompetition({...newCompetition, maxParticipants: parseInt(e.target.value) || 100})}
                  min="1"
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowAddCompetitionModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={handleCreateCompetition}>
                Oluştur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FederationPage;
