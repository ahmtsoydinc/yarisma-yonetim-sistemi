export enum UserRole {
  SUPERADMIN = 'SUPERADMIN',
  FEDERATION = 'FEDERATION',
  PRESIDENT = 'PRESIDENT',
  JUDGE = 'JUDGE',
  MEMBER = 'MEMBER'
}

export enum AnimalBreed {
  TAVUK = 'TAVUK',
  HOROZ = 'HOROZ',
  GUVERCIN = 'GUVERCIN',
  KAZ = 'KAZ',
  ORDEK = 'ORDEK',
  HINDI = 'HINDI',
  TAVSAN = 'TAVSAN'
}

export enum CompetitionStatus {
  PLANNED = 'PLANNED',
  ACTIVE = 'ACTIVE',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum AnimalRegistrationStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  PARTICIPATING = 'PARTICIPATING',
  COMPLETED = 'COMPLETED'
}

export enum AwardType {
  FIRST_PLACE = 'FIRST_PLACE',
  SECOND_PLACE = 'SECOND_PLACE',
  THIRD_PLACE = 'THIRD_PLACE',
  HONORABLE_MENTION = 'HONORABLE_MENTION',
  SPECIAL_AWARD = 'SPECIAL_AWARD'
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  phone?: string;
  isActive: boolean;
  createdAt: string;
  federation?: {
    id: string;
    name: string;
  };
  association?: {
    id: string;
    name: string;
  };
}

export interface Animal {
  id: string;
  ringNumber: string;
  name?: string;
  gender?: string;
  birthDate?: string;
  ownerId: string;
  associationId: string;
  animalTypeId: string;
  animalColorId: string;
  registrationStatus: AnimalRegistrationStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  animalType?: AnimalType;
  animalColor?: AnimalColor;
  owner?: User;
  association?: Association;
}

export interface AnimalType {
  id: string;
  name: string;
  breed: AnimalBreed;
  description?: string;
  isActive: boolean;
}

export interface AnimalColor {
  id: string;
  name: string;
  code?: string;
  description?: string;
  animalTypeId: string;
  isActive: boolean;
}

export interface Association {
  id: string;
  name: string;
  code: string;
  address?: string;
  phone?: string;
  email?: string;
  membershipFee?: number;
  isActive: boolean;
  federationId: string;
  federation?: Federation;
}

export interface Federation {
  id: string;
  name: string;
  description?: string;
  address?: string;
  phone?: string;
  email?: string;
  isActive: boolean;
}

export interface Competition {
  id: string;
  name: string;
  description?: string;
  location?: string;
  startDate: string;
  endDate: string;
  maxAnimals: number;
  status: CompetitionStatus;
  federationId: string;
  federation?: Federation;
}

export interface Score {
  id: string;
  registrationId: string;
  judgeId: string;
  appearanceScore: number;
  conditionScore: number;
  breedStandardScore: number;
  totalScore: number;
  rank?: number;
  notes?: string;
  createdAt: string;
}

export interface AuthResponse {
  message: string;
  token: string;
  user: User;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  phone?: string;
  federationId?: string;
  associationId?: string;
}
