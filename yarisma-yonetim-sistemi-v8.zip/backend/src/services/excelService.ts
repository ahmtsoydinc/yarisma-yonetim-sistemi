import * as XLSX from 'xlsx';
import { prisma } from '../config/database';
import { AnimalBreed } from '../types';

export interface AnimalTypeImport {
  name: string;
  breed: AnimalBreed;
  description?: string;
}

export interface AnimalColorImport {
  name: string;
  code?: string;
  description?: string;
  animalTypeName: string;
}

export class ExcelService {
  static async importAnimalTypes(file: Buffer): Promise<{ success: number; errors: string[] }> {
    const workbook = XLSX.read(file, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    const errors: string[] = [];
    let success = 0;

    for (const [index, row] of data.entries()) {
      try {
        const animalTypeData = row as any;
        
        // Validate required fields
        if (!animalTypeData.name || !animalTypeData.breed) {
          errors.push(`Satır ${index + 2}: İsim ve cins alanları zorunlu`);
          continue;
        }

        // Validate breed
        if (!Object.values(AnimalBreed).includes(animalTypeData.breed)) {
          errors.push(`Satır ${index + 2}: Geçersiz cins (${animalTypeData.breed})`);
          continue;
        }

        // Check if type already exists
        const existingType = await prisma.animalType.findUnique({
          where: { name: animalTypeData.name }
        });

        if (existingType) {
          errors.push(`Satır ${index + 2}: Bu tür zaten mevcut (${animalTypeData.name})`);
          continue;
        }

        // Create animal type
        await prisma.animalType.create({
          data: {
            name: animalTypeData.name,
            breed: animalTypeData.breed,
            description: animalTypeData.description || null
          }
        });

        success++;
      } catch (error: any) {
        errors.push(`Satır ${index + 2}: ${error.message}`);
      }
    }

    return { success, errors };
  }

  static async importAnimalColors(file: Buffer): Promise<{ success: number; errors: string[] }> {
    const workbook = XLSX.read(file, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    const errors: string[] = [];
    let success = 0;

    for (const [index, row] of data.entries()) {
      try {
        const colorData = row as any;
        
        // Validate required fields
        if (!colorData.name || !colorData.animalTypeName) {
          errors.push(`Satır ${index + 2}: İsim ve hayvan türü alanları zorunlu`);
          continue;
        }

        // Find animal type
        const animalType = await prisma.animalType.findUnique({
          where: { name: colorData.animalTypeName }
        });

        if (!animalType) {
          errors.push(`Satır ${index + 2}: Hayvan türü bulunamadı (${colorData.animalTypeName})`);
          continue;
        }

        // Check if color already exists for this type
        const existingColor = await prisma.animalColor.findFirst({
          where: {
            name: colorData.name,
            animalTypeId: animalType.id
          }
        });

        if (existingColor) {
          errors.push(`Satır ${index + 2}: Bu renk zaten bu tür için mevcut (${colorData.name})`);
          continue;
        }

        // Create animal color
        await prisma.animalColor.create({
          data: {
            name: colorData.name,
            code: colorData.code || null,
            description: colorData.description || null,
            animalTypeId: animalType.id
          }
        });

        success++;
      } catch (error: any) {
        errors.push(`Satır ${index + 2}: ${error.message}`);
      }
    }

    return { success, errors };
  }

  static async exportAnimalTypes(): Promise<Buffer> {
    const animalTypes = await prisma.animalType.findMany({
      orderBy: { name: 'asc' }
    });

    const data = animalTypes.map(type => ({
      'Tür Adı': type.name,
      'Cins': type.breed,
      'Açıklama': type.description || '',
      'Aktif': type.isActive ? 'Evet' : 'Hayır',
      'Oluşturulma Tarihi': new Date(type.createdAt).toLocaleDateString('tr-TR')
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Hayvan Türleri');

    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }

  static async exportAnimalColors(): Promise<Buffer> {
    const animalColors = await prisma.animalColor.findMany({
      include: {
        animalType: true
      },
      orderBy: { name: 'asc' }
    });

    const data = animalColors.map(color => ({
      'Renk Adı': color.name,
      'Renk Kodu': color.code || '',
      'Hayvan Türü': color.animalType.name,
      'Açıklama': color.description || '',
      'Aktif': color.isActive ? 'Evet' : 'Hayır',
      'Oluşturulma Tarihi': new Date(color.createdAt).toLocaleDateString('tr-TR')
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Hayvan Renkleri');

    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }

  static async exportAnimals(): Promise<Buffer> {
    const animals = await prisma.animal.findMany({
      include: {
        animalType: true,
        animalColor: true,
        owner: {
          select: { firstName: true, lastName: true, email: true }
        },
        association: {
          select: { name: true, code: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const data = animals.map(animal => ({
      'Bilezik No': animal.ringNumber,
      'Hayvan Adı': animal.name || '',
      'Cinsiyet': animal.gender || '',
      'Doğum Tarihi': animal.birthDate ? new Date(animal.birthDate).toLocaleDateString('tr-TR') : '',
      'Tür': animal.animalType.name,
      'Renk': animal.animalColor.name,
      'Sahip': `${animal.owner.firstName} ${animal.owner.lastName}`,
      'E-posta': animal.owner.email,
      'Dernek': animal.association.name,
      'Dernek Kodu': animal.association.code,
      'Kayıt Durumu': animal.registrationStatus,
      'Notlar': animal.notes || '',
      'Kayıt Tarihi': new Date(animal.createdAt).toLocaleDateString('tr-TR')
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Hayvanlar');

    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }

  static getTemplateForAnimalTypes(): Buffer {
    const templateData = [
      {
        'name': 'Örnek Tavuk Türü',
        'breed': 'TAVUK',
        'description': 'Örnek açıklama'
      }
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Hayvan Türleri Şablonu');

    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }

  static getTemplateForAnimalColors(): Buffer {
    const templateData = [
      {
        'name': 'Örnek Renk',
        'code': '#FF0000',
        'description': 'Örnek açıklama',
        'animalTypeName': 'Örnek Tavuk Türü'
      }
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Hayvan Renkleri Şablonu');

    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }
}
