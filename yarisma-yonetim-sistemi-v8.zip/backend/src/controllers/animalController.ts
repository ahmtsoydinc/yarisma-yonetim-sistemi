import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';
// import { AuthRequest } from '../types';

export const getAnimals = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, associationId, status } = req.query;
    const userId = (req as any).user!.userId;

    let where: any = {};
    
    // Filter based on user role
    if ((req as any).user!.role === 'MEMBER') {
      where.owner = userId;
    }
    
    if (status) where.isActive = status === 'active';

    const animals = await prisma.animal.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        animalType: true
      },
      orderBy: { createdAt: 'desc' }
    });

    const total = await prisma.animal.count({ where });

    res.json({
      animals,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getAnimalById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const animal = await prisma.animal.findUnique({
      where: { id },
      include: {
        animalType: true
      }
    });

    if (!animal) {
      throw createError('Animal not found', 404);
    }

    res.json({ animal });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createAnimal = async (req: Request, res: Response) => {
  try {
    const { ringNumber, name, gender, age, weight, animalTypeId, notes } = req.body;
    const userId = (req as any).user!.userId;

    // Check if ring number already exists
    const existingAnimal = await prisma.animal.findUnique({
      where: { ringNumber }
    });

    if (existingAnimal) {
      throw createError('Bu bilezik numarası zaten kayıtlı', 400);
    }

    // Get user's association
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { associationId: true }
    });

    if (!user?.associationId) {
      throw createError('Kullanıcı bir derneğe bağlı değil', 400);
    }

    const animal = await prisma.animal.create({
      data: {
        ringNumber,
        name,
        gender,
        age,
        weight,
        animalTypeId,
        owner: userId,
        notes,
        type: 'TAVUK', // Default type
        color: 'BEYAZ' // Default color
      },
      include: {
        animalType: true
      }
    });

    res.status(201).json({
      message: 'Hayvan başarıyla kaydedildi',
      animal
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateAnimal = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, gender, age, weight, animalTypeId, notes } = req.body;
    const userId = (req as any).user!.userId;

    // Check if animal exists and user has permission
    const existingAnimal = await prisma.animal.findUnique({
      where: { id }
    });

    if (!existingAnimal) {
      throw createError('Animal not found', 404);
    }

    // Only owner or admin can update
    if (existingAnimal.owner !== userId && !['SUPERADMIN', 'FEDERATION'].includes((req as any).user!.role)) {
      throw createError('Bu hayvanı güncelleme yetkiniz yok', 403);
    }

    const animal = await prisma.animal.update({
      where: { id },
      data: {
        name,
        gender,
        age,
        weight,
        animalTypeId,
        notes
      },
      include: {
        animalType: true
      }
    });

    res.json({
      message: 'Hayvan başarıyla güncellendi',
      animal
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteAnimal = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user!.userId;

    // Check if animal exists and user has permission
    const existingAnimal = await prisma.animal.findUnique({
      where: { id }
    });

    if (!existingAnimal) {
      throw createError('Animal not found', 404);
    }

    // Only owner or admin can delete
    if (existingAnimal.owner !== userId && !['SUPERADMIN', 'FEDERATION'].includes((req as any).user!.role)) {
      throw createError('Bu hayvanı silme yetkiniz yok', 403);
    }

    await prisma.animal.delete({
      where: { id }
    });

    res.json({ message: 'Hayvan başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const importAnimalTypes = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      throw createError('Excel dosyası yüklenmedi', 400);
    }

    const { ExcelService } = await import('../services/excelService');
    const result = await ExcelService.importAnimalTypes(req.file.buffer);

    res.json({
      message: `${result.success} hayvan türü başarıyla yüklendi`,
      success: result.success,
      errors: result.errors
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const importAnimalColors = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      throw createError('Excel dosyası yüklenmedi', 400);
    }

    const { ExcelService } = await import('../services/excelService');
    const result = await ExcelService.importAnimalColors(req.file.buffer);

    res.json({
      message: `${result.success} hayvan rengi başarıyla yüklendi`,
      success: result.success,
      errors: result.errors
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};
