import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getCompetitions, 
  getCompetitionById, 
  createCompetition, 
  updateCompetition, 
  deleteCompetition,
  updateCompetitionStatus,
  getCompetitionStats,
  getAvailableFederations
} from '../controllers/competitionController';
import { authenticateToken, requireSuperAdmin } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createCompetitionValidation = [
  body('name').notEmpty().withMessage('Yarışma adı zorunludur'),
  body('location').optional().isString().withMessage('Konum geçerli bir metin olmalıdır'),
  body('startDate').isISO8601().withMessage('Geçerli bir başlangıç tarihi giriniz'),
  body('endDate').isISO8601().withMessage('Geçerli bir bitiş tarihi giriniz'),
  body('maxAnimals').optional().isInt({ min: 1 }).withMessage('Maksimum hayvan sayısı 1\'den büyük olmalıdır'),
  body('federationId').isUUID().withMessage('Geçerli bir federasyon ID seçiniz'),
  body('status').optional().isIn(['PLANNED', 'OPEN', 'CLOSED', 'ONGOING', 'COMPLETED', 'CANCELLED']).withMessage('Geçersiz durum'),
];

const updateCompetitionValidation = [
  body('name').optional().notEmpty().withMessage('Yarışma adı boş olamaz'),
  body('location').optional().isString().withMessage('Konum geçerli bir metin olmalıdır'),
  body('startDate').optional().isISO8601().withMessage('Geçerli bir başlangıç tarihi giriniz'),
  body('endDate').optional().isISO8601().withMessage('Geçerli bir bitiş tarihi giriniz'),
  body('maxAnimals').optional().isInt({ min: 1 }).withMessage('Maksimum hayvan sayısı 1\'den büyük olmalıdır'),
  body('status').optional().isIn(['PLANNED', 'OPEN', 'CLOSED', 'ONGOING', 'COMPLETED', 'CANCELLED']).withMessage('Geçersiz durum'),
];

const updateStatusValidation = [
  body('status').isIn(['PLANNED', 'OPEN', 'CLOSED', 'ONGOING', 'COMPLETED', 'CANCELLED']).withMessage('Geçersiz durum'),
];

// Public routes (authenticated users can view)
router.get('/', getCompetitions);
router.get('/available-federations', getAvailableFederations);
router.get('/:id', getCompetitionById);
router.get('/:id/stats', getCompetitionStats);

// Superadmin only routes
router.post('/', createCompetitionValidation, validateRequest, requireSuperAdmin, createCompetition);
router.put('/:id', updateCompetitionValidation, validateRequest, requireSuperAdmin, updateCompetition);
router.patch('/:id/status', updateStatusValidation, validateRequest, requireSuperAdmin, updateCompetitionStatus);
router.delete('/:id', requireSuperAdmin, deleteCompetition);

export default router;