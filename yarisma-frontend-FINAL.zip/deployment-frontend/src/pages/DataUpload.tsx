import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';
import { animalTypesAPI } from '../services/api';

const DataUpload: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('animal-types');
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [uploadMessage, setUploadMessage] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedData, setUploadedData] = useState<any[]>([]);

  const handleBack = () => {
    navigate('/dashboard');
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadStatus('uploading');
    setUploadMessage('');
    setUploadProgress(0);
    setUploadedData([]);

    try {
      // File validation
      if (!file.name.match(/\.(xlsx|xls)$/i)) {
        throw new Error('Geçersiz dosya formatı. Lütfen Excel dosyası (.xlsx, .xls) seçin.');
      }

      // Read Excel file
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

          setUploadProgress(50);

          // Validate and process data based on active tab
          setTimeout(async () => {
            try {
              const processedData = processExcelData(jsonData as any[][], activeTab);
              setUploadProgress(75);
              
              // Upload to API
              if (activeTab === 'animal-types') {
                for (const item of processedData) {
                  await animalTypesAPI.createAnimalType(item);
                }
              } else if (activeTab === 'animal-colors') {
                for (const item of processedData) {
                  await animalTypesAPI.createAnimalColor(item);
                }
              }
              
              setUploadProgress(100);
              setUploadedData(processedData);
              setUploadStatus('success');
              setUploadMessage(`${file.name} başarıyla yüklendi! ${processedData.length} kayıt sisteme eklendi.`);
            } catch (error) {
              setUploadStatus('error');
              setUploadMessage('Veriler sisteme kaydedilirken hata oluştu: ' + (error as Error).message);
            }
          }, 1000);
        } catch (error) {
          setUploadStatus('error');
          setUploadMessage('Dosya okuma hatası: ' + (error as Error).message);
        }
      };
      reader.readAsArrayBuffer(file);
    } catch (error) {
      setUploadStatus('error');
      setUploadMessage((error as Error).message);
    }
  };

  const processExcelData = (data: any[][], type: string) => {
    if (!data || data.length < 2) {
      throw new Error('Excel dosyası boş veya geçersiz format.');
    }

    const rows = data.slice(1);
    const processedData: any[] = [];

    rows.forEach((row, index) => {
      if (row.some(cell => cell !== undefined && cell !== null && cell !== '')) {
        const item: any = {};
        
        if (type === 'animal-types') {
          item.id = Date.now() + index;
          item.name = row[0] || '';
          item.species = row[1] || '';
          item.description = row[2] || '';
          item.isActive = true;
          item.createdAt = new Date().toISOString();
        } else if (type === 'animal-colors') {
          item.id = Date.now() + index;
          item.name = row[0] || '';
          item.hexCode = row[1] || '';
          item.animalType = row[2] || '';
          item.isActive = true;
          item.createdAt = new Date().toISOString();
        }
        
        processedData.push(item);
      }
    });

    return processedData;
  };

  const downloadTemplate = (type: 'animal-types' | 'animal-colors') => {
    let data: any[][] = [];
    let filename = '';

    if (type === 'animal-types') {
      data = [
        ['Hayvan Türü Adı', 'Hayvan Cinsi', 'Açıklama'],
        ['Brahma', 'TAVUK', 'Büyük ırk tavuk türü'],
        ['Leghorn', 'TAVUK', 'Yumurta tavuğu'],
        ['Rhode Island Red', 'TAVUK', 'Çift amaçlı tavuk'],
        ['Orpington', 'TAVUK', 'Büyük ırk tavuk'],
        ['Sussex', 'TAVUK', 'Çift amaçlı tavuk']
      ];
      filename = 'hayvan_turleri_sablonu.xlsx';
    } else if (type === 'animal-colors') {
      data = [
        ['Renk Adı', 'HEX Renk Kodu', 'Hayvan Türü'],
        ['Beyaz', '#FFFFFF', 'Brahma'],
        ['Siyah', '#000000', 'Orpington'],
        ['Kahverengi', '#8B4513', 'Rhode Island Red'],
        ['Kırmızı', '#FF0000', 'Leghorn'],
        ['Gri', '#808080', 'Sussex']
      ];
      filename = 'hayvan_renkleri_sablonu.xlsx';
    }

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Veri');

    // Auto-size columns
    const colWidths = data[0].map(() => ({ wch: 20 }));
    worksheet['!cols'] = colWidths;

    XLSX.writeFile(workbook, filename);
    console.log(`${filename} indirildi`);
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem' }}>
          <button
            onClick={handleBack}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '1.5rem',
              cursor: 'pointer',
              marginRight: '1rem',
              padding: '0.5rem',
              borderRadius: '0.375rem',
              transition: 'background-color 0.15s ease-in-out'
            }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f3f4f6'}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >
            ←
          </button>
          <h1 className="dashboard-title">Veri Yükleme</h1>
        </div>
        <p className="dashboard-subtitle">
          Hayvan cins, tür ve renk verilerini Excel ile yükleyin
        </p>
      </div>

      {/* Tab Navigation */}
      <div style={{ 
        display: 'flex', 
        borderBottom: '1px solid #e5e7eb', 
        marginBottom: '2rem',
        gap: '1rem'
      }}>
        <button
          onClick={() => setActiveTab('animal-types')}
          style={{
            padding: '0.75rem 1.5rem',
            border: 'none',
            background: activeTab === 'animal-types' ? '#3b82f6' : 'transparent',
            color: activeTab === 'animal-types' ? 'white' : '#6b7280',
            cursor: 'pointer',
            borderRadius: '0.375rem 0.375rem 0 0',
            fontWeight: '500',
            transition: 'all 0.15s ease-in-out'
          }}
        >
          Hayvan Türleri
        </button>
        <button
          onClick={() => setActiveTab('animal-colors')}
          style={{
            padding: '0.75rem 1.5rem',
            border: 'none',
            background: activeTab === 'animal-colors' ? '#3b82f6' : 'transparent',
            color: activeTab === 'animal-colors' ? 'white' : '#6b7280',
            cursor: 'pointer',
            borderRadius: '0.375rem 0.375rem 0 0',
            fontWeight: '500',
            transition: 'all 0.15s ease-in-out'
          }}
        >
          Hayvan Renkleri
        </button>
        <button
          onClick={() => setActiveTab('templates')}
          style={{
            padding: '0.75rem 1.5rem',
            border: 'none',
            background: activeTab === 'templates' ? '#3b82f6' : 'transparent',
            color: activeTab === 'templates' ? 'white' : '#6b7280',
            cursor: 'pointer',
            borderRadius: '0.375rem 0.375rem 0 0',
            fontWeight: '500',
            transition: 'all 0.15s ease-in-out'
          }}
        >
          Şablon İndir
        </button>
      </div>

      {/* Tab Content */}
      <div className="card">
        {activeTab === 'animal-types' && (
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#111827', marginBottom: '1rem' }}>
              Hayvan Türleri Yükleme
            </h3>
            <p style={{ color: '#6b7280', marginBottom: '2rem' }}>
              Excel dosyası ile hayvan türlerini toplu olarak sisteme yükleyin
            </p>

            {/* Upload Area */}
            <div style={{
              border: '2px dashed #d1d5db',
              borderRadius: '0.5rem',
              padding: '2rem',
              textAlign: 'center',
              marginBottom: '2rem',
              backgroundColor: '#f9fafb'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📊</div>
              <h4 style={{ fontSize: '1.125rem', fontWeight: '600', color: '#111827', marginBottom: '0.5rem' }}>
                Excel Dosyası Yükleyin
              </h4>
              <p style={{ color: '#6b7280', marginBottom: '1rem' }}>
                Hayvan türleri için Excel dosyasını seçin (.xlsx, .xls)
              </p>
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileUpload}
                style={{ display: 'none' }}
                id="animal-types-upload"
              />
              <label
                htmlFor="animal-types-upload"
                className="btn-primary"
                style={{ cursor: 'pointer', display: 'inline-block' }}
              >
                Dosya Seç
              </label>
            </div>

            {/* Upload Status */}
            {uploadStatus !== 'idle' && (
              <div style={{
                padding: '1rem',
                borderRadius: '0.375rem',
                marginBottom: '2rem',
                backgroundColor: uploadStatus === 'success' ? '#dcfce7' : uploadStatus === 'error' ? '#fee2e2' : '#dbeafe',
                color: uploadStatus === 'success' ? '#166534' : uploadStatus === 'error' ? '#dc2626' : '#1e40af',
                border: `1px solid ${uploadStatus === 'success' ? '#bbf7d0' : uploadStatus === 'error' ? '#fecaca' : '#bfdbfe'}`
              }}>
                {uploadStatus === 'uploading' && (
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <div className="spinner" style={{ marginRight: '0.5rem' }}></div>
                      Dosya yükleniyor...
                    </div>
                    <div style={{
                      width: '100%',
                      backgroundColor: '#e5e7eb',
                      borderRadius: '0.25rem',
                      overflow: 'hidden'
                    }}>
                      <div style={{
                        width: `${uploadProgress}%`,
                        backgroundColor: '#3b82f6',
                        height: '0.5rem',
                        transition: 'width 0.3s ease-in-out'
                      }}></div>
                    </div>
                    <div style={{ fontSize: '0.875rem', marginTop: '0.25rem' }}>
                      {uploadProgress}% tamamlandı
                    </div>
                  </div>
                )}
                {uploadStatus === 'success' && (
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <span style={{ marginRight: '0.5rem' }}>✅</span>
                      {uploadMessage}
                    </div>
                    {uploadedData.length > 0 && (
                      <div style={{ marginTop: '1rem' }}>
                        <h5 style={{ fontSize: '0.875rem', fontWeight: '600', marginBottom: '0.5rem' }}>
                          Yüklenen Veriler:
                        </h5>
                        <div style={{ maxHeight: '200px', overflowY: 'auto', backgroundColor: '#f9fafb', padding: '0.5rem', borderRadius: '0.25rem' }}>
                          {uploadedData.slice(0, 5).map((item, index) => (
                            <div key={index} style={{ fontSize: '0.75rem', padding: '0.25rem 0', borderBottom: index < 4 ? '1px solid #e5e7eb' : 'none' }}>
                              {activeTab === 'animal-types' ? 
                                `${item.name} (${item.species})` : 
                                `${item.name} (${item.hexCode})`
                              }
                            </div>
                          ))}
                          {uploadedData.length > 5 && (
                            <div style={{ fontSize: '0.75rem', padding: '0.25rem 0', fontStyle: 'italic', color: '#6b7280' }}>
                              ... ve {uploadedData.length - 5} kayıt daha
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
                {uploadStatus === 'error' && (
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    <span style={{ marginRight: '0.5rem' }}>❌</span>
                    {uploadMessage}
                  </div>
                )}
              </div>
            )}

            {/* File Format Info */}
            <div style={{
              backgroundColor: '#f3f4f6',
              padding: '1rem',
              borderRadius: '0.375rem',
              marginBottom: '2rem'
            }}>
              <h5 style={{ fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.5rem' }}>
                Excel Dosyası Formatı
              </h5>
              <p style={{ fontSize: '0.875rem', color: '#6b7280', marginBottom: '0.5rem' }}>
                Excel dosyanız aşağıdaki sütunları içermelidir:
              </p>
              <ul style={{ fontSize: '0.875rem', color: '#6b7280', paddingLeft: '1rem' }}>
                <li><strong>A Sütunu:</strong> Hayvan Türü Adı (örn: Brahma, Leghorn)</li>
                <li><strong>B Sütunu:</strong> Hayvan Cinsi (TAVUK, HOROZ, GUVERCIN, vb.)</li>
                <li><strong>C Sütunu:</strong> Açıklama (opsiyonel)</li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'animal-colors' && (
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#111827', marginBottom: '1rem' }}>
              Hayvan Renkleri Yükleme
            </h3>
            <p style={{ color: '#6b7280', marginBottom: '2rem' }}>
              Excel dosyası ile hayvan renklerini toplu olarak sisteme yükleyin
            </p>

            {/* Upload Area */}
            <div style={{
              border: '2px dashed #d1d5db',
              borderRadius: '0.5rem',
              padding: '2rem',
              textAlign: 'center',
              marginBottom: '2rem',
              backgroundColor: '#f9fafb'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎨</div>
              <h4 style={{ fontSize: '1.125rem', fontWeight: '600', color: '#111827', marginBottom: '0.5rem' }}>
                Renk Excel Dosyası Yükleyin
              </h4>
              <p style={{ color: '#6b7280', marginBottom: '1rem' }}>
                Hayvan renkleri için Excel dosyasını seçin (.xlsx, .xls)
              </p>
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileUpload}
                style={{ display: 'none' }}
                id="animal-colors-upload"
              />
              <label
                htmlFor="animal-colors-upload"
                className="btn-primary"
                style={{ cursor: 'pointer', display: 'inline-block' }}
              >
                Dosya Seç
              </label>
            </div>

            {/* Upload Status for Colors */}
            {uploadStatus !== 'idle' && activeTab === 'animal-colors' && (
              <div style={{
                padding: '1rem',
                borderRadius: '0.375rem',
                marginBottom: '2rem',
                backgroundColor: uploadStatus === 'success' ? '#dcfce7' : uploadStatus === 'error' ? '#fee2e2' : '#dbeafe',
                color: uploadStatus === 'success' ? '#166534' : uploadStatus === 'error' ? '#dc2626' : '#1e40af',
                border: `1px solid ${uploadStatus === 'success' ? '#bbf7d0' : uploadStatus === 'error' ? '#fecaca' : '#bfdbfe'}`
              }}>
                {uploadStatus === 'uploading' && (
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <div className="spinner" style={{ marginRight: '0.5rem' }}></div>
                      Dosya yükleniyor...
                    </div>
                    <div style={{
                      width: '100%',
                      backgroundColor: '#e5e7eb',
                      borderRadius: '0.25rem',
                      overflow: 'hidden'
                    }}>
                      <div style={{
                        width: `${uploadProgress}%`,
                        backgroundColor: '#3b82f6',
                        height: '0.5rem',
                        transition: 'width 0.3s ease-in-out'
                      }}></div>
                    </div>
                    <div style={{ fontSize: '0.875rem', marginTop: '0.25rem' }}>
                      {uploadProgress}% tamamlandı
                    </div>
                  </div>
                )}
                {uploadStatus === 'success' && (
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <span style={{ marginRight: '0.5rem' }}>✅</span>
                      {uploadMessage}
                    </div>
                    {uploadedData.length > 0 && (
                      <div style={{ marginTop: '1rem' }}>
                        <h5 style={{ fontSize: '0.875rem', fontWeight: '600', marginBottom: '0.5rem' }}>
                          Yüklenen Renkler:
                        </h5>
                        <div style={{ maxHeight: '200px', overflowY: 'auto', backgroundColor: '#f9fafb', padding: '0.5rem', borderRadius: '0.25rem' }}>
                          {uploadedData.slice(0, 5).map((item, index) => (
                            <div key={index} style={{ fontSize: '0.75rem', padding: '0.25rem 0', borderBottom: index < 4 ? '1px solid #e5e7eb' : 'none', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                              <div style={{ width: '1rem', height: '1rem', backgroundColor: item.hexCode, border: '1px solid #ccc', borderRadius: '0.125rem' }}></div>
                              {item.name} ({item.hexCode})
                            </div>
                          ))}
                          {uploadedData.length > 5 && (
                            <div style={{ fontSize: '0.75rem', padding: '0.25rem 0', fontStyle: 'italic', color: '#6b7280' }}>
                              ... ve {uploadedData.length - 5} kayıt daha
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
                {uploadStatus === 'error' && (
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    <span style={{ marginRight: '0.5rem' }}>❌</span>
                    {uploadMessage}
                  </div>
                )}
              </div>
            )}

            {/* File Format Info */}
            <div style={{
              backgroundColor: '#f3f4f6',
              padding: '1rem',
              borderRadius: '0.375rem',
              marginBottom: '2rem'
            }}>
              <h5 style={{ fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.5rem' }}>
                Excel Dosyası Formatı
              </h5>
              <p style={{ fontSize: '0.875rem', color: '#6b7280', marginBottom: '0.5rem' }}>
                Excel dosyanız aşağıdaki sütunları içermelidir:
              </p>
              <ul style={{ fontSize: '0.875rem', color: '#6b7280', paddingLeft: '1rem' }}>
                <li><strong>A Sütunu:</strong> Renk Adı (örn: Beyaz, Siyah, Kahverengi)</li>
                <li><strong>B Sütunu:</strong> HEX Renk Kodu (örn: #FFFFFF, #000000)</li>
                <li><strong>C Sütunu:</strong> Hayvan Türü Adı (daha önce yüklenmiş olmalı)</li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'templates' && (
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#111827', marginBottom: '1rem' }}>
              Şablon Dosyaları
            </h3>
            <p style={{ color: '#6b7280', marginBottom: '2rem' }}>
              Doğru format için örnek Excel şablonlarını indirin
            </p>

            <div className="grid">
              <div className="card">
                <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>📋</div>
                <h4 style={{ fontSize: '1rem', fontWeight: '600', color: '#111827', marginBottom: '0.5rem' }}>
                  Hayvan Türleri Şablonu
                </h4>
                <p style={{ fontSize: '0.875rem', color: '#6b7280', marginBottom: '1rem' }}>
                  Hayvan türleri için Excel şablonu
                </p>
                <button 
                  className="btn-primary" 
                  style={{ padding: '0.5rem 1rem', width: 'auto' }}
                  onClick={() => downloadTemplate('animal-types')}
                >
                  📥 İndir
                </button>
              </div>

              <div className="card">
                <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>🎨</div>
                <h4 style={{ fontSize: '1rem', fontWeight: '600', color: '#111827', marginBottom: '0.5rem' }}>
                  Hayvan Renkleri Şablonu
                </h4>
                <p style={{ fontSize: '0.875rem', color: '#6b7280', marginBottom: '1rem' }}>
                  Hayvan renkleri için Excel şablonu
                </p>
                <button 
                  className="btn-primary" 
                  style={{ padding: '0.5rem 1rem', width: 'auto' }}
                  onClick={() => downloadTemplate('animal-colors')}
                >
                  📥 İndir
                </button>
              </div>
            </div>

            {/* Instructions */}
            <div style={{
              backgroundColor: '#fef3c7',
              padding: '1rem',
              borderRadius: '0.375rem',
              marginTop: '2rem',
              border: '1px solid #fbbf24'
            }}>
              <h5 style={{ fontSize: '0.875rem', fontWeight: '600', color: '#92400e', marginBottom: '0.5rem' }}>
                📝 Kullanım Talimatları
              </h5>
              <ol style={{ fontSize: '0.875rem', color: '#92400e', paddingLeft: '1rem' }}>
                <li>İstediğiniz şablonu indirin</li>
                <li>Excel dosyasını açın ve örnek verileri kendi verilerinizle değiştirin</li>
                <li>Dosyayı kaydedin ve sisteme yükleyin</li>
                <li>Yükleme sonucunu kontrol edin</li>
              </ol>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DataUpload;
