import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useAuth } from '../contexts/AuthContext';
import { LoginRequest } from '../types';
import { associationsAPI } from '../services/api';
// EyeIcon ve EyeSlashIcon kullanılmıyor, emoji ile değiştirildi

const Login: React.FC = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [associations, setAssociations] = useState<any[]>([]);
  const [selectedAssociation, setSelectedAssociation] = useState('');
  const [userRole, setUserRole] = useState('');
  const { login, isLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const from = location.state?.from?.pathname || '/dashboard';

  useEffect(() => {
    const loadAssociations = async () => {
      try {
        const response = await associationsAPI.getAssociations();
        setAssociations(response.associations);
      } catch (error) {
        console.error('Dernekler yüklenirken hata:', error);
      }
    };

    loadAssociations();
  }, []);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginRequest>();

  // Email değiştiğinde kullanıcı rolünü belirle
  const handleEmailChange = (email: string) => {
    if (email.includes('admin@sustavuklari.org')) {
      setUserRole('SUPERADMIN');
    } else if (email.includes('federation@sustavuklari.org')) {
      setUserRole('FEDERATION');
    } else if (email.includes('judge@sustavuklari.org')) {
      setUserRole('JUDGE');
    } else if (email.includes('president@') || email.includes('member@')) {
      setUserRole('MEMBER_OR_PRESIDENT');
    } else {
      setUserRole('');
    }
  };

  const onSubmit = async (data: LoginRequest) => {
    try {
      // SUPERADMIN, FEDERATION, JUDGE için dernek seçimi opsiyonel
      // Diğer roller için dernek seçimi zorunlu
      if (['SUPERADMIN', 'FEDERATION', 'JUDGE'].includes(userRole)) {
        await login(data, selectedAssociation);
      } else if (userRole === 'MEMBER_OR_PRESIDENT' && !selectedAssociation) {
        alert('Lütfen derneğinizi seçiniz');
        return;
      } else {
        await login(data, selectedAssociation);
      }
      navigate(from, { replace: true });
    } catch (error) {
      // Error is handled in AuthContext
    }
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <div>
          <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
            <div style={{ 
              width: '5rem', 
              height: '5rem', 
              margin: '0 auto 1.5rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <img 
                src="/tshf-logo.png" 
                alt="TSHF Logo" 
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'contain',
                  borderRadius: '12px',
                  border: '2px solid rgba(255, 255, 255, 0.2)',
                  backgroundColor: 'rgba(255, 255, 255, 0.1)',
                  backdropFilter: 'blur(5px)',
                  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)'
                }}
              />
            </div>
            <h2 className="login-title">
              TSHF Süs Tavukları Yarışma Sistemi
            </h2>
            <p className="login-subtitle">
              Türkiye Süs Tavukları ve Bahçe Hayvanları Federasyonu
            </p>
          </div>
        </div>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="form-group">
            <input
              {...register('email', {
                required: 'E-posta adresi gerekli',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Geçerli bir e-posta adresi girin',
                },
              })}
              type="email"
              autoComplete="email"
              className="form-input"
              placeholder="E-posta adresi"
              onChange={(e) => handleEmailChange(e.target.value)}
            />
            {errors.email && (
              <p className="error-message">{errors.email.message}</p>
            )}
          </div>
          
          <div className="form-group">
            <select
              value={selectedAssociation}
              onChange={(e) => setSelectedAssociation(e.target.value)}
              className="form-input"
              style={{ 
                background: 'white',
                border: '1px solid #d1d5db',
                borderRadius: '0.5rem',
                padding: '0.75rem',
                fontSize: '1rem',
                color: '#374151'
              }}
            >
              <option value="">
                {userRole === 'MEMBER_OR_PRESIDENT' 
                  ? 'Dernek Seçiniz (Zorunlu)' 
                  : 'TSHF / Dernek Seçiniz (Opsiyonel)'
                }
              </option>
              {['SUPERADMIN', 'FEDERATION', 'JUDGE'].includes(userRole) && (
                <option value="TSHF">TSHF - Türkiye Süs Tavukları Federasyonu</option>
              )}
              {associations.map((association) => (
                <option key={association.id} value={association.id}>
                  {association.name}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group" style={{ position: 'relative' }}>
            <input
              {...register('password', {
                required: 'Şifre gerekli',
                minLength: {
                  value: 6,
                  message: 'Şifre en az 6 karakter olmalı',
                },
              })}
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              className="form-input"
              placeholder="Şifre"
              style={{ paddingRight: '3rem' }}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="password-toggle"
            >
              {showPassword ? '🙈' : '👁️'}
            </button>
            {errors.password && (
              <p className="error-message">{errors.password.message}</p>
            )}
          </div>

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary"
            >
              {isLoading ? (
                <div className="spinner"></div>
              ) : (
                'Giriş Yap'
              )}
            </button>
          </div>

          <div style={{ textAlign: 'center', marginTop: '1rem' }}>
            <p style={{ fontSize: '0.875rem', color: '#6b7280' }}>
              Hesabınız yok mu?{' '}
              <Link
                to="/register"
                style={{ color: '#3b82f6', fontWeight: '500' }}
              >
                Kayıt olun
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
