import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';

export const getPages = async (req: Request, res: Response) => {
  try {
    const { isActive, isVisible } = req.query;
    
    const where: any = {};
    if (isActive !== undefined) where.isActive = isActive === 'true';
    if (isVisible !== undefined) where.isVisible = isVisible === 'true';

    const pages = await prisma.page.findMany({
      where,
      include: {
        permissions: {
          select: {
            role: true,
            canView: true,
            canEdit: true,
            canDelete: true
          }
        }
      },
      orderBy: { order: 'asc' }
    });

    res.json({ pages });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getPageById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const page = await prisma.page.findUnique({
      where: { id },
      include: {
        permissions: {
          select: {
            id: true,
            role: true,
            canView: true,
            canEdit: true,
            canDelete: true
          }
        }
      }
    });

    if (!page) {
      throw createError('Sayfa bulunamadı', 404);
    }

    res.json({ page });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createPage = async (req: Request, res: Response) => {
  try {
    const { name, title, description, path, icon, color, shape, isActive, isVisible, order, permissions } = req.body;

    // Check if page already exists
    const existingPage = await prisma.page.findFirst({
      where: {
        OR: [
          { name },
          { path }
        ]
      }
    });

    if (existingPage) {
      throw createError('Bu isim veya path ile bir sayfa zaten mevcut', 400);
    }

    const page = await prisma.page.create({
      data: {
        name,
        title,
        description,
        path,
        icon,
        color,
        shape,
        isActive: isActive !== undefined ? isActive : true,
        isVisible: isVisible !== undefined ? isVisible : true,
        order: order || 0,
        permissions: {
          create: permissions || []
        }
      },
      include: {
        permissions: {
          select: {
            id: true,
            role: true,
            canView: true,
            canEdit: true,
            canDelete: true
          }
        }
      }
    });

    res.status(201).json({
      message: 'Sayfa başarıyla oluşturuldu',
      page
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updatePage = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, title, description, path, icon, color, shape, isActive, isVisible, order, permissions } = req.body;

    // Check if page exists
    const existingPage = await prisma.page.findUnique({
      where: { id }
    });

    if (!existingPage) {
      throw createError('Sayfa bulunamadı', 404);
    }

    // Check for duplicate name/path
    const duplicatePage = await prisma.page.findFirst({
      where: {
        AND: [
          { id: { not: id } },
          {
            OR: [
              { name },
              { path }
            ]
          }
        ]
      }
    });

    if (duplicatePage) {
      throw createError('Bu isim veya path ile başka bir sayfa mevcut', 400);
    }

    // Update page
    const page = await prisma.page.update({
      where: { id },
      data: {
        name,
        title,
        description,
        path,
        icon,
        color,
        shape,
        isActive,
        isVisible,
        order
      },
      include: {
        permissions: {
          select: {
            id: true,
            role: true,
            canView: true,
            canEdit: true,
            canDelete: true
          }
        }
      }
    });

    // Update permissions if provided
    if (permissions) {
      // Delete existing permissions
      await prisma.pagePermission.deleteMany({
        where: { pageId: id }
      });

      // Create new permissions
      await prisma.pagePermission.createMany({
        data: permissions.map((perm: any) => ({
          pageId: id,
          role: perm.role,
          canView: perm.canView,
          canEdit: perm.canEdit,
          canDelete: perm.canDelete
        }))
      });

      // Fetch updated page with permissions
      const updatedPage = await prisma.page.findUnique({
        where: { id },
        include: {
          permissions: {
            select: {
              id: true,
              role: true,
              canView: true,
              canEdit: true,
              canDelete: true
            }
          }
        }
      });

      return res.json({
        message: 'Sayfa başarıyla güncellendi',
        page: updatedPage
      });
    }

    return res.json({
      message: 'Sayfa başarıyla güncellendi',
      page
    });
  } catch (error: any) {
    return res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deletePage = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Check if page exists
    const existingPage = await prisma.page.findUnique({
      where: { id }
    });

    if (!existingPage) {
      throw createError('Sayfa bulunamadı', 404);
    }

    await prisma.page.delete({
      where: { id }
    });

    res.json({ message: 'Sayfa başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getPagePermissions = async (req: Request, res: Response) => {
  try {
    const { pageId } = req.params;

    const permissions = await prisma.pagePermission.findMany({
      where: { pageId },
      include: {
        page: {
          select: {
            id: true,
            name: true,
            title: true
          }
        }
      }
    });

    res.json({ permissions });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const updatePagePermissions = async (req: Request, res: Response) => {
  try {
    const { pageId } = req.params;
    const { permissions } = req.body;

    // Delete existing permissions
    await prisma.pagePermission.deleteMany({
      where: { pageId }
    });

    // Create new permissions
    if (permissions && permissions.length > 0) {
      await prisma.pagePermission.createMany({
        data: permissions.map((perm: any) => ({
          pageId,
          role: perm.role,
          canView: perm.canView,
          canEdit: perm.canEdit,
          canDelete: perm.canDelete
        }))
      });
    }

    res.json({ message: 'Sayfa izinleri başarıyla güncellendi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getUserVisiblePages = async (req: Request, res: Response) => {
  try {
    const userRole = (req as any).user?.role;

    if (!userRole) {
      throw createError('Kullanıcı rolü bulunamadı', 401);
    }

    const pages = await prisma.page.findMany({
      where: {
        isActive: true,
        isVisible: true,
        permissions: {
          some: {
            role: userRole,
            canView: true
          }
        }
      },
      include: {
        permissions: {
          where: {
            role: userRole
          },
          select: {
            canView: true,
            canEdit: true,
            canDelete: true
          }
        }
      },
      orderBy: { order: 'asc' }
    });

    res.json({ pages });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getPageAccessByRole = async (req: Request, res: Response) => {
  try {
    const { role } = req.params;

    const pages = await prisma.page.findMany({
      where: {
        isActive: true,
        permissions: {
          some: {
            role: role,
            canView: true
          }
        }
      },
      include: {
        permissions: {
          where: {
            role: role
          },
          select: {
            canView: true,
            canEdit: true,
            canDelete: true
          }
        }
      },
      orderBy: { order: 'asc' }
    });

    res.json({ 
      role,
      pages,
      totalPages: pages.length
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};
