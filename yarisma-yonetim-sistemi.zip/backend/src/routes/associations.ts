import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getAssociations, 
  getAssociationById, 
  createAssociation, 
  updateAssociation, 
  deleteAssociation,
  getAssociationMembers,
  addAssociationMember,
  removeAssociationMember
} from '../controllers/associationController';
import { authenticateToken, requireFederation } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createAssociationValidation = [
  body('name').notEmpty().trim(),
  body('code').notEmpty().trim(),
  body('federationId').isUUID(),
  body('membershipFee').optional().isDecimal()
];

// Routes
router.get('/', getAssociations);
router.get('/:id', getAssociationById);
router.get('/:id/members', getAssociationMembers);

// Federation routes
router.post('/', createAssociationValidation, validateRequest, requireFederation, createAssociation);
router.put('/:id', createAssociationValidation, validateRequest, requireFederation, updateAssociation);
router.delete('/:id', requireFederation, deleteAssociation);

// Member management
router.post('/:id/members', requireFederation, addAssociationMember);
router.delete('/:id/members/:userId', requireFederation, removeAssociationMember);

export default router;
