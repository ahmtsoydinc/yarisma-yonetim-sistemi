import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';

export const getUsers = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, role, isActive } = req.query;
    
    const where: any = {};
    if (role) where.role = role;
    if (isActive !== undefined) where.isActive = isActive === 'true';

    const users = await prisma.user.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        createdAt: true,
        federation: {
          select: { id: true, name: true }
        },
        association: {
          select: { id: true, name: true }
        }
      }
    });

    const total = await prisma.user.count({ where });

    return res.json({
      users,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
};

export const getUserById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const user = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        createdAt: true,
        federation: {
          select: { id: true, name: true }
        },
        association: {
          select: { id: true, name: true }
        }
      }
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    return res.json({ user });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
};

export const createUser = async (req: Request, res: Response) => {
  try {
    const { email, password, firstName, lastName, role, phone, federationId, associationId } = req.body;

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        firstName,
        lastName,
        role,
        phone,
        federationId,
        associationId,
        isApproved: role !== 'MEMBER' // MEMBER dışındaki roller otomatik onaylı
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        isApproved: true,
        createdAt: true,
        federation: {
          select: { id: true, name: true }
        },
        association: {
          select: { id: true, name: true }
        }
      }
    });

    return res.status(201).json({ user });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
};

export const updateUser = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { firstName, lastName, role, phone, isActive } = req.body;

    const user = await prisma.user.update({
      where: { id },
      data: {
        firstName,
        lastName,
        role,
        phone,
        isActive
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        isApproved: true,
        createdAt: true,
        federation: {
          select: { id: true, name: true }
        },
        association: {
          select: { id: true, name: true }
        }
      }
    });

    return res.json({ user });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
};

export const deleteUser = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await prisma.user.delete({
      where: { id }
    });

    return res.json({ message: 'User deleted successfully' });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
};

// Kullanıcı onaylama fonksiyonu (Başkan için)
export const approveUser = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = (req as any).user; // Auth middleware'den gelen user ID

    // Başkan mı kontrol et
    const president = await prisma.user.findUnique({
      where: { id: userId },
      include: { presidencyAssociation: true }
    });

    if (!president || president.role !== 'PRESIDENT') {
      throw createError('Sadece başkanlar kullanıcı onaylayabilir', 403);
    }

    // Onaylanacak kullanıcıyı bul
    const userToApprove = await prisma.user.findUnique({
      where: { id },
      include: { association: true }
    });

    if (!userToApprove) {
      throw createError('Kullanıcı bulunamadı', 404);
    }

    // Kullanıcı aynı derneğe mi ait kontrol et
    if (userToApprove.associationId !== president.presidencyAssociation?.id) {
      throw createError('Bu kullanıcı sizin derneğinize ait değil', 403);
    }

    // Kullanıcıyı onayla
    const approvedUser = await prisma.user.update({
      where: { id },
      data: {
        isApproved: true,
        approvedBy: userId,
        approvedAt: new Date()
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        isApproved: true,
        approvedAt: true,
        association: {
          select: { name: true }
        }
      }
    });

    return res.json({
      message: 'Kullanıcı başarıyla onaylandı',
      user: approvedUser
    });
  } catch (error: any) {
    return res.status(error.statusCode || 500).json({ error: error.message });
  }
};

// Bekleyen kullanıcıları getir (Başkan için)
export const getPendingUsers = async (req: Request, res: Response) => {
  try {
    const { userId } = (req as any).user;
    const { page = 1, limit = 10 } = req.query;

    // Başkan mı kontrol et
    const president = await prisma.user.findUnique({
      where: { id: userId },
      include: { presidencyAssociation: true }
    });

    if (!president || president.role !== 'PRESIDENT') {
      throw createError('Sadece başkanlar bu listeyi görebilir', 403);
    }

    const pendingUsers = await prisma.user.findMany({
      where: {
        associationId: president.presidencyAssociation?.id,
        isApproved: false,
        isActive: true
      },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        createdAt: true,
        association: {
          select: { name: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const total = await prisma.user.count({
      where: {
        associationId: president.presidencyAssociation?.id,
        isApproved: false,
        isActive: true
      }
    });

    return res.json({
      users: pendingUsers,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    return res.status(error.statusCode || 500).json({ error: error.message });
  }
};

// Dernek seçimi ile giriş fonksiyonu
export const loginWithAssociation = async (req: Request, res: Response) => {
  try {
    const { email, password, associationId } = req.body;

    // Find user
    const user = await prisma.user.findUnique({
      where: { email },
      include: {
        federation: true,
        association: true
      }
    });

    if (!user || !user.isActive) {
      throw createError('Invalid credentials', 401);
    }

    // Check if user is approved (except for SUPERADMIN, FEDERATION, PRESIDENT, JUDGE)
    if (user.role === 'MEMBER' && !user.isApproved) {
      throw createError('Hesabınız henüz onaylanmamış. Dernek başkanınızla iletişime geçin.', 403);
    }

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      throw createError('Invalid credentials', 401);
    }

    // If associationId provided, verify user belongs to that association
    if (associationId && user.associationId !== associationId) {
      throw createError('Seçilen dernek ile kullanıcı derneği uyuşmuyor', 403);
    }

    // Generate JWT
    const payload: any = {
      userId: user.id,
      email: user.email,
      role: user.role,
    };
    const token = jwt.sign(payload, process.env.JWT_SECRET!, { expiresIn: '1h' });

    // Exclude password from user object before sending
    const { password: _, ...userWithoutPassword } = user;

    return res.json({
      message: 'Login successful',
      token,
      user: userWithoutPassword,
    });
  } catch (error: any) {
    return res.status(error.statusCode || 500).json({ error: error.message || 'Login failed' });
  }
};