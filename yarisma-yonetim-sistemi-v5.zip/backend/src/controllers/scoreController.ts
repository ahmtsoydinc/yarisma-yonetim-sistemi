import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';
// import { AuthRequest } from '../types';

export const getScores = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, competitionId, registrationId } = req.query;
    
    const where: any = {};
    if (competitionId) {
      where.registration = { competitionId };
    }
    if (registrationId) where.registrationId = registrationId;

    const scores = await prisma.score.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        registration: {
          include: {
            animal: {
              include: {
                animalType: true,
                animalColor: true,
                owner: {
                  select: { id: true, firstName: true, lastName: true }
                }
              }
            },
            competition: {
              select: { id: true, name: true }
            }
          }
        },
        judge: {
          select: { id: true, firstName: true, lastName: true }
        },
        awards: true
      },
      orderBy: { totalScore: 'desc' }
    });

    const total = await prisma.score.count({ where });

    res.json({
      scores,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getJudgeScores = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const judgeId = (req as any).user!.userId;

    const scores = await prisma.score.findMany({
      where: { judgeId },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        registration: {
          include: {
            animal: {
              include: {
                animalType: true,
                animalColor: true,
                owner: {
                  select: { id: true, firstName: true, lastName: true }
                }
              }
            },
            competition: {
              select: { id: true, name: true, status: true }
            },
            cage: true
          }
        },
        awards: true
      },
      orderBy: { createdAt: 'desc' }
    });

    const total = await prisma.score.count({ where: { judgeId } });

    res.json({
      scores,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getScoreById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const score = await prisma.score.findUnique({
      where: { id },
      include: {
        registration: {
          include: {
            animal: {
              include: {
                animalType: true,
                animalColor: true,
                owner: {
                  select: { id: true, firstName: true, lastName: true }
                }
              }
            },
            competition: {
              select: { id: true, name: true }
            }
          }
        },
        judge: {
          select: { id: true, firstName: true, lastName: true }
        },
        awards: true
      }
    });

    if (!score) {
      throw createError('Score not found', 404);
    }

    res.json({ score });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createScore = async (req: Request, res: Response) => {
  try {
    const { registrationId, appearanceScore, conditionScore, breedStandardScore, notes } = req.body;
    const judgeId = (req as any).user!.userId;

    // Check if score already exists for this registration and judge
    const existingScore = await prisma.score.findUnique({
      where: {
        registrationId_judgeId: {
          registrationId,
          judgeId
        }
      }
    });

    if (existingScore) {
      throw createError('Bu kayıt için zaten puan vermişsiniz', 400);
    }

    // Calculate total score
    const totalScore = appearanceScore + conditionScore + breedStandardScore;

    const score = await prisma.score.create({
      data: {
        registrationId,
        judgeId,
        appearanceScore,
        conditionScore,
        breedStandardScore,
        totalScore,
        notes
      },
      include: {
        registration: {
          include: {
            animal: {
              include: {
                animalType: true,
                animalColor: true,
                owner: {
                  select: { id: true, firstName: true, lastName: true }
                }
              }
            }
          }
        }
      }
    });

    res.status(201).json({
      message: 'Puan başarıyla kaydedildi',
      score
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateScore = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { appearanceScore, conditionScore, breedStandardScore, notes } = req.body;
    const judgeId = (req as any).user!.userId;

    // Check if score exists and belongs to this judge
    const existingScore = await prisma.score.findUnique({
      where: { id }
    });

    if (!existingScore) {
      throw createError('Score not found', 404);
    }

    if (existingScore.judgeId !== judgeId) {
      throw createError('Bu puanı güncelleme yetkiniz yok', 403);
    }

    // Calculate total score
    const totalScore = appearanceScore + conditionScore + breedStandardScore;

    const score = await prisma.score.update({
      where: { id },
      data: {
        appearanceScore,
        conditionScore,
        breedStandardScore,
        totalScore,
        notes
      },
      include: {
        registration: {
          include: {
            animal: {
              include: {
                animalType: true,
                animalColor: true,
                owner: {
                  select: { id: true, firstName: true, lastName: true }
                }
              }
            }
          }
        }
      }
    });

    res.json({
      message: 'Puan başarıyla güncellendi',
      score
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteScore = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const judgeId = (req as any).user!.userId;

    // Check if score exists and belongs to this judge
    const existingScore = await prisma.score.findUnique({
      where: { id }
    });

    if (!existingScore) {
      throw createError('Score not found', 404);
    }

    if (existingScore.judgeId !== judgeId) {
      throw createError('Bu puanı silme yetkiniz yok', 403);
    }

    await prisma.score.delete({
      where: { id }
    });

    res.json({ message: 'Puan başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const addAward = async (req: Request, res: Response) => {
  try {
    const { scoreId } = req.params;
    const { type, name, description } = req.body;
    const judgeId = (req as any).user!.userId;

    // Check if score exists and belongs to this judge
    const score = await prisma.score.findUnique({
      where: { id: scoreId }
    });

    if (!score) {
      throw createError('Score not found', 404);
    }

    if (score.judgeId !== judgeId) {
      throw createError('Bu puan için ödül ekleme yetkiniz yok', 403);
    }

    const award = await prisma.award.create({
      data: {
        scoreId,
        type,
        name,
        description
      }
    });

    res.status(201).json({
      message: 'Ödül başarıyla eklendi',
      award
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};
