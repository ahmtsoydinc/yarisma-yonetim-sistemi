import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';

export const getAnimalTypes = async (req: Request, res: Response) => {
  try {
    const animalTypes = await prisma.animalType.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' }
    });

    res.json({ animalTypes });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getAnimalTypeById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const animalType = await prisma.animalType.findUnique({
      where: { id }
    });

    if (!animalType) {
      throw createError('Hayvan türü bulunamadı', 404);
    }

    res.json({ animalType });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createAnimalType = async (req: Request, res: Response) => {
  try {
    const { name, description } = req.body;

    // Check if animal type already exists
    const existingType = await prisma.animalType.findUnique({
      where: { name }
    });

    if (existingType) {
      throw createError('Bu hayvan türü zaten mevcut', 400);
    }

    const animalType = await prisma.animalType.create({
      data: {
        name,
        description
      }
    });

    res.status(201).json({
      message: 'Hayvan türü başarıyla oluşturuldu',
      animalType
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateAnimalType = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, description, isActive } = req.body;

    const animalType = await prisma.animalType.update({
      where: { id },
      data: {
        name,
        description,
        isActive
      }
    });

    res.json({
      message: 'Hayvan türü başarıyla güncellendi',
      animalType
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteAnimalType = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Check if animal type is used by any animals
    const animalCount = await prisma.animal.count({
      where: { animalTypeId: id }
    });

    if (animalCount > 0) {
      throw createError('Bu hayvan türü kullanımda olduğu için silinemez', 400);
    }

    await prisma.animalType.delete({
      where: { id }
    });

    res.json({ message: 'Hayvan türü başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getAnimalColors = async (req: Request, res: Response) => {
  try {
    // Mock data for colors
    const animalColors = [
      { id: '1', name: 'Beyaz', code: '#FFFFFF', animalTypeId: '1', isActive: true },
      { id: '2', name: 'Siyah', code: '#000000', animalTypeId: '1', isActive: true },
      { id: '3', name: 'Kahverengi', code: '#8B4513', animalTypeId: '1', isActive: true },
      { id: '4', name: 'Kırmızı', code: '#FF0000', animalTypeId: '1', isActive: true },
      { id: '5', name: 'Gri', code: '#808080', animalTypeId: '1', isActive: true }
    ];

    res.json({ animalColors });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const createAnimalColor = async (req: Request, res: Response) => {
  try {
    const { name, code, description, animalTypeId } = req.body;

    // Mock response
    const animalColor = {
      id: Date.now().toString(),
      name,
      code,
      description,
      animalTypeId,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    res.status(201).json({
      message: 'Hayvan rengi başarıyla oluşturuldu',
      animalColor
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateAnimalColor = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, code, description, isActive } = req.body;

    // Mock response
    const animalColor = {
      id,
      name,
      code,
      description,
      isActive,
      updatedAt: new Date()
    };

    res.json({
      message: 'Hayvan rengi başarıyla güncellendi',
      animalColor
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteAnimalColor = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Mock response
    res.json({ message: 'Hayvan rengi başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};
