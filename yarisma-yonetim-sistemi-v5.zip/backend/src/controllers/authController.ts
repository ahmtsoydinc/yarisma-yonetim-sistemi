import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/database';
import { JWTPayload, AuthRequest } from '../types';
import { createError } from '../middleware/errorHandler';

interface RegisterRequest extends Request {
  body: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    role: string;
    phone?: string;
    federationId?: string;
    associationId?: string;
  };
}

interface LoginRequest extends Request {
  body: {
    email: string;
    password: string;
    associationId?: string;
  };
}

export const register = async (req: RegisterRequest, res: Response) => {
  try {
    const { email, password, firstName, lastName, role, phone, federationId, associationId } = req.body;

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      throw createError('User already exists with this email', 400);
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        firstName,
        lastName,
        role,
        phone,
        federationId,
        associationId
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        createdAt: true
      }
    });

    res.status(201).json({
      message: 'User created successfully',
      user
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({
      error: error.message || 'Registration failed'
    });
  }
};

export const login = async (req: LoginRequest, res: Response) => {
  try {
    const { email, password, associationId } = req.body;

    // Find user
    const user = await prisma.user.findUnique({
      where: { email },
      include: {
        federation: true,
        association: true
      }
    });

    if (!user || !user.isActive) {
      throw createError('Invalid credentials', 401);
    }

    // Check if user is approved (except for SUPERADMIN, FEDERATION, PRESIDENT, JUDGE)
    if (user.role === 'MEMBER' && !user.isApproved) {
      throw createError('Hesabınız henüz onaylanmamış. Dernek başkanınızla iletişime geçin.', 403);
    }

    // TSHF seçimi kontrolü - SUPERADMIN, FEDERATION, JUDGE için TSHF seçimi varsa kontrol et
    if (associationId === 'TSHF' && ['SUPERADMIN', 'FEDERATION', 'JUDGE'].includes(user.role)) {
      // TSHF seçimi yapıldı, bu kullanıcılar TSHF'ye bağlı olmalı
      if (!user.federationId) {
        throw createError('Bu kullanıcı TSHF\'ye bağlı değil', 403);
      }
    }

    // Dernek seçimi kontrolü - MEMBER ve PRESIDENT için dernek seçimi zorunlu
    if (['MEMBER', 'PRESIDENT'].includes(user.role) && associationId && associationId !== 'TSHF') {
      if (user.associationId !== associationId) {
        throw createError('Seçilen dernek ile kullanıcı derneği uyuşmuyor', 403);
      }
    }

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      throw createError('Invalid credentials', 401);
    }

    // Generate JWT
    const payload: JWTPayload = {
      userId: user.id,
      email: user.email,
      role: user.role
    };

    const secret = process.env.JWT_SECRET || 'fallback-secret';
    const token = jwt.sign(payload, secret);

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        phone: user.phone,
        federation: user.federation,
        association: user.association
      }
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({
      error: error.message || 'Login failed'
    });
  }
};

export const getProfile = async (req: Request, res: Response) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: (req as any).user!.userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        createdAt: true,
        federation: true,
        association: true
      }
    });

    if (!user) {
      throw createError('User not found', 404);
    }

    res.json({ user });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({
      error: error.message || 'Failed to get profile'
    });
  }
};

export const updateProfile = async (req: Request, res: Response) => {
  try {
    const { firstName, lastName, phone } = req.body;
    const userId = (req as any).user!.userId;

    const user = await prisma.user.update({
      where: { id: userId },
      data: {
        firstName,
        lastName,
        phone
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        updatedAt: true
      }
    });

    res.json({
      message: 'Profile updated successfully',
      user
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({
      error: error.message || 'Failed to update profile'
    });
  }
};
