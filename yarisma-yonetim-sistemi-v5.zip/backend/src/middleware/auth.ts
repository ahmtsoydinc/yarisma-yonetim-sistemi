import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { UserRole, JWTPayload, AuthenticatedRequest } from '../types';

export interface AuthRequest extends Request {
  user?: JWTPayload;
}

export const authenticateToken = (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    res.status(401).json({ error: 'Access token required' });
    return;
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as JWTPayload;
    req.user = decoded;
    next();
  } catch (error) {
    res.status(403).json({ error: 'Invalid or expired token' });
    return;
  }
};

export const requireRole = (...roles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: 'Insufficient permissions' });
      return;
    }

    next();
  };
};

export const requireSuperAdmin = requireRole('SUPERADMIN');
export const requireFederation = requireRole('SUPERADMIN', 'FEDERATION');
export const requirePresident = requireRole('SUPERADMIN', 'FEDERATION', 'PRESIDENT');
export const requireJudge = requireRole('SUPERADMIN', 'FEDERATION', 'JUDGE');
export const requireMember = requireRole('SUPERADMIN', 'FEDERATION', 'PRESIDENT', 'MEMBER');