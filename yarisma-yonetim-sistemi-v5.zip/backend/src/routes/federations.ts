import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getFederations, 
  getFederationById, 
  createFederation, 
  updateFederation, 
  deleteFederation,
  getFederationAssociations,
  getFederationStats
} from '../controllers/federationController';
import { authenticateToken, requireSuperAdmin, requireFederation } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createFederationValidation = [
  body('name').notEmpty().trim(),
  body('description').optional().trim(),
  body('address').optional().trim(),
  body('phone').optional().trim(),
  body('email').optional().isEmail()
];

// Routes
router.get('/', getFederations);
router.get('/:id', getFederationById);
router.get('/:id/associations', getFederationAssociations);
router.get('/:id/stats', getFederationStats);

// Superadmin routes
router.post('/', createFederationValidation, validateRequest, requireSuperAdmin, createFederation);
router.put('/:id', createFederationValidation, validateRequest, requireSuperAdmin, updateFederation);
router.delete('/:id', requireSuperAdmin, deleteFederation);

// Federation routes (own federation only)
router.put('/my', createFederationValidation, validateRequest, requireFederation, updateFederation);

export default router;
