import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getPresidents, 
  getPresidentById, 
  createPresident, 
  updatePresident, 
  deletePresident,
  togglePresidentStatus,
  getAvailableAssociations
} from '../controllers/presidentController';
import { authenticateToken, requireSuperAdmin } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createPresidentValidation = [
  body('email').isEmail().withMessage('Geçerli bir e-posta adresi giriniz'),
  body('password').isLength({ min: 6 }).withMessage('Şifre en az 6 karakter olmalıdır'),
  body('firstName').notEmpty().withMessage('Ad zorunludur'),
  body('lastName').notEmpty().withMessage('Soyad zorunludur'),
  body('associationId').isUUID().withMessage('Geçerli bir dernek ID seçiniz'),
  body('phone').optional().isMobilePhone('tr-TR').withMessage('Geçerli bir telefon numarası giriniz'),
  body('isActive').optional().isBoolean().withMessage('Aktif durumu boolean olmalıdır'),
];

const updatePresidentValidation = [
  body('firstName').optional().notEmpty().withMessage('Ad boş olamaz'),
  body('lastName').optional().notEmpty().withMessage('Soyad boş olamaz'),
  body('associationId').optional().isUUID().withMessage('Geçerli bir dernek ID seçiniz'),
  body('phone').optional().isMobilePhone('tr-TR').withMessage('Geçerli bir telefon numarası giriniz'),
  body('isActive').optional().isBoolean().withMessage('Aktif durumu boolean olmalıdır'),
];

// Superadmin only routes
router.get('/', requireSuperAdmin, getPresidents);
router.get('/available-associations', requireSuperAdmin, getAvailableAssociations);
router.get('/:id', requireSuperAdmin, getPresidentById);
router.post('/', createPresidentValidation, validateRequest, requireSuperAdmin, createPresident);
router.put('/:id', updatePresidentValidation, validateRequest, requireSuperAdmin, updatePresident);
router.delete('/:id', requireSuperAdmin, deletePresident);
router.patch('/:id/toggle-status', requireSuperAdmin, togglePresidentStatus);

export default router;
