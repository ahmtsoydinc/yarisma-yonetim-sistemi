export enum UserRole {
  SUPERADMIN = 'SUPERADMIN',
  FEDERATION = 'FEDERATION',
  PRESIDENT = 'PRESIDENT',
  JUDGE = 'JUDGE',
  MEMBER = 'MEMBER'
}

export enum AnimalBreed {
  TAVUK = 'TAVUK',
  HOROZ = 'HOROZ',
  GUVERCIN = 'GUVERCIN',
  KAZ = 'KAZ',
  ORDEK = 'ORDEK',
  HINDI = 'HINDI',
  TAVSAN = 'TAVSAN'
}

export enum CompetitionStatus {
  PLANNED = 'PLANNED',
  ACTIVE = 'ACTIVE',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum AnimalRegistrationStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  PARTICIPATING = 'PARTICIPATING',
  COMPLETED = 'COMPLETED'
}

export enum AwardType {
  FIRST_PLACE = 'FIRST_PLACE',
  SECOND_PLACE = 'SECOND_PLACE',
  THIRD_PLACE = 'THIRD_PLACE',
  HONORABLE_MENTION = 'HONORABLE_MENTION',
  SPECIAL_AWARD = 'SPECIAL_AWARD'
}

export interface JWTPayload {
  userId: string;
  email: string;
  role: string;
}

export interface AuthRequest extends Request {
  user?: JWTPayload;
}

export interface AuthenticatedRequest extends Request {
  user?: JWTPayload;
}
