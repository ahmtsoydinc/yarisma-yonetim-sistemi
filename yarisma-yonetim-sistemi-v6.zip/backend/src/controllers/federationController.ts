import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';

export const getFederations = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, isActive } = req.query;
    
    const where: any = {};
    if (isActive !== undefined) where.isActive = isActive === 'true';

    const federations = await prisma.federation.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        _count: {
          select: { associations: true, users: true, competitions: true }
        }
      },
      orderBy: { name: 'asc' }
    });

    const total = await prisma.federation.count({ where });

    res.json({
      federations,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getFederationById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const federation = await prisma.federation.findUnique({
      where: { id },
      include: {
        associations: {
          include: {
            president: {
              select: { id: true, firstName: true, lastName: true, email: true }
            },
            _count: {
              select: { users: true }
            }
          }
        },
        users: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            role: true,
            isActive: true
          }
        },
        competitions: {
          select: {
            id: true,
            name: true,
            status: true,
            startDate: true,
            endDate: true,
            _count: {
              select: { registrations: true }
            }
          }
        }
      }
    });

    if (!federation) {
      throw createError('Federation not found', 404);
    }

    res.json({ federation });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createFederation = async (req: Request, res: Response) => {
  try {
    const { name, description } = req.body;

    const federation = await prisma.federation.create({
      data: {
        name,
        description
      }
    });

    res.status(201).json({
      message: 'Federasyon başarıyla oluşturuldu',
      federation
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateFederation = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, description, isActive } = req.body;

    const federation = await prisma.federation.update({
      where: { id },
      data: {
        name,
        description,
        isActive
      }
    });

    res.json({
      message: 'Federasyon başarıyla güncellendi',
      federation
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteFederation = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await prisma.federation.delete({
      where: { id }
    });

    res.json({ message: 'Federasyon başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getFederationAssociations = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { page = 1, limit = 10, isActive } = req.query;

    const where: any = { federationId: id };
    if (isActive !== undefined) where.isActive = isActive === 'true';

    const associations = await prisma.association.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        president: {
          select: { id: true, firstName: true, lastName: true, email: true }
        },
        _count: {
          select: { users: true }
        }
      },
      orderBy: { name: 'asc' }
    });

    const total = await prisma.association.count({ where });

    res.json({
      associations,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getFederationStats = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const [
      totalAssociations,
      activeAssociations,
      totalMembers,
      activeMembers,
      totalAnimals,
      totalCompetitions,
      activeCompetitions,
      completedCompetitions
    ] = await Promise.all([
      prisma.association.count({ where: { federationId: id } }),
      prisma.association.count({ where: { federationId: id, isActive: true } }),
      prisma.user.count({ where: { federationId: id } }),
      prisma.user.count({ where: { federationId: id, isActive: true } }),
      prisma.animal.count({
        where: {
          federationId: id
        }
      }),
      prisma.competition.count({ where: { federationId: id } }),
      prisma.competition.count({ where: { federationId: id, status: 'ACTIVE' } }),
      prisma.competition.count({ where: { federationId: id, status: 'COMPLETED' } })
    ]);

    const stats = {
      associations: {
        total: totalAssociations,
        active: activeAssociations,
        inactive: totalAssociations - activeAssociations
      },
      members: {
        total: totalMembers,
        active: activeMembers,
        inactive: totalMembers - activeMembers
      },
      animals: {
        total: totalAnimals
      },
      competitions: {
        total: totalCompetitions,
        active: activeCompetitions,
        completed: completedCompetitions
      }
    };

    res.json({ stats });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};
