import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getPages, 
  getPageById, 
  createPage, 
  updatePage, 
  deletePage,
  getPagePermissions,
  updatePagePermissions,
  getUserVisiblePages,
  getPageAccessByRole
} from '../controllers/pageController';
import { authenticateToken, requireSuperAdmin } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createPageValidation = [
  body('name').notEmpty().withMessage('Sayfa adı zorunludur'),
  body('title').notEmpty().withMessage('Sayfa başlığı zorunludur'),
  body('path').notEmpty().withMessage('Sayfa yolu zorunludur'),
  body('icon').optional().trim(),
  body('color').optional().trim(),
  body('shape').optional().trim(),
  body('description').optional().trim(),
  body('isActive').optional().isBoolean(),
  body('isVisible').optional().isBoolean(),
  body('order').optional().isInt({ min: 0 }),
  body('permissions').optional().isArray()
];

const updatePageValidation = [
  body('name').optional().notEmpty().withMessage('Sayfa adı boş olamaz'),
  body('title').optional().notEmpty().withMessage('Sayfa başlığı boş olamaz'),
  body('path').optional().notEmpty().withMessage('Sayfa yolu boş olamaz'),
  body('icon').optional().trim(),
  body('color').optional().trim(),
  body('shape').optional().trim(),
  body('description').optional().trim(),
  body('isActive').optional().isBoolean(),
  body('isVisible').optional().isBoolean(),
  body('order').optional().isInt({ min: 0 }),
  body('permissions').optional().isArray()
];

// Superadmin only routes
router.get('/', requireSuperAdmin, getPages);
router.get('/:id', requireSuperAdmin, getPageById);
router.post('/', createPageValidation, validateRequest, requireSuperAdmin, createPage);
router.put('/:id', updatePageValidation, validateRequest, requireSuperAdmin, updatePage);
router.delete('/:id', requireSuperAdmin, deletePage);

// Page permissions routes
router.get('/:pageId/permissions', requireSuperAdmin, getPagePermissions);
router.put('/:pageId/permissions', requireSuperAdmin, updatePagePermissions);

// User visible pages routes
router.get('/user/visible', authenticateToken, getUserVisiblePages);
router.get('/role/:role', authenticateToken, getPageAccessByRole);

export default router;
