import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getAnimals, 
  getAnimalById, 
  createAnimal, 
  updateAnimal, 
  deleteAnimal,
  importAnimalTypes,
  importAnimalColors 
} from '../controllers/animalController';
import { authenticateToken, requireMember } from '../middleware/auth';
import { requireSuperAdmin } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';
import { uploadSingle } from '../middleware/upload';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createAnimalValidation = [
  body('ringNumber').notEmpty().trim(),
  body('name').optional().trim(),
  body('gender').optional().trim(),
  body('animalTypeId').isUUID(),
  body('animalColorId').isUUID()
];

// Routes
router.get('/', requireMember, getAnimals);
router.get('/:id', requireMember, getAnimalById);
router.post('/', createAnimalValidation, validateRequest, requireMember, createAnimal);
router.put('/:id', createAnimalValidation, validateRequest, requireMember, updateAnimal);
router.delete('/:id', requireMember, deleteAnimal);

// Admin only routes
router.post('/import/types', requireSuperAdmin, uploadSingle('file'), importAnimalTypes);
router.post('/import/colors', requireSuperAdmin, uploadSingle('file'), importAnimalColors);

export default router;
