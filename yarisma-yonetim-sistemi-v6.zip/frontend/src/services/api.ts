import axios from 'axios';
import { AuthResponse, LoginRequest, RegisterRequest } from '../types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Axios instance
export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: async (credentials: LoginRequest): Promise<AuthResponse> => {
    const response = await api.post('/auth/login', credentials);
    return response.data;
  },

  loginWithAssociation: async (credentials: LoginRequest & { associationId?: string }): Promise<AuthResponse> => {
    const response = await api.post('/auth/login-with-association', credentials);
    return response.data;
  },

  register: async (userData: RegisterRequest): Promise<{ message: string; user: any }> => {
    const response = await api.post('/auth/register', userData);
    return response.data;
  },

  getProfile: async (): Promise<{ user: any }> => {
    const response = await api.get('/auth/profile');
    return response.data;
  },

  updateProfile: async (userData: any): Promise<{ message: string; user: any }> => {
    const response = await api.put('/auth/profile', userData);
    return response.data;
  },
};

// Users API
export const usersAPI = {
  getUsers: async (params?: any): Promise<{ users: any[]; pagination: any }> => {
    const response = await api.get('/users', { params });
    return response.data;
  },

  getUserById: async (id: string): Promise<{ user: any }> => {
    const response = await api.get(`/users/${id}`);
    return response.data;
  },

  createUser: async (userData: any): Promise<{ message: string; user: any }> => {
    const response = await api.post('/users', userData);
    return response.data;
  },

  updateUser: async (id: string, userData: any): Promise<{ message: string; user: any }> => {
    const response = await api.put(`/users/${id}`, userData);
    return response.data;
  },

  deleteUser: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/users/${id}`);
    return response.data;
  },
};

// Animals API
export const animalsAPI = {
  getAnimals: async (params?: any): Promise<{ animals: any[]; pagination?: any }> => {
    const response = await api.get('/animals', { params });
    return response.data;
  },

  getAnimalById: async (id: string): Promise<{ animal: any }> => {
    const response = await api.get(`/animals/${id}`);
    return response.data;
  },

  createAnimal: async (animalData: any): Promise<{ message: string; animal: any }> => {
    const response = await api.post('/animals', animalData);
    return response.data;
  },

  updateAnimal: async (id: string, animalData: any): Promise<{ message: string; animal: any }> => {
    const response = await api.put(`/animals/${id}`, animalData);
    return response.data;
  },

  deleteAnimal: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/animals/${id}`);
    return response.data;
  },

  importTypes: async (file: File): Promise<{ message: string }> => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await api.post('/animals/import/types', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },

  importColors: async (file: File): Promise<{ message: string }> => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await api.post('/animals/import/colors', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },
};

// Animal Types API
export const animalTypesAPI = {
  getAnimalTypes: async (params?: any): Promise<{ animalTypes: any[] }> => {
    const response = await api.get('/animal-types/types', { params });
    return response.data;
  },

  getAnimalTypeById: async (id: string): Promise<{ animalType: any }> => {
    const response = await api.get(`/animal-types/types/${id}`);
    return response.data;
  },

  createAnimalType: async (animalTypeData: any): Promise<{ message: string; animalType: any }> => {
    const response = await api.post('/animal-types/types', animalTypeData);
    return response.data;
  },

  updateAnimalType: async (id: string, animalTypeData: any): Promise<{ message: string; animalType: any }> => {
    const response = await api.put(`/animal-types/types/${id}`, animalTypeData);
    return response.data;
  },

  deleteAnimalType: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/animal-types/types/${id}`);
    return response.data;
  },

  getAnimalColors: async (params?: any): Promise<{ animalColors: any[] }> => {
    const response = await api.get('/animal-types/colors', { params });
    return response.data;
  },

  createAnimalColor: async (animalColorData: any): Promise<{ message: string; animalColor: any }> => {
    const response = await api.post('/animal-types/colors', animalColorData);
    return response.data;
  },

  updateAnimalColor: async (id: string, animalColorData: any): Promise<{ message: string; animalColor: any }> => {
    const response = await api.put(`/animal-types/colors/${id}`, animalColorData);
    return response.data;
  },

  deleteAnimalColor: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/animal-types/colors/${id}`);
    return response.data;
  },
};

// Pages API
export const pagesAPI = {
  getPages: async (params?: any): Promise<{ pages: any[] }> => {
    const response = await api.get('/pages', { params });
    return response.data;
  },

  getPageById: async (id: string): Promise<{ page: any }> => {
    const response = await api.get(`/pages/${id}`);
    return response.data;
  },

  createPage: async (pageData: any): Promise<{ message: string; page: any }> => {
    const response = await api.post('/pages', pageData);
    return response.data;
  },

  updatePage: async (id: string, pageData: any): Promise<{ message: string; page: any }> => {
    const response = await api.put(`/pages/${id}`, pageData);
    return response.data;
  },

  deletePage: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/pages/${id}`);
    return response.data;
  },

  getPagePermissions: async (pageId: string): Promise<{ permissions: any[] }> => {
    const response = await api.get(`/pages/${pageId}/permissions`);
    return response.data;
  },

  updatePagePermissions: async (pageId: string, permissions: any[]): Promise<{ message: string }> => {
    const response = await api.put(`/pages/${pageId}/permissions`, { permissions });
    return response.data;
  },

  getUserVisiblePages: async (): Promise<{ pages: any[] }> => {
    const response = await api.get('/pages/user/visible');
    return response.data;
  },

  getPageAccessByRole: async (role: string): Promise<{ role: string; pages: any[]; totalPages: number }> => {
    const response = await api.get(`/pages/role/${role}`);
    return response.data;
  },
};

// Presidents API
export const presidentsAPI = {
  getPresidents: async (params?: any): Promise<{ presidents: any[]; pagination: any }> => {
    const response = await api.get('/presidents', { params });
    return response.data;
  },

  getPresidentById: async (id: string): Promise<{ president: any }> => {
    const response = await api.get(`/presidents/${id}`);
    return response.data;
  },

  createPresident: async (presidentData: any): Promise<{ message: string; president: any }> => {
    const response = await api.post('/presidents', presidentData);
    return response.data;
  },

  updatePresident: async (id: string, presidentData: any): Promise<{ message: string; president: any }> => {
    const response = await api.put(`/presidents/${id}`, presidentData);
    return response.data;
  },

  deletePresident: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/presidents/${id}`);
    return response.data;
  },

  togglePresidentStatus: async (id: string): Promise<{ message: string; president: any }> => {
    const response = await api.patch(`/presidents/${id}/toggle-status`);
    return response.data;
  },

  getAvailableAssociations: async (): Promise<{ associations: any[] }> => {
    const response = await api.get('/presidents/available-associations');
    return response.data;
  },
};

// Competitions API
export const competitionsAPI = {
  getCompetitions: async (params?: any): Promise<{ competitions: any[]; pagination: any }> => {
    const response = await api.get('/competitions', { params });
    return response.data;
  },

  getCompetitionById: async (id: string): Promise<{ competition: any }> => {
    const response = await api.get(`/competitions/${id}`);
    return response.data;
  },

  createCompetition: async (competitionData: any): Promise<{ message: string; competition: any }> => {
    const response = await api.post('/competitions', competitionData);
    return response.data;
  },

  updateCompetition: async (id: string, competitionData: any): Promise<{ message: string; competition: any }> => {
    const response = await api.put(`/competitions/${id}`, competitionData);
    return response.data;
  },

  deleteCompetition: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/competitions/${id}`);
    return response.data;
  },

  updateCompetitionStatus: async (id: string, status: string): Promise<{ message: string; competition: any }> => {
    const response = await api.patch(`/competitions/${id}/status`, { status });
    return response.data;
  },

  getCompetitionStats: async (id: string): Promise<{ stats: any }> => {
    const response = await api.get(`/competitions/${id}/stats`);
    return response.data;
  },

  getAvailableFederations: async (): Promise<{ federations: any[] }> => {
    const response = await api.get('/competitions/available-federations');
    return response.data;
  },

  getRegistrations: async (id: string): Promise<{ registrations: any[] }> => {
    const response = await api.get(`/competitions/${id}/registrations`);
    return response.data;
  },

  approveRegistration: async (competitionId: string, registrationId: string): Promise<{ message: string }> => {
    const response = await api.put(`/competitions/${competitionId}/registrations/${registrationId}/approve`);
    return response.data;
  },
};

// Associations API
export const associationsAPI = {
  getAssociations: async (params?: any): Promise<{ associations: any[] }> => {
    const response = await api.get('/associations', { params });
    return response.data;
  },

  getAssociationById: async (id: string): Promise<{ association: any }> => {
    const response = await api.get(`/associations/${id}`);
    return response.data;
  },

  createAssociation: async (associationData: any): Promise<{ message: string; association: any }> => {
    const response = await api.post('/associations', associationData);
    return response.data;
  },

  updateAssociation: async (id: string, associationData: any): Promise<{ message: string; association: any }> => {
    const response = await api.put(`/associations/${id}`, associationData);
    return response.data;
  },

  deleteAssociation: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/associations/${id}`);
    return response.data;
  },

  getMembers: async (id: string): Promise<{ members: any[] }> => {
    const response = await api.get(`/associations/${id}/members`);
    return response.data;
  },
};

// Federations API
export const federationsAPI = {
  getFederations: async (params?: any): Promise<{ federations: any[] }> => {
    const response = await api.get('/federations', { params });
    return response.data;
  },

  getFederationById: async (id: string): Promise<{ federation: any }> => {
    const response = await api.get(`/federations/${id}`);
    return response.data;
  },

  createFederation: async (federationData: any): Promise<{ message: string; federation: any }> => {
    const response = await api.post('/federations', federationData);
    return response.data;
  },

  updateFederation: async (id: string, federationData: any): Promise<{ message: string; federation: any }> => {
    const response = await api.put(`/federations/${id}`, federationData);
    return response.data;
  },

  deleteFederation: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/federations/${id}`);
    return response.data;
  },

  getAssociations: async (id: string): Promise<{ associations: any[] }> => {
    const response = await api.get(`/federations/${id}/associations`);
    return response.data;
  },

  getStats: async (id: string): Promise<{ stats: any }> => {
    const response = await api.get(`/federations/${id}/stats`);
    return response.data;
  },
};

// Scores API
export const scoresAPI = {
  getScores: async (params?: any): Promise<{ scores: any[] }> => {
    const response = await api.get('/scores', { params });
    return response.data;
  },

  getJudgeScores: async (): Promise<{ scores: any[] }> => {
    const response = await api.get('/scores/judge');
    return response.data;
  },

  getScoreById: async (id: string): Promise<{ score: any }> => {
    const response = await api.get(`/scores/${id}`);
    return response.data;
  },

  createScore: async (scoreData: any): Promise<{ message: string; score: any }> => {
    const response = await api.post('/scores', scoreData);
    return response.data;
  },

  updateScore: async (id: string, scoreData: any): Promise<{ message: string; score: any }> => {
    const response = await api.put(`/scores/${id}`, scoreData);
    return response.data;
  },

  deleteScore: async (id: string): Promise<{ message: string }> => {
    const response = await api.delete(`/scores/${id}`);
    return response.data;
  },

  addAward: async (scoreId: string, awardData: any): Promise<{ message: string; award: any }> => {
    const response = await api.post(`/scores/${scoreId}/awards`, awardData);
    return response.data;
  },
};

export default api;
