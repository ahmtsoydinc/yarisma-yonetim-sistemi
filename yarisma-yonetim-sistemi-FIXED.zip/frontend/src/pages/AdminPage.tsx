import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const AdminPage: React.FC = () => {
  const { user } = useAuth();

  if (user?.role !== 'SUPERADMIN') {
    return (
      <div className="admin-dashboard">
        <div className="access-denied">
          <h2>Erişim Reddedildi</h2>
          <p>Bu sayfaya erişim yetkiniz bulunmamaktadır.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      <div className="dashboard-header">
        <h1>Yönetici Paneli</h1>
        <p>Hoş geldiniz, {user?.firstName} {user?.lastName}</p>
      </div>
      
      <div className="dashboard-content">
        <div className="stats-grid">
          <div className="stat-card">
            <h3>Toplam Kullanıcılar</h3>
            <p className="stat-number">0</p>
          </div>
          <div className="stat-card">
            <h3>Toplam Hayvanlar</h3>
            <p className="stat-number">0</p>
          </div>
          <div className="stat-card">
            <h3>Aktif Yarışmalar</h3>
            <p className="stat-number">0</p>
          </div>
          <div className="stat-card">
            <h3>Toplam Dernekler</h3>
            <p className="stat-number">0</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
