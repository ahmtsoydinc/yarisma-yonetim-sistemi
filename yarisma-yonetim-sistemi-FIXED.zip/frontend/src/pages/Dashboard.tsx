import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  console.log('Dashboard - User:', user); // Debug log

  return (
    <div className="admin-dashboard">
      <div className="dashboard-header">
        <h1 className="dashboard-title">TSHF Süs Tavukları Yarışma Sistemi</h1>
        <p className="dashboard-subtitle">Türkiye Süs Tavukları ve Bahçe Hayvanları Federasyonu</p>
        <p className="dashboard-welcome">Hoş geldiniz, {user?.firstName} {user?.lastName}</p>
        <div className="role-badge">{user?.role}</div>
      </div>
      
      {user?.role === 'SUPERADMIN' && (
        <div className="admin-section">
          <h2>Yönetici Paneli</h2>
          <div className="dashboard-grid">
            <div className="dashboard-card" onClick={() => navigate('/admin')}>
              <h3>Sistem Ayarları</h3>
              <p>Kullanıcıları ve sistem ayarlarını yönetin</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/data-upload')}>
              <h3>Veri Yükleme</h3>
              <p>Hayvan cins ve renk verilerini yükleyin</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/admin')}>
              <h3>Sayfa Yönetimi</h3>
              <p>Sayfaları ekleyin ve düzenleyin</p>
            </div>
          </div>
        </div>
      )}

      {user?.role === 'FEDERATION' && (
        <div className="admin-section">
          <h2>Federasyon Paneli</h2>
          <div className="dashboard-grid">
            <div className="dashboard-card" onClick={() => navigate('/federation')}>
              <h3>Dernek Yönetimi</h3>
              <p>Kayıtlı dernekleri yönetin</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/federation')}>
              <h3>Yarışma Oluştur</h3>
              <p>Yeni yarışmalar ekleyin</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/federation')}>
              <h3>Yarışma Sonuçları</h3>
              <p>Sonuçları görüntüleyin ve yayınlayın</p>
            </div>
          </div>
        </div>
      )}

      {user?.role === 'PRESIDENT' && (
        <div className="admin-section">
          <h2>Başkan Paneli</h2>
          <div className="dashboard-grid">
            <div className="dashboard-card" onClick={() => navigate('/president')}>
              <h3>Üye Kayıtları</h3>
              <p>Yeni üyeleri sisteme kaydedin</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/president')}>
              <h3>Hayvan Onayları</h3>
              <p>Üyelerin hayvanlarını onaylayın</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/president')}>
              <h3>Bilezik Siparişleri</h3>
              <p>Bilezik siparişlerini takip edin</p>
            </div>
          </div>
        </div>
      )}

      {user?.role === 'JUDGE' && (
        <div className="admin-section">
          <h2>Hakem Paneli</h2>
          <div className="dashboard-grid">
            <div className="dashboard-card" onClick={() => navigate('/judge')}>
              <h3>Puanlama Yap</h3>
              <p>Hayvanları puanlayın</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/judge')}>
              <h3>Ödül Ekle</h3>
              <p>Puanlanan hayvanlara ödül verin</p>
            </div>
          </div>
        </div>
      )}

      {user?.role === 'MEMBER' && (
        <div className="admin-section">
          <h2>Üye Paneli</h2>
          <div className="dashboard-grid">
            <div className="dashboard-card" onClick={() => {
              console.log('Dashboard - MEMBER card clicked, navigating to /member');
              navigate('/member');
            }}>
              <h3>Hayvanlarım</h3>
              <p>Hayvanlarınızı yönetin</p>
            </div>
            <div className="dashboard-card" onClick={() => {
              console.log('Dashboard - MEMBER card clicked, navigating to /member');
              navigate('/member');
            }}>
              <h3>Yarışmalar</h3>
              <p>Yarışmalara kayıt olun</p>
            </div>
            <div className="dashboard-card" onClick={() => {
              console.log('Dashboard - MEMBER card clicked, navigating to /member');
              navigate('/member');
            }}>
              <h3>Sonuçlarım</h3>
              <p>Yarışma sonuçlarınızı görün</p>
            </div>
            <div className="dashboard-card" onClick={() => {
              console.log('Dashboard - MEMBER card clicked, navigating to /member');
              navigate('/member');
            }}>
              <h3>Profilim</h3>
              <p>Profil bilgilerinizi düzenleyin</p>
            </div>
          </div>
        </div>
      )}
      
      <div className="admin-section">
        <h2>Hesap Bilgileri</h2>
        <div className="user-info-grid">
          <div className="info-item">
            <label>E-posta:</label>
            <span>{user?.email}</span>
          </div>
          <div className="info-item">
            <label>Telefon:</label>
            <span>{user?.phone || 'Belirtilmemiş'}</span>
          </div>
          <div className="info-item">
            <label>Kayıt Tarihi:</label>
            <span>{user?.createdAt ? new Date(user.createdAt).toLocaleDateString('tr-TR') : 'Bilinmiyor'}</span>
          </div>
          <div className="info-item">
            <label>Durum:</label>
            <span className={`status ${user?.isActive ? 'active' : 'inactive'}`}>
              {user?.isActive ? 'Aktif' : 'Pasif'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;