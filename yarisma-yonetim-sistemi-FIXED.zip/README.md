# Süs Tavukları Yarışma Kayıt Sistemi

Modern web teknolojileri kullanılarak geliştirilmiş süs tavukları yarışma kayıt ve yönetim sistemi.

## 🏗️ Teknoloji Stack

### Backend
- **Node.js** + **TypeScript**
- **Express.js** - Web framework
- **Prisma ORM** - Veritabanı ORM
- **PostgreSQL** - Veritabanı
- **JWT** - Kimlik doğrulama
- **bcryptjs** - Şifre hashleme

### Frontend
- **React** + **TypeScript**
- **Tailwind CSS** - Styling
- **React Router** - Routing
- **React Hook Form** - Form yönetimi
- **Axios** - HTTP client
- **React Hot Toast** - Bildirimler

## 🚀 Kurulum

### Gereksinimler
- Node.js (v18+)
- PostgreSQL (v12+)
- npm veya yarn

### Backend Kurulumu

```bash
cd backend
npm install
```

#### Veritabanı Kurulumu
```bash
# .env dosyasını oluşturun (env.example'dan kopyalayın)
cp env.example .env

# Veritabanı URL'ini düzenleyin
# DATABASE_URL="postgresql://username:password@localhost:5432/sus_tavuklari_db"

# Prisma client oluşturun
npm run db:generate

# Veritabanı migration'ları çalıştırın
npm run db:push
```

#### Backend'i Başlatma
```bash
npm run dev
```

### Frontend Kurulumu

```bash
cd frontend
npm install
```

#### Frontend'i Başlatma
```bash
npm start
```

## 📊 Sistem Özellikleri

### Kullanıcı Rolleri

#### 🔧 Süperadmin
- Sistem kullanıcılarını yönetme
- Federasyon oluşturma/yönetme
- Sistem ayarları
- Excel'den hayvan türü/renk yükleme

#### 🏛️ Federasyon
- 42 derneği yönetme
- Aidat takibi
- Yarışma organizasyonu
- Kafes ataması
- Sonuç yayınlama

#### 👨‍💼 Başkan
- Dernek üyelerini yönetme
- Hayvan kayıtlarını onaylama
- Bilezik sipariş takibi

#### 👨‍⚖️ Hakem
- Atandığı kafesleri görme
- Hayvanları puanlama
- Ödül verme

#### 👤 Dernek Üyesi
- Hayvan kayıt sistemi
- Yarışma başvuruları
- Sonuçları görme

### Hayvan Kayıt Sistemi
- **Cinsler**: Tavuk, Horoz, Güvercin, Kaz, Ördek, Hindi, Tavşan
- **Tür ve Renk Varyasyonları**: Excel'den yüklenebilir
- **Bilezik Numarası**: Benzersiz olmalı
- **Kayıt Durumu**: Beklemede, Onaylandı, Reddedildi, Katılıyor, Tamamlandı

### Yarışma Sistemi
- Yarışma organizasyonu
- Hayvan sayısı limiti
- Aynı tür hayvanlar için kafes ataması
- Puanlama sistemi (Görünüm, Kondisyon, Cins Standardı)
- Ödül sistemi

## 🗄️ Veritabanı Şeması

### Ana Tablolar
- `users` - Kullanıcılar
- `federations` - Federasyonlar
- `associations` - Dernekler (42 adet)
- `animal_types` - Hayvan türleri
- `animal_colors` - Hayvan renkleri
- `animals` - Hayvanlar
- `competitions` - Yarışmalar
- `cages` - Kafesler
- `competition_registrations` - Yarışma kayıtları
- `scores` - Puanlar
- `awards` - Ödüller
- `ring_orders` - Bilezik siparişleri

## 🔐 API Endpoints

### Kimlik Doğrulama
- `POST /api/auth/login` - Giriş
- `POST /api/auth/register` - Kayıt
- `GET /api/auth/profile` - Profil
- `PUT /api/auth/profile` - Profil güncelleme

### Kullanıcılar
- `GET /api/users` - Kullanıcı listesi
- `GET /api/users/:id` - Kullanıcı detayı
- `PUT /api/users/:id` - Kullanıcı güncelleme
- `DELETE /api/users/:id` - Kullanıcı silme

### Hayvanlar
- `GET /api/animals` - Hayvan listesi
- `POST /api/animals` - Hayvan ekleme
- `PUT /api/animals/:id` - Hayvan güncelleme
- `DELETE /api/animals/:id` - Hayvan silme
- `POST /api/animals/import/types` - Hayvan türü yükleme
- `POST /api/animals/import/colors` - Hayvan rengi yükleme

### Yarışmalar
- `GET /api/competitions` - Yarışma listesi
- `POST /api/competitions` - Yarışma oluşturma
- `GET /api/competitions/:id/registrations` - Kayıt listesi
- `PUT /api/competitions/:id/registrations/:registrationId/approve` - Kayıt onaylama

### Dernekler
- `GET /api/associations` - Dernek listesi
- `POST /api/associations` - Dernek oluşturma
- `GET /api/associations/:id/members` - Üye listesi

### Federasyonlar
- `GET /api/federations` - Federasyon listesi
- `GET /api/federations/:id/stats` - İstatistikler

### Puanlar
- `GET /api/scores` - Puan listesi
- `POST /api/scores` - Puan ekleme
- `GET /api/scores/judge` - Hakem puanları
- `POST /api/scores/:id/awards` - Ödül ekleme

## 🚀 Geliştirme

### Backend Geliştirme
```bash
cd backend
npm run dev  # Development server
npm run build  # Production build
npm run db:studio  # Prisma Studio
```

### Frontend Geliştirme
```bash
cd frontend
npm start  # Development server
npm run build  # Production build
npm test  # Tests
```

## 📝 TODO

- [ ] Excel import/export sistemi
- [ ] Email bildirimleri
- [ ] Raporlama sistemi
- [ ] Mobil uygulama
- [ ] Çoklu dil desteği
- [ ] Backup sistemi

## 🤝 Katkıda Bulunma

1. Fork edin
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Commit edin (`git commit -m 'Add amazing feature'`)
4. Push edin (`git push origin feature/amazing-feature`)
5. Pull Request açın

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır.

## 📞 İletişim

Proje hakkında sorularınız için issue açabilirsiniz.
