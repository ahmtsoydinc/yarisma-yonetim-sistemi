import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [visiblePages, setVisiblePages] = useState<any[]>([]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  useEffect(() => {
    // Mock visible pages based on user role
    const getVisiblePages = () => {
      if (!user) return [];
      
      console.log('Layout - User role:', user.role); // Debug log
      
      const basePages = [
        { id: '1', title: 'Dashboard', path: '/dashboard', icon: '🏠' }
      ];

      switch (user.role) {
        case 'SUPERADMIN':
          console.log('Layout - Setting SUPERADMIN pages'); // Debug log
          return [
            ...basePages,
            { id: '2', title: 'Admin Panel', path: '/admin', icon: '⚙️' }
          ];
        case 'FEDERATION':
          console.log('Layout - Setting FEDERATION pages'); // Debug log
          return [
            ...basePages,
            { id: '3', title: 'Federasyon Panel', path: '/federation', icon: '🏛️' }
          ];
        case 'PRESIDENT':
          console.log('Layout - Setting PRESIDENT pages'); // Debug log
          return [
            ...basePages,
            { id: '4', title: 'Başkan Panel', path: '/president', icon: '👑' }
          ];
        case 'JUDGE':
          console.log('Layout - Setting JUDGE pages'); // Debug log
          return [
            ...basePages,
            { id: '5', title: 'Hakem Panel', path: '/judge', icon: '⚖️' }
          ];
        case 'MEMBER':
          console.log('Layout - Setting MEMBER pages'); // Debug log
          return [
            ...basePages,
            { id: '6', title: 'Üye Panel', path: '/member', icon: '👤' }
          ];
        default:
          console.log('Layout - Setting default pages'); // Debug log
          return basePages;
      }
    };

    const pages = getVisiblePages();
    console.log('Layout - Visible pages:', pages); // Debug log
    setVisiblePages(pages);
  }, [user]);

  return (
    <div className="text-layout">
              {/* Header */}
              <div className="layout-header">
                <div className="header-logo-section">
                  <img src="/tshf-logo.png" alt="TSHF Logo" className="header-logo" />
                  <div className="header-title">
                    <h1>TSHF Süs Tavukları Yarışma Sistemi</h1>
                    <p className="header-subtitle">Türkiye Süs Tavukları ve Bahçe Hayvanları Federasyonu</p>
                  </div>
                </div>
                <div className="user-info">
                  <span>{user?.firstName} {user?.lastName} ({user?.role})</span>
                  <button onClick={handleLogout}>Çıkış</button>
                </div>
              </div>

      {/* Navigation */}
      <div className="layout-nav">
        {visiblePages.map((page) => (
          <Link 
            key={page.id} 
            to={page.path}
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '0.5rem',
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              textDecoration: 'none',
              color: '#4a5568',
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              margin: '0 0.25rem',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
              e.currentTarget.style.color = '#2d3748';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
              e.currentTarget.style.color = '#4a5568';
            }}
          >
            <span style={{ fontSize: '1.2rem' }}>{page.icon}</span>
            <span>{page.title}</span>
          </Link>
        ))}
      </div>

      {/* Main Content */}
      <div className="layout-content">
        {children}
      </div>
    </div>
  );
};

export default Layout;