# Vercel Deployment Guide

Bu dosya sadece frontend deployment'ı içindir.

## Vercel Ayarları

1. **Framework Preset:** Create React App
2. **Root Directory:** `.` (ana dizin)
3. **Build Command:** `npm run build`
4. **Output Directory:** `build`
5. **Install Command:** `npm install`

## Environment Variables

```
REACT_APP_API_URL=https://your-backend-url.com
```

## Deployment Steps

1. Bu ZIP dosyasını GitHub'a yükleyin
2. Vercel'de yeni proje oluşturun
3. GitHub repository'sini seçin
4. Yukarıdaki ayarları yapın
5. Deploy edin

## Not

Bu klasör sadece React frontend'ini içerir. Backend ayrı olarak Railway'de deploy edilmelidir.
