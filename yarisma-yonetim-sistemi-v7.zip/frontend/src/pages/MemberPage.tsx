import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { animalsAPI } from '../services/api';

const MemberPage: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('animals');
  
  // Modal states
  const [showAnimalModal, setShowAnimalModal] = useState(false);
  const [showCompetitionModal, setShowCompetitionModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [editingAnimal, setEditingAnimal] = useState<any>(null);
  const [selectedCompetition, setSelectedCompetition] = useState<any>(null);
  
  // Form states
  const [newAnimal, setNewAnimal] = useState({
    name: '',
    ringNumber: '',
    breed: '',
    type: '',
    color: '',
    gender: '',
    birthDate: '',
    notes: ''
  });
  
  const [profileData, setProfileData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || ''
  });
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  console.log('MemberPage - User:', user); // Debug log
  console.log('MemberPage - User role:', user?.role); // Debug log
  console.log('MemberPage - Component rendered'); // Debug log
  
  // Mock data for member's animals
  const [animals, setAnimals] = useState([
    {
      id: '1',
      ringNumber: 'IST-2024-001',
      name: 'Sultan',
      type: 'Büyük Irk',
      breed: 'Cochin',
      color: 'Beyaz',
      gender: 'Dişi',
      birthDate: '2023-01-15',
      status: 'approved',
      registrationDate: '2024-01-15',
      notes: 'Çok güzel bir hayvan'
    },
    {
      id: '2',
      ringNumber: 'IST-2024-002',
      name: 'Altın',
      type: 'Orta Irk',
      breed: 'Leghorn',
      color: 'Altın',
      gender: 'Erkek',
      birthDate: '2023-03-20',
      status: 'pending',
      registrationDate: '2024-02-01',
      notes: 'Yarışmaya hazır'
    },
    {
      id: '3',
      ringNumber: 'IST-2024-003',
      name: 'Gümüş',
      type: 'Küçük Irk',
      breed: 'Serama',
      color: 'Gri',
      gender: 'Dişi',
      birthDate: '2023-05-10',
      status: 'rejected',
      registrationDate: '2024-02-10',
      notes: 'Reddedildi - belgeler eksik'
    }
  ]);

  // Mock data for competitions
  const [competitions] = useState([
    {
      id: '1',
      name: '2024 İstanbul Şampiyonası',
      date: '2024-03-15',
      location: 'İstanbul Fuar Merkezi',
      status: 'OPEN',
      registrationDeadline: '2024-03-01',
      myRegistrations: ['IST-2024-001']
    },
    {
      id: '2',
      name: '2024 Ankara Kupası',
      date: '2024-03-22',
      location: 'Ankara Spor Salonu',
      status: 'PLANNED',
      registrationDeadline: '2024-03-15',
      myRegistrations: []
    }
  ]);

  // Mock data for results
  const [results] = useState([
    {
      id: '1',
      competitionName: '2023 İstanbul Şampiyonası',
      animalName: 'Sultan',
      ringNumber: 'IST-2024-001',
      category: 'Büyük Irk',
      rank: 1,
      score: 95,
      award: 'Altın Kupa',
      date: '2023-12-15'
    },
    {
      id: '2',
      competitionName: '2023 Ankara Kupası',
      animalName: 'Altın',
      ringNumber: 'IST-2024-002',
      category: 'Orta Irk',
      rank: 3,
      score: 88,
      award: 'Bronz Madalya',
      date: '2023-11-20'
    }
  ]);

  // Animal management functions
  const handleRegisterAnimal = () => {
    setNewAnimal({
      name: '',
      ringNumber: '',
      breed: '',
      type: '',
      color: '',
      gender: '',
      birthDate: '',
      notes: ''
    });
    setEditingAnimal(null);
    setShowAnimalModal(true);
  };

  const handleEditAnimal = (id: string) => {
    const animal = animals.find(a => a.id === id);
    if (animal) {
      setNewAnimal({
        name: animal.name,
        ringNumber: animal.ringNumber,
        breed: animal.breed,
        type: animal.type,
        color: animal.color,
        gender: animal.gender,
        birthDate: animal.birthDate,
        notes: animal.notes || ''
      });
      setEditingAnimal(animal);
      setShowAnimalModal(true);
    }
  };

  const handleDeleteAnimal = async (id: string) => {
    if (window.confirm('Bu hayvanı silmek istediğinizden emin misiniz?')) {
      try {
        await animalsAPI.deleteAnimal(id);
        setAnimals(animals.filter(animal => animal.id !== id));
        alert('Hayvan başarıyla silindi!');
      } catch (error) {
        console.error('Hayvan silme hatası:', error);
        alert('Hayvan silinirken bir hata oluştu!');
      }
    }
  };

  const handleSaveAnimal = async () => {
    if (!newAnimal.name || !newAnimal.ringNumber || !newAnimal.breed) {
      alert('Lütfen zorunlu alanları doldurun!');
      return;
    }

    try {
      if (editingAnimal) {
        // Update existing animal
        await animalsAPI.updateAnimal(editingAnimal.id, newAnimal);
        setAnimals(animals.map(animal => 
          animal.id === editingAnimal.id 
            ? { ...animal, ...newAnimal, status: 'pending' }
            : animal
        ));
        alert('Hayvan başarıyla güncellendi!');
      } else {
        // Add new animal
        const newAnimalData = {
          ...newAnimal,
          status: 'pending',
          registrationDate: new Date().toISOString().split('T')[0]
        };
        const response = await animalsAPI.createAnimal(newAnimalData);
        setAnimals([...animals, response.animal]);
        alert('Yeni hayvan başarıyla eklendi!');
      }
      
      setShowAnimalModal(false);
      setEditingAnimal(null);
    } catch (error) {
      console.error('Hayvan kaydetme hatası:', error);
      alert('Hayvan kaydedilirken bir hata oluştu!');
    }
  };

  // Competition functions
  const handleRegisterToCompetition = (competitionId: string) => {
    const competition = competitions.find(c => c.id === competitionId);
    if (competition) {
      setSelectedCompetition(competition);
      setShowCompetitionModal(true);
    }
  };

  const handleViewCompetitionDetails = (competitionId: string) => {
    const competition = competitions.find(c => c.id === competitionId);
    if (competition) {
      alert(`Yarışma: ${competition.name}\nTarih: ${new Date(competition.date).toLocaleDateString('tr-TR')}\nLokasyon: ${competition.location}\nSon Kayıt: ${new Date(competition.registrationDeadline).toLocaleDateString('tr-TR')}`);
    }
  };

  const handleCompetitionRegistration = (selectedAnimals: string[]) => {
    if (selectedAnimals.length === 0) {
      alert('Lütfen en az bir hayvan seçin!');
      return;
    }

    // Update competition with new registrations
    const updatedCompetitions = competitions.map(comp => 
      comp.id === selectedCompetition.id 
        ? { ...comp, myRegistrations: [...comp.myRegistrations, ...selectedAnimals] }
        : comp
    );
    // Note: setCompetitions function would be needed if competitions state was mutable
    console.log('Competitions updated:', updatedCompetitions);
    
    console.log('Yarışmaya kayıt yapıldı:', selectedCompetition.id, selectedAnimals);
    setShowCompetitionModal(false);
    setSelectedCompetition(null);
  };

  // Profile functions
  const handleEditProfile = () => {
    setProfileData({
      firstName: user?.firstName || '',
      lastName: user?.lastName || '',
      email: user?.email || '',
      phone: user?.phone || ''
    });
    setShowProfileModal(true);
  };

  const handleSaveProfile = () => {
    if (!profileData.firstName || !profileData.lastName || !profileData.email) {
      alert('Lütfen zorunlu alanları doldurun!');
      return;
    }

    console.log('Profil güncellendi:', profileData);
    setShowProfileModal(false);
  };

  const handleChangePassword = () => {
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
    setShowPasswordModal(true);
  };

  const handleSavePassword = () => {
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      alert('Lütfen tüm alanları doldurun!');
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert('Yeni şifreler eşleşmiyor!');
      return;
    }

    if (passwordData.newPassword.length < 6) {
      alert('Şifre en az 6 karakter olmalıdır!');
      return;
    }

    console.log('Şifre değiştirildi');
    setShowPasswordModal(false);
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return '#10b981';
      case 'pending': return '#f59e0b';
      case 'rejected': return '#ef4444';
      case 'OPEN': return '#10b981';
      case 'PLANNED': return '#6b7280';
      case 'CLOSED': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved': return 'Onaylandı';
      case 'pending': return 'Beklemede';
      case 'rejected': return 'Reddedildi';
      case 'OPEN': return 'Kayıt Açık';
      case 'PLANNED': return 'Planlandı';
      case 'CLOSED': return 'Kayıt Kapandı';
      default: return status;
    }
  };

  const getRankText = (rank: number) => {
    switch (rank) {
      case 1: return '🥇 1.';
      case 2: return '🥈 2.';
      case 3: return '🥉 3.';
      default: return `${rank}.`;
    }
  };

  return (
    <div className="member-page">
      <div className="page-header">
        <h1>Üye Paneli</h1>
        <p>Hoş geldiniz, {user?.firstName} {user?.lastName}</p>
      </div>

      <div className="admin-tabs">
        <button 
          className={`tab-button ${activeTab === 'animals' ? 'active' : ''}`}
          onClick={() => setActiveTab('animals')}
        >
          Hayvanlarım
        </button>
        <button 
          className={`tab-button ${activeTab === 'competitions' ? 'active' : ''}`}
          onClick={() => setActiveTab('competitions')}
        >
          Yarışmalar
        </button>
        <button 
          className={`tab-button ${activeTab === 'results' ? 'active' : ''}`}
          onClick={() => setActiveTab('results')}
        >
          Sonuçlarım
        </button>
        <button 
          className={`tab-button ${activeTab === 'profile' ? 'active' : ''}`}
          onClick={() => setActiveTab('profile')}
        >
          Profilim
        </button>
      </div>

      <div className="admin-content">
        {/* Animals Tab */}
        {activeTab === 'animals' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Hayvanlarım</h2>
              <div className="header-actions">
                <div className="stats">
                  <span className="stat-item">
                    <strong>Toplam Hayvan:</strong> {animals.length}
                  </span>
                  <span className="stat-item">
                    <strong>Onaylanan:</strong> {animals.filter(a => a.status === 'approved').length}
                  </span>
                  <span className="stat-item">
                    <strong>Beklemede:</strong> {animals.filter(a => a.status === 'pending').length}
                  </span>
                </div>
                <button 
                  className="add-button"
                  onClick={handleRegisterAnimal}
                >
                  + Yeni Hayvan Kaydet
                </button>
              </div>
            </div>

            <div className="animals-list">
              {animals.map(animal => (
                <div key={animal.id} className="animal-item">
                  <div className="animal-info">
                    <h3>{animal.name} ({animal.ringNumber})</h3>
                    <p><strong>Cins:</strong> {animal.breed}</p>
                    <p><strong>Tür:</strong> {animal.type}</p>
                    <p><strong>Renk:</strong> {animal.color}</p>
                    <p><strong>Cinsiyet:</strong> {animal.gender}</p>
                    <p><strong>Doğum Tarihi:</strong> {new Date(animal.birthDate).toLocaleDateString('tr-TR')}</p>
                    {animal.notes && <p><strong>Notlar:</strong> {animal.notes}</p>}
                  </div>
                  <div className="animal-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(animal.status) }}
                    >
                      {getStatusText(animal.status)}
                    </span>
                    <div className="action-buttons">
                      <button 
                        className="edit-btn"
                        onClick={() => handleEditAnimal(animal.id)}
                      >
                        Düzenle
                      </button>
                      <button 
                        className="delete-btn"
                        onClick={() => handleDeleteAnimal(animal.id)}
                      >
                        Sil
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Competitions Tab */}
        {activeTab === 'competitions' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Yarışmalar</h2>
              <div className="stats">
                <span className="stat-item">
                  <strong>Toplam Yarışma:</strong> {competitions.length}
                </span>
                <span className="stat-item">
                  <strong>Kayıt Açık:</strong> {competitions.filter(c => c.status === 'OPEN').length}
                </span>
                <span className="stat-item">
                  <strong>Kayıtlı:</strong> {competitions.filter(c => c.myRegistrations.length > 0).length}
                </span>
              </div>
            </div>

            <div className="competitions-list">
              {competitions.map(competition => (
                <div key={competition.id} className="competition-item">
                  <div className="competition-info">
                    <h3>{competition.name}</h3>
                    <p><strong>Tarih:</strong> {new Date(competition.date).toLocaleDateString('tr-TR')}</p>
                    <p><strong>Lokasyon:</strong> {competition.location}</p>
                    <p><strong>Son Kayıt:</strong> {new Date(competition.registrationDeadline).toLocaleDateString('tr-TR')}</p>
                    <p><strong>Kayıtlı Hayvanlarım:</strong> {competition.myRegistrations.length}</p>
                  </div>
                  <div className="competition-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(competition.status) }}
                    >
                      {getStatusText(competition.status)}
                    </span>
                    <div className="action-buttons">
                      <button 
                        className="edit-btn"
                        onClick={() => handleViewCompetitionDetails(competition.id)}
                      >
                        Detaylar
                      </button>
                      {competition.status === 'OPEN' && (
                        <button 
                          className="status-btn"
                          onClick={() => handleRegisterToCompetition(competition.id)}
                        >
                          Kayıt Ol
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Results Tab */}
        {activeTab === 'results' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Yarışma Sonuçlarım</h2>
              <div className="stats">
                <span className="stat-item">
                  <strong>Toplam Sonuç:</strong> {results.length}
                </span>
                <span className="stat-item">
                  <strong>Ödüllü:</strong> {results.filter(r => r.rank <= 3).length}
                </span>
                <span className="stat-item">
                  <strong>Ortalama Puan:</strong> {Math.round(results.reduce((acc, r) => acc + r.score, 0) / results.length)}
                </span>
              </div>
            </div>

            <div className="results-list">
              {results.map(result => (
                <div key={result.id} className="result-item">
                  <div className="result-info">
                    <h3>{result.competitionName}</h3>
                    <p><strong>Hayvan:</strong> {result.animalName} ({result.ringNumber})</p>
                    <p><strong>Kategori:</strong> {result.category}</p>
                    <p><strong>Puan:</strong> {result.score}/100</p>
                    <p><strong>Tarih:</strong> {new Date(result.date).toLocaleDateString('tr-TR')}</p>
                  </div>
                  <div className="result-actions">
                    <div className="rank-display">
                      <span className="rank-badge">
                        {getRankText(result.rank)}
                      </span>
                      <span className="award-badge">
                        🏆 {result.award}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Profil Bilgilerim</h2>
            </div>

            <div className="profile-card">
              <div className="profile-info">
                <h3>Kişisel Bilgiler</h3>
                <div className="profile-field">
                  <label>Ad Soyad:</label>
                  <span>{user?.firstName} {user?.lastName}</span>
                </div>
                <div className="profile-field">
                  <label>E-posta:</label>
                  <span>{user?.email}</span>
                </div>
                <div className="profile-field">
                  <label>Telefon:</label>
                  <span>{user?.phone || 'Belirtilmemiş'}</span>
                </div>
                <div className="profile-field">
                  <label>Rol:</label>
                  <span>{user?.role}</span>
                </div>
                <div className="profile-field">
                  <label>Dernek:</label>
                  <span>{user?.association?.name || 'Belirtilmemiş'}</span>
                </div>
                <div className="profile-field">
                  <label>Onay Durumu:</label>
                  <span className="status-badge approved">
                    Onaylandı
                  </span>
                </div>
              </div>
              <div className="profile-actions">
                <button className="edit-btn" onClick={handleEditProfile}>
                  Profili Düzenle
                </button>
                <button className="status-btn" onClick={handleChangePassword}>
                  Şifre Değiştir
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Animal Registration/Edit Modal */}
      {showAnimalModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>{editingAnimal ? 'Hayvan Düzenle' : 'Yeni Hayvan Kaydet'}</h3>
              <button className="close-btn" onClick={() => setShowAnimalModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Hayvan Adı *</label>
                <input
                  type="text"
                  value={newAnimal.name}
                  onChange={(e) => setNewAnimal({...newAnimal, name: e.target.value})}
                  placeholder="Hayvan adını girin"
                />
              </div>
              <div className="form-group">
                <label>Bilezik Numarası *</label>
                <input
                  type="text"
                  value={newAnimal.ringNumber}
                  onChange={(e) => setNewAnimal({...newAnimal, ringNumber: e.target.value})}
                  placeholder="Bilezik numarasını girin"
                />
              </div>
              <div className="form-group">
                <label>Cins *</label>
                <input
                  type="text"
                  value={newAnimal.breed}
                  onChange={(e) => setNewAnimal({...newAnimal, breed: e.target.value})}
                  placeholder="Cins bilgisini girin"
                />
              </div>
              <div className="form-group">
                <label>Tür</label>
                <select
                  value={newAnimal.type}
                  onChange={(e) => setNewAnimal({...newAnimal, type: e.target.value})}
                >
                  <option value="">Tür seçin</option>
                  <option value="Büyük Irk">Büyük Irk</option>
                  <option value="Orta Irk">Orta Irk</option>
                  <option value="Küçük Irk">Küçük Irk</option>
                </select>
              </div>
              <div className="form-group">
                <label>Renk</label>
                <input
                  type="text"
                  value={newAnimal.color}
                  onChange={(e) => setNewAnimal({...newAnimal, color: e.target.value})}
                  placeholder="Renk bilgisini girin"
                />
              </div>
              <div className="form-group">
                <label>Cinsiyet</label>
                <select
                  value={newAnimal.gender}
                  onChange={(e) => setNewAnimal({...newAnimal, gender: e.target.value})}
                >
                  <option value="">Cinsiyet seçin</option>
                  <option value="Erkek">Erkek</option>
                  <option value="Dişi">Dişi</option>
                </select>
              </div>
              <div className="form-group">
                <label>Doğum Tarihi</label>
                <input
                  type="date"
                  value={newAnimal.birthDate}
                  onChange={(e) => setNewAnimal({...newAnimal, birthDate: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>Notlar</label>
                <textarea
                  value={newAnimal.notes}
                  onChange={(e) => setNewAnimal({...newAnimal, notes: e.target.value})}
                  placeholder="Ek notlar (opsiyonel)"
                  rows={3}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowAnimalModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={handleSaveAnimal}>
                {editingAnimal ? 'Güncelle' : 'Kaydet'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Competition Registration Modal */}
      {showCompetitionModal && selectedCompetition && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Yarışmaya Kayıt Ol</h3>
              <button className="close-btn" onClick={() => setShowCompetitionModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="competition-info">
                <h4>{selectedCompetition.name}</h4>
                <p><strong>Tarih:</strong> {new Date(selectedCompetition.date).toLocaleDateString('tr-TR')}</p>
                <p><strong>Lokasyon:</strong> {selectedCompetition.location}</p>
                <p><strong>Son Kayıt:</strong> {new Date(selectedCompetition.registrationDeadline).toLocaleDateString('tr-TR')}</p>
              </div>
              <div className="form-group">
                <label>Kayıt Olmak İstediğiniz Hayvanlar:</label>
                <div className="animal-selection">
                  {animals.filter(animal => animal.status === 'approved').map(animal => (
                    <label key={animal.id} className="checkbox-item">
                      <input
                        type="checkbox"
                        value={animal.id}
                      onChange={(e) => {
                        if (e.target.checked) {
                          if (!selectedCompetition.myRegistrations.includes(animal.id)) {
                            setSelectedCompetition({
                              ...selectedCompetition,
                              myRegistrations: [...selectedCompetition.myRegistrations, animal.id]
                            });
                          }
                        } else {
                          setSelectedCompetition({
                            ...selectedCompetition,
                            myRegistrations: selectedCompetition.myRegistrations.filter((id: string) => id !== animal.id)
                          });
                        }
                      }}
                      />
                      <span>{animal.name} ({animal.ringNumber})</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowCompetitionModal(false)}>
                İptal
              </button>
              <button 
                className="save-btn" 
                onClick={() => handleCompetitionRegistration(selectedCompetition.myRegistrations)}
              >
                Kayıt Ol
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Profile Edit Modal */}
      {showProfileModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Profil Düzenle</h3>
              <button className="close-btn" onClick={() => setShowProfileModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Ad *</label>
                <input
                  type="text"
                  value={profileData.firstName}
                  onChange={(e) => setProfileData({...profileData, firstName: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>Soyad *</label>
                <input
                  type="text"
                  value={profileData.lastName}
                  onChange={(e) => setProfileData({...profileData, lastName: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>E-posta *</label>
                <input
                  type="email"
                  value={profileData.email}
                  onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>Telefon</label>
                <input
                  type="tel"
                  value={profileData.phone}
                  onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowProfileModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={handleSaveProfile}>
                Kaydet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Şifre Değiştir</h3>
              <button className="close-btn" onClick={() => setShowPasswordModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Mevcut Şifre *</label>
                <input
                  type="password"
                  value={passwordData.currentPassword}
                  onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>Yeni Şifre *</label>
                <input
                  type="password"
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>Yeni Şifre Tekrar *</label>
                <input
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowPasswordModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={handleSavePassword}>
                Şifreyi Değiştir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MemberPage;
