import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getScores, 
  getScoreById, 
  createScore, 
  updateScore, 
  deleteScore,
  getJudgeScores,
  addAward
} from '../controllers/scoreController';
import { authenticateToken, requireJudge } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createScoreValidation = [
  body('registrationId').isUUID(),
  body('appearanceScore').isInt({ min: 0, max: 100 }),
  body('conditionScore').isInt({ min: 0, max: 100 }),
  body('breedStandardScore').isInt({ min: 0, max: 100 }),
  body('notes').optional().trim()
];

const awardValidation = [
  body('type').isIn(['FIRST_PLACE', 'SECOND_PLACE', 'THIRD_PLACE', 'HONORABLE_MENTION', 'SPECIAL_AWARD']),
  body('name').notEmpty().trim(),
  body('description').optional().trim()
];

// Routes
router.get('/', getScores);
router.get('/judge', requireJudge, getJudgeScores);
router.get('/:id', getScoreById);
router.post('/', createScoreValidation, validateRequest, requireJudge, createScore);
router.put('/:id', createScoreValidation, validateRequest, requireJudge, updateScore);
router.delete('/:id', requireJudge, deleteScore);

// Award routes
router.post('/:id/awards', awardValidation, validateRequest, requireJudge, addAward);

export default router;
