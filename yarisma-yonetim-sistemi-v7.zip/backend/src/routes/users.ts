import { Router } from 'express';
import { body } from 'express-validator';
import { getUsers, getUserById, createUser, updateUser, deleteUser, approveUser, getPendingUsers } from '../controllers/userController';
import { authenticateToken, requireSuperAdmin } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation middleware
const createUserValidation = [
  body('email').isEmail().withMessage('Geçerli bir e-posta adresi giriniz'),
  body('password').isLength({ min: 6 }).withMessage('Şifre en az 6 karakter olmalıdır'),
  body('firstName').notEmpty().withMessage('Ad zorunludur'),
  body('lastName').notEmpty().withMessage('Soyad zorunludur'),
  body('role').isIn(['SUPERADMIN', 'FEDERATION', 'PRESIDENT', 'JUDGE', 'MEMBER']).withMessage('Geçerli bir rol seçiniz'),
  body('phone').optional().isMobilePhone('tr-TR').withMessage('Geçerli bir telefon numarası giriniz'),
];

const updateUserValidation = [
  body('firstName').optional().notEmpty().withMessage('Ad boş olamaz'),
  body('lastName').optional().notEmpty().withMessage('Soyad boş olamaz'),
  body('role').optional().isIn(['SUPERADMIN', 'FEDERATION', 'PRESIDENT', 'JUDGE', 'MEMBER']).withMessage('Geçerli bir rol seçiniz'),
  body('phone').optional().isMobilePhone('tr-TR').withMessage('Geçerli bir telefon numarası giriniz'),
];

// Superadmin only routes
router.get('/', requireSuperAdmin, getUsers);
router.get('/:id', requireSuperAdmin, getUserById);
router.post('/', createUserValidation, validateRequest, requireSuperAdmin, createUser);
router.put('/:id', updateUserValidation, validateRequest, requireSuperAdmin, updateUser);
router.delete('/:id', requireSuperAdmin, deleteUser);

// President routes for user approval
router.get('/pending', getPendingUsers);
router.patch('/:id/approve', approveUser);

export default router;
