# 🚀 Vercel Deployment Rehberi

## 📋 Ön Gereksinimler

1. **GitHub Hesabı** - Kodunuzu GitHub'a yükleyin
2. **Vercel Hesabı** - [vercel.com](https://vercel.com) üzerinde hesap oluşturun
3. **Railway Hesabı** - Backend için [railway.app](https://railway.app)

## 🌐 Frontend Deployment (Vercel)

### 1. GitHub Repository Oluşturma

```bash
# Proje dizininde
cd /home/ahmet/yarisma-yonetim-sistemi

# Git repository başlat
git init
git add .
git commit -m "Initial commit - TSHF Süs Tavukları Yarışma Sistemi"

# GitHub'da yeni repository oluştur ve bağla
git remote add origin https://github.com/KULLANICI_ADI/yarisma-yonetim-sistemi.git
git branch -M main
git push -u origin main
```

### 2. Vercel'de Proje Oluşturma

1. [vercel.com](https://vercel.com) adresine gidin
2. "Sign Up" → GitHub ile giriş yapın
3. "Add New..." → "Project" seçin
4. GitHub repository'nizi seçin
5. **Önemli Ayarlar:**
   - **Root Directory:** `frontend`
   - **Framework Preset:** `Create React App`
   - **Build Command:** `npm run build`
   - **Output Directory:** `build`

### 3. Environment Variables (Ortam Değişkenleri)

Vercel Dashboard → Project → Settings → Environment Variables:

```
REACT_APP_API_URL = https://your-railway-backend.up.railway.app/api
```

## 🔧 Backend Deployment (Railway)

### 1. Railway'de Proje Oluşturma

1. [railway.app](https://railway.app) adresine gidin
2. GitHub ile giriş yapın
3. "New Project" → "Deploy from GitHub repo"
4. Repository'nizi seçin
5. **Root Directory:** `backend`

### 2. Environment Variables

Railway Dashboard → Project → Variables:

```
DATABASE_URL = postgresql://username:password@host:port/database
JWT_SECRET = your-jwt-secret-key
NODE_ENV = production
PORT = 5000
```

### 3. PostgreSQL Database Ekleme

1. Railway Dashboard → "Add Service" → "Database" → "PostgreSQL"
2. Database URL'ini environment variables'a ekleyin
3. Migration'ları çalıştırın:

```bash
npx prisma migrate deploy
npx prisma generate
```

## 📦 Deployment Sonrası

### 1. CORS Ayarları

Backend'te `src/server.ts` dosyasında:

```typescript
app.use(cors({
  origin: ['http://localhost:3000', 'https://your-vercel-app.vercel.app'],
  credentials: true
}));
```

### 2. Frontend API URL Güncelleme

Frontend'te `src/services/api.ts`:

```typescript
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
```

## 🔍 Test Etme

1. **Frontend:** `https://your-app.vercel.app`
2. **Backend:** `https://your-backend.railway.app/api/health`
3. **Login Test:** admin@sustavuklari.org / admin123

## 📱 Özellikler

✅ **Tam İşlevsel Sistem:**
- Kullanıcı yönetimi (5 farklı rol)
- Hayvan kayıt sistemi
- Yarışma organizasyonu
- Excel import/export
- Modern responsive tasarım
- Gerçek veritabanı entegrasyonu

## 🆘 Sorun Giderme

### Build Hataları
- `npm run build` komutunu local'de test edin
- Environment variables'ları kontrol edin
- Dependencies'leri kontrol edin

### API Bağlantı Hataları
- CORS ayarlarını kontrol edin
- Backend URL'ini kontrol edin
- Network tab'da hata mesajlarını inceleyin

### Database Hataları
- Railway PostgreSQL bağlantısını kontrol edin
- Migration'ları tekrar çalıştırın
- Prisma client'ı regenerate edin

## 🎯 Sonuç

Bu rehberi takip ederek uygulamanızı production'da çalıştırabilirsiniz:

- **Frontend:** Vercel (Ücretsiz)
- **Backend:** Railway (Ücretsiz)
- **Database:** Railway PostgreSQL (Ücretsiz)

Toplam maliyet: **0 TL** 💰

## 📞 Destek

Sorun yaşarsanız:
1. Console loglarını kontrol edin
2. Network tab'da API çağrılarını inceleyin
3. Railway ve Vercel loglarını kontrol edin
