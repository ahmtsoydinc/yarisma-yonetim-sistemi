import { Router } from 'express';
import { body } from 'express-validator';
import { register, login, getProfile, updateProfile } from '../controllers/authController';
import { loginWithAssociation } from '../controllers/userController';
import { authenticateToken } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// Validation rules
const registerValidation = [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
  body('firstName').notEmpty().trim(),
  body('lastName').notEmpty().trim(),
  body('role').isIn(['SUPERADMIN', 'FEDERATION', 'PRESIDENT', 'JUDGE', 'MEMBER']),
  body('phone').optional().isMobilePhone('tr-TR')
];

const loginValidation = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
];

const loginWithAssociationValidation = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
  body('associationId').optional().isString()
];

// Routes
router.post('/register', registerValidation, validateRequest, register);
router.post('/login', loginValidation, validateRequest, login);
router.post('/login-with-association', loginWithAssociationValidation, validateRequest, loginWithAssociation);
router.get('/profile', authenticateToken, getProfile);
router.put('/profile', authenticateToken, updateProfile);

module.exports = router;
