import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';

export const getScores = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, competitionId, animalId } = req.query;
    
    const where: any = {};
    if (competitionId) {
      where.competitionId = competitionId;
    }
    if (animalId) {
      where.animalId = animalId;
    }

    const scores = await prisma.score.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      orderBy: { score: 'desc' }
    });

    const total = await prisma.score.count({ where });

    res.json({
      scores,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getScoresByJudge = async (req: Request, res: Response) => {
  try {
    const { judgeId } = req.params;
    const { page = 1, limit = 10 } = req.query;

    const scores = await prisma.score.findMany({
      where: { judgeId },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      orderBy: { createdAt: 'desc' }
    });

    const total = await prisma.score.count({ where: { judgeId } });

    res.json({
      scores,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getScoreById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const score = await prisma.score.findUnique({
      where: { id }
    });

    if (!score) {
      throw createError('Score not found', 404);
    }

    res.json({ score });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createScore = async (req: Request, res: Response) => {
  try {
    const { animalId, competitionId, judgeId, score, notes } = req.body;

    // Validate required fields
    if (!animalId || !competitionId || !judgeId || score === undefined) {
      throw createError('Missing required fields', 400);
    }

    // Check if score already exists for this animal, competition, and judge
    const existingScore = await prisma.score.findFirst({
      where: { animalId, competitionId, judgeId },
    });

    if (existingScore) {
      throw createError('Score already exists for this animal, competition, and judge', 409);
    }

    const newScore = await prisma.score.create({
      data: {
        animalId,
        competitionId,
        judgeId,
        score,
        notes
      }
    });

    res.status(201).json({
      message: 'Puan başarıyla kaydedildi',
      score: newScore
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateScore = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { score, notes } = req.body;

    // Check if score exists
    const existingScore = await prisma.score.findUnique({
      where: { id }
    });

    if (!existingScore) {
      throw createError('Score not found', 404);
    }

    const updatedScore = await prisma.score.update({
      where: { id },
      data: {
        score,
        notes
      }
    });

    res.json({
      message: 'Puan başarıyla güncellendi',
      score: updatedScore
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteScore = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Check if score exists
    const existingScore = await prisma.score.findUnique({
      where: { id }
    });

    if (!existingScore) {
      throw createError('Score not found', 404);
    }

    await prisma.score.delete({
      where: { id }
    });

    res.json({
      message: 'Puan başarıyla silindi'
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createAward = async (req: Request, res: Response) => {
  try {
    const { scoreId, type, name, description } = req.body;

    // Check if score exists
    const score = await prisma.score.findUnique({
      where: { id: scoreId }
    });

    if (!score) {
      throw createError('Score not found', 404);
    }

    // Mock award creation since award model doesn't exist in schema
    const award = {
      id: 'mock-award-id',
      scoreId,
      type,
      name,
      description,
      createdAt: new Date()
    };

    res.status(201).json({
      message: 'Ödül başarıyla eklendi',
      award
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};