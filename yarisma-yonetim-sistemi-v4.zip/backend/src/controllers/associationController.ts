import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';

export const getAssociations = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, federationId, isActive } = req.query;
    
    const where: any = {};
    if (federationId) where.federationId = federationId;
    if (isActive !== undefined) where.isActive = isActive === 'true';

    const associations = await prisma.association.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        federation: {
          select: { id: true, name: true }
        },
        president: {
          select: { id: true, firstName: true, lastName: true, email: true }
        },
        _count: {
          select: { users: true }
        }
      },
      orderBy: { name: 'asc' }
    });

    const total = await prisma.association.count({ where });

    res.json({
      associations,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getAssociationById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const association = await prisma.association.findUnique({
      where: { id },
      include: {
        federation: {
          select: { id: true, name: true }
        },
        president: {
          select: { id: true, firstName: true, lastName: true, email: true, phone: true }
        },
        users: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            role: true,
            isActive: true,
            createdAt: true
          }
        },
        _count: {
          select: { users: true }
        }
      }
    });

    if (!association) {
      throw createError('Association not found', 404);
    }

    res.json({ association });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createAssociation = async (req: Request, res: Response) => {
  try {
    const { name, code, address, phone, email, membershipFee, federationId } = req.body;

    // Check if code already exists
    const existingAssociation = await prisma.association.findUnique({
      where: { code }
    });

    if (existingAssociation) {
      throw createError('Bu dernek kodu zaten kullanılıyor', 400);
    }

    const association = await prisma.association.create({
      data: {
        name,
        code,
        description,
        federationId
      },
      include: {
        federation: {
          select: { id: true, name: true }
        }
      }
    });

    res.status(201).json({
      message: 'Dernek başarıyla oluşturuldu',
      association
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateAssociation = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, address, phone, email, membershipFee, isActive } = req.body;

    const association = await prisma.association.update({
      where: { id },
      data: {
        name,
        description,
        isActive
      },
      include: {
        federation: {
          select: { id: true, name: true }
        },
        president: {
          select: { id: true, firstName: true, lastName: true, email: true }
        }
      }
    });

    res.json({
      message: 'Dernek başarıyla güncellendi',
      association
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteAssociation = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await prisma.association.delete({
      where: { id }
    });

    res.json({ message: 'Dernek başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getAssociationMembers = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { page = 1, limit = 10, role, isActive } = req.query;

    const where: any = { associationId: id };
    if (role) where.role = role;
    if (isActive !== undefined) where.isActive = isActive === 'true';

    const members = await prisma.user.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        phone: true,
        isActive: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' }
    });

    const total = await prisma.user.count({ where });

    res.json({
      members,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const addAssociationMember = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;

    const user = await prisma.user.update({
      where: { id: userId },
      data: { associationId: id },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true
      }
    });

    res.json({
      message: 'Üye başarıyla derneğe eklendi',
      user
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const removeAssociationMember = async (req: Request, res: Response) => {
  try {
    const { id, userId } = req.params;

    await prisma.user.update({
      where: { id: userId },
      data: { associationId: null }
    });

    res.json({ message: 'Üye başarıyla dernekten çıkarıldı' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};
