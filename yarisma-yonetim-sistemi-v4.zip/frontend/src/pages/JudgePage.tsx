import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const JudgePage: React.FC = () => {
  const { user: _user } = useAuth();
  const [activeTab, setActiveTab] = useState('scoring');
  
  // Mock data for competitions
  const [competitions] = useState([
    {
      id: '1',
      name: '2024 İstanbul Şampiyonası',
      date: '2024-03-15',
      location: 'İstanbul Fuar Merkezi',
      status: 'ONGOING',
      totalParticipants: 156,
      judgedParticipants: 89
    },
    {
      id: '2',
      name: '2024 Ankara Kupası',
      date: '2024-03-22',
      location: 'Ankara Spor Salonu',
      status: 'PLANNED',
      totalParticipants: 98,
      judgedParticipants: 0
    },
    {
      id: '3',
      name: '2024 İzmir Yarışması',
      date: '2024-02-28',
      location: 'İzmir Kongre Merkezi',
      status: 'COMPLETED',
      totalParticipants: 124,
      judgedParticipants: 124
    }
  ]);

  // Mock data for animals to judge
  const [animalsToJudge] = useState([
    {
      id: '1',
      ringNumber: 'IST-2024-001',
      name: 'Sultan',
      breed: 'Cochin',
      category: 'Büyük Irk',
      owner: 'Ahmet Yılmaz',
      association: 'İstanbul Derneği',
      scores: {
        appearance: 0,
        condition: 0,
        breed_standard: 0,
        behavior: 0
      }
    },
    {
      id: '2',
      ringNumber: 'IST-2024-002',
      name: 'Altın',
      breed: 'Leghorn',
      category: 'Orta Irk',
      owner: 'Ayşe Demir',
      association: 'Ankara Derneği',
      scores: {
        appearance: 0,
        condition: 0,
        breed_standard: 0,
        behavior: 0
      }
    },
    {
      id: '3',
      ringNumber: 'IST-2024-003',
      name: 'Gümüş',
      breed: 'Serama',
      category: 'Küçük Irk',
      owner: 'Mehmet Kaya',
      association: 'İzmir Derneği',
      scores: {
        appearance: 0,
        condition: 0,
        breed_standard: 0,
        behavior: 0
      }
    }
  ]);

  // Mock data for awards
  const [awards] = useState([
    {
      id: '1',
      name: 'En İyi Görünüm',
      description: 'Görünüm kategorisinde en yüksek puan alan hayvan',
      competitionId: '1',
      winnerId: null,
      prize: 'Altın Kupa'
    },
    {
      id: '2',
      name: 'En Sağlıklı Hayvan',
      description: 'Sağlık durumu en iyi olan hayvan',
      competitionId: '1',
      winnerId: null,
      prize: 'Gümüş Madalya'
    },
    {
      id: '3',
      name: 'En Uyumlu Davranış',
      description: 'Davranış kategorisinde en yüksek puan alan hayvan',
      competitionId: '1',
      winnerId: null,
      prize: 'Bronz Rozet'
    }
  ]);

  // Scoring functions
  const handleScoreChange = (animalId: string, category: string, score: number) => {
    if (score < 0 || score > 100) {
      alert('Puan 0-100 arasında olmalıdır!');
      return;
    }
    alert(`Hayvan ${animalId} - ${category} kategorisi: ${score} puan`);
  };

  const handleSubmitScores = (animalId: string) => {
    alert(`Hayvan ${animalId} için puanlar kaydedildi!`);
  };

  // Award functions
  const handleAddAward = () => {
    alert('Yeni ödül ekleme formu açılacak!');
  };

  const handleAssignAward = (awardId: string, animalId: string) => {
    alert(`Ödül ${awardId} hayvan ${animalId}'ye atandı!`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ONGOING': return '#10b981';
      case 'PLANNED': return '#f59e0b';
      case 'COMPLETED': return '#6b7280';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'ONGOING': return 'Devam Ediyor';
      case 'PLANNED': return 'Planlandı';
      case 'COMPLETED': return 'Tamamlandı';
      default: return status;
    }
  };

  return (
    <div className="judge-page">
      <div className="page-header">
        <h1>Hakem Paneli</h1>
        <p>Yarışma Değerlendirme ve Puanlama Sistemi</p>
      </div>

      <div className="admin-tabs">
        <button 
          className={`tab-button ${activeTab === 'scoring' ? 'active' : ''}`}
          onClick={() => setActiveTab('scoring')}
        >
          Puanlama
        </button>
        <button 
          className={`tab-button ${activeTab === 'awards' ? 'active' : ''}`}
          onClick={() => setActiveTab('awards')}
        >
          Ödül Yönetimi
        </button>
        <button 
          className={`tab-button ${activeTab === 'competitions' ? 'active' : ''}`}
          onClick={() => setActiveTab('competitions')}
        >
          Yarışmalar
        </button>
      </div>

      <div className="admin-content">
        {/* Scoring Tab */}
        {activeTab === 'scoring' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Hayvan Puanlama</h2>
              <div className="stats">
                <span className="stat-item">
                  <strong>Toplam Hayvan:</strong> {animalsToJudge.length}
                </span>
                <span className="stat-item">
                  <strong>Puanlanan:</strong> {animalsToJudge.filter(a => Object.values(a.scores).some(s => s > 0)).length}
                </span>
                <span className="stat-item">
                  <strong>Bekleyen:</strong> {animalsToJudge.filter(a => Object.values(a.scores).every(s => s === 0)).length}
                </span>
              </div>
            </div>

            <div className="animals-list">
              {animalsToJudge.map(animal => (
                <div key={animal.id} className="animal-item">
                  <div className="animal-info">
                    <h3>{animal.name} ({animal.ringNumber})</h3>
                    <p><strong>Cins:</strong> {animal.breed}</p>
                    <p><strong>Kategori:</strong> {animal.category}</p>
                    <p><strong>Sahibi:</strong> {animal.owner}</p>
                    <p><strong>Dernek:</strong> {animal.association}</p>
                  </div>
                  <div className="scoring-section">
                    <h4>Puanlama</h4>
                    <div className="score-inputs">
                      <div className="score-input">
                        <label>Görünüm (0-100):</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={animal.scores.appearance}
                          onChange={(e) => handleScoreChange(animal.id, 'appearance', parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <div className="score-input">
                        <label>Sağlık Durumu (0-100):</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={animal.scores.condition}
                          onChange={(e) => handleScoreChange(animal.id, 'condition', parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <div className="score-input">
                        <label>Irk Standardı (0-100):</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={animal.scores.breed_standard}
                          onChange={(e) => handleScoreChange(animal.id, 'breed_standard', parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <div className="score-input">
                        <label>Davranış (0-100):</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={animal.scores.behavior}
                          onChange={(e) => handleScoreChange(animal.id, 'behavior', parseInt(e.target.value) || 0)}
                        />
                      </div>
                    </div>
                    <button 
                      className="save-btn"
                      onClick={() => handleSubmitScores(animal.id)}
                    >
                      Puanları Kaydet
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Awards Tab */}
        {activeTab === 'awards' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Ödül Yönetimi</h2>
              <button className="add-button" onClick={handleAddAward}>
                + Yeni Ödül Ekle
              </button>
            </div>

            <div className="awards-list">
              {awards.map(award => (
                <div key={award.id} className="award-item">
                  <div className="award-info">
                    <h3>{award.name}</h3>
                    <p><strong>Açıklama:</strong> {award.description}</p>
                    <p><strong>Ödül:</strong> {award.prize}</p>
                    <p><strong>Yarışma:</strong> {competitions.find(c => c.id === award.competitionId)?.name}</p>
                  </div>
                  <div className="award-actions">
                    <span className={`award-status ${award.winnerId ? 'assigned' : 'unassigned'}`}>
                      {award.winnerId ? 'Atanmış' : 'Atanmamış'}
                    </span>
                    <div className="action-buttons">
                      <button className="edit-btn">
                        Düzenle
                      </button>
                      {!award.winnerId && (
                        <button 
                          className="assign-btn"
                          onClick={() => handleAssignAward(award.id, 'animal1')}
                        >
                          Ödül Ata
                        </button>
                      )}
                      <button className="delete-btn">
                        Sil
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Competitions Tab */}
        {activeTab === 'competitions' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Yarışma Listesi</h2>
              <div className="stats">
                <span className="stat-item">
                  <strong>Toplam Yarışma:</strong> {competitions.length}
                </span>
                <span className="stat-item">
                  <strong>Devam Eden:</strong> {competitions.filter(c => c.status === 'ONGOING').length}
                </span>
                <span className="stat-item">
                  <strong>Tamamlanan:</strong> {competitions.filter(c => c.status === 'COMPLETED').length}
                </span>
              </div>
            </div>

            <div className="competitions-list">
              {competitions.map(competition => (
                <div key={competition.id} className="competition-item">
                  <div className="competition-info">
                    <h3>{competition.name}</h3>
                    <p><strong>Tarih:</strong> {new Date(competition.date).toLocaleDateString('tr-TR')}</p>
                    <p><strong>Lokasyon:</strong> {competition.location}</p>
                    <p><strong>Katılımcı:</strong> {competition.totalParticipants}</p>
                    <p><strong>Değerlendirilen:</strong> {competition.judgedParticipants}</p>
                  </div>
                  <div className="competition-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(competition.status) }}
                    >
                      {getStatusText(competition.status)}
                    </span>
                    <div className="action-buttons">
                      <button className="edit-btn">
                        Detaylar
                      </button>
                      {competition.status === 'ONGOING' && (
                        <button className="status-btn">
                          Puanlama Yap
                        </button>
                      )}
                      <button className="export-btn">
                        Rapor İndir
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default JudgePage;
