import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    message: 'Süs Tavukları Yarışma Sistemi Backend çalışıyor!'
  });
});

app.get('/api/test', (req, res) => {
  res.json({
    message: 'Test endpoint başarılı!',
    data: {
      users: [
        { id: 1, name: 'Test User', role: 'ADMIN' }
      ]
    }
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Backend server çalışıyor: http://localhost:${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🧪 Test endpoint: http://localhost:${PORT}/api/test`);
});
