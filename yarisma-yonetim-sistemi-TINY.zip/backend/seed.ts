import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create Federation
  const federation = await prisma.federation.upsert({
    where: { name: 'Türkiye Süs Tavukları Federasyonu' },
    update: {},
    create: {
      name: 'Türkiye Süs Tavukları Federasyonu',
      description: 'Ana federasyon'
    }
  });

  // Create Association
  const association = await prisma.association.upsert({
    where: { code: 'IST001' },
    update: {},
    create: {
      name: 'İstanbul Süs Tavukları Derneği',
      code: 'IST001',
      description: 'İstanbul bölgesi derneği',
      federationId: federation.id
    }
  });

  // Create Superadmin
  const superAdminPassword = await bcrypt.hash('admin123', 12);
  const superAdmin = await prisma.user.upsert({
    where: { email: 'admin@sustavuklari.org' },
    update: {},
    create: {
      email: 'admin@sustavuklari.org',
      password: superAdminPassword,
      firstName: 'Sistem',
      lastName: 'Yöneticisi',
      role: 'SUPERADMIN',
      phone: '+90 212 123 45 69',
      isApproved: true
    }
  });

  // Create Federation User
  const federationPassword = await bcrypt.hash('federation123', 12);
  const federationUser = await prisma.user.upsert({
    where: { email: 'federation@sustavuklari.org' },
    update: {},
    create: {
      email: 'federation@sustavuklari.org',
      password: federationPassword,
      firstName: 'Federasyon',
      lastName: 'Yöneticisi',
      role: 'FEDERATION',
      phone: '+90 212 123 45 70',
      federationId: federation.id,
      isApproved: true
    }
  });

  // Create President
  const presidentPassword = await bcrypt.hash('president123', 12);
  const president = await prisma.user.upsert({
    where: { email: 'president@istankulub.org' },
    update: {},
    create: {
      email: 'president@istankulub.org',
      password: presidentPassword,
      firstName: 'Dernek',
      lastName: 'Başkanı',
      role: 'PRESIDENT',
      phone: '+90 212 123 45 71',
      associationId: association.id,
      isApproved: true
    }
  });

  // Update association with president
  await prisma.association.update({
    where: { id: association.id },
    data: { presidentId: president.id }
  });

  // Create Judge
  const judgePassword = await bcrypt.hash('judge123', 12);
  const judge = await prisma.user.upsert({
    where: { email: 'judge@sustavuklari.org' },
    update: {},
    create: {
      email: 'judge@sustavuklari.org',
      password: judgePassword,
      firstName: 'Hakem',
      lastName: 'Kullanıcı',
      role: 'JUDGE',
      phone: '+90 212 123 45 72',
      federationId: federation.id,
      isApproved: true
    }
  });

  // Create Member
  const memberPassword = await bcrypt.hash('member123', 12);
  const member = await prisma.user.upsert({
    where: { email: 'member@istankulub.org' },
    update: {},
    create: {
      email: 'member@istankulub.org',
      password: memberPassword,
      firstName: 'Dernek',
      lastName: 'Üyesi',
      role: 'MEMBER',
      phone: '+90 212 123 45 73',
      associationId: association.id,
      isApproved: true,
      approvedBy: president.id,
      approvedAt: new Date()
    }
  });

  // Create Animal Types
  const animalTypes = [
    { name: 'Brahma', description: 'Büyük cüsseli tavuk' },
    { name: 'Cochin', description: 'Tüylü ayaklı tavuk' },
    { name: 'Orpington', description: 'Yumurta tavuğu' },
    { name: 'Rhode Island Red', description: 'Klasik tavuk türü' },
    { name: 'Sultan', description: 'Süs tavuğu' },
    { name: 'Wyandotte', description: 'Çift amaçlı tavuk' },
    { name: 'Leghorn', description: 'Yumurta tavuğu' },
    { name: 'Sussex', description: 'Çift amaçlı tavuk' },
    { name: 'Güvercin', description: 'Süs güvercini' },
    { name: 'Kumru', description: 'Süs kumrusu' },
    { name: 'Toulouse Kazı', description: 'Büyük kaz türü' },
    { name: 'Emden Kazı', description: 'Beyaz kaz türü' },
    { name: 'Çin Kazı', description: 'Küçük kaz türü' },
    { name: 'Pekin Ördeği', description: 'Süs ördeği' },
    { name: 'Muscovy Ördeği', description: 'Büyük ördek türü' },
    { name: 'Call Ördeği', description: 'Küçük ördek türü' },
    { name: 'Bronze Hindi', description: 'Klasik hindi türü' },
    { name: 'White Holland Hindi', description: 'Beyaz hindi türü' },
    { name: 'Narragansett Hindi', description: 'Gri hindi türü' },
    { name: 'Holland Lop', description: 'Küçük tavşan türü' },
    { name: 'Flemish Giant', description: 'Büyük tavşan türü' },
    { name: 'Mini Rex', description: 'Küçük tavşan türü' }
  ];

  for (const typeData of animalTypes) {
    await prisma.animalType.upsert({
      where: { name: typeData.name },
      update: {},
      create: typeData
    });
  }

  // Create default pages
  const defaultPages = [
    {
      name: 'dashboard',
      title: 'Ana Sayfa',
      description: 'Sistem ana sayfası',
      path: '/dashboard',
      icon: '🏠',
      color: '#667eea',
      shape: 'square',
      order: 1,
      permissions: [
        { role: 'SUPERADMIN', canView: true, canEdit: false, canDelete: false },
        { role: 'FEDERATION', canView: true, canEdit: false, canDelete: false },
        { role: 'PRESIDENT', canView: true, canEdit: false, canDelete: false },
        { role: 'JUDGE', canView: true, canEdit: false, canDelete: false },
        { role: 'MEMBER', canView: true, canEdit: false, canDelete: false }
      ]
    },
    {
      name: 'admin',
      title: 'Sistem Ayarları',
      description: 'Sistem yönetim sayfası',
      path: '/admin',
      icon: '⚙️',
      color: '#f56565',
      shape: 'rounded',
      order: 2,
      permissions: [
        { role: 'SUPERADMIN', canView: true, canEdit: true, canDelete: false }
      ]
    },
    {
      name: 'animal-registration',
      title: 'Hayvan Kayıt',
      description: 'Hayvan kayıt sayfası',
      path: '/animal-registration',
      icon: '🐔',
      color: '#48bb78',
      shape: 'circle',
      order: 3,
      permissions: [
        { role: 'MEMBER', canView: true, canEdit: true, canDelete: false }
      ]
    },
    {
      name: 'animals',
      title: 'Hayvan Listesi',
      description: 'Kayıtlı hayvanları görüntüleme',
      path: '/animals',
      icon: '📋',
      color: '#ed8936',
      shape: 'square',
      order: 4,
      permissions: [
        { role: 'FEDERATION', canView: true, canEdit: true, canDelete: true },
        { role: 'MEMBER', canView: true, canEdit: false, canDelete: false },
        { role: 'PRESIDENT', canView: true, canEdit: true, canDelete: false }
      ]
    },
    {
      name: 'data-upload',
      title: 'Veri Yükleme',
      description: 'Excel ile veri yükleme sayfası',
      path: '/data-upload',
      icon: '📊',
      color: '#9f7aea',
      shape: 'rounded',
      order: 5,
      permissions: [
        { role: 'SUPERADMIN', canView: true, canEdit: true, canDelete: false }
      ]
    }
  ];

  for (const pageData of defaultPages) {
    const { permissions, ...pageInfo } = pageData;
    
    const page = await prisma.page.upsert({
      where: { name: pageData.name },
      update: pageInfo,
      create: pageInfo
    });

    // Create permissions for this page
    for (const permission of permissions) {
      await prisma.pagePermission.upsert({
        where: {
          pageId_role: {
            pageId: page.id,
            role: permission.role
          }
        },
        update: permission,
        create: {
          pageId: page.id,
          ...permission
        }
      });
    }
  }

  console.log('✅ Database seeded successfully!');
  console.log('\n🔐 Test Kullanıcıları:');
  console.log('Süperadmin: admin@sustavuklari.org / admin123');
  console.log('Federasyon: federation@sustavuklari.org / federation123');
  console.log('Başkan: president@istankulub.org / president123');
  console.log('Hakem: judge@sustavuklari.org / judge123');
  console.log('Üye: member@istankulub.org / member123');
  console.log('\n📄 Örnek Sayfalar:');
  console.log('- Ana Sayfa (/dashboard)');
  console.log('- Sistem Ayarları (/admin)');
  console.log('- Hayvan Kayıt (/animal-registration)');
  console.log('- Hayvan Listesi (/animals)');
  console.log('- Veri Yükleme (/data-upload)');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });