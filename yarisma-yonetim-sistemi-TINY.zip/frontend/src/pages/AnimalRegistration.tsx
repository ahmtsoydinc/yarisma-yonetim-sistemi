import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { animalsAPI, animalTypesAPI } from '../services/api';
import toast from 'react-hot-toast';

const AnimalRegistration: React.FC = () => {
  const { user } = useAuth();
  const [animalTypes, setAnimalTypes] = useState<any[]>([]);
  const [animalColors, setAnimalColors] = useState<any[]>([]);
  const [selectedTypeId, setSelectedTypeId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    ringNumber: '',
    name: '',
    gender: '',
    birthDate: '',
    animalTypeId: '',
    animalColorId: '',
    notes: ''
  });

  useEffect(() => {
    loadAnimalTypes();
  }, []);

  useEffect(() => {
    if (selectedTypeId) {
      loadAnimalColors(selectedTypeId);
    } else {
      setAnimalColors([]);
    }
  }, [selectedTypeId]);

  const loadAnimalTypes = async () => {
    try {
      const response = await animalTypesAPI.getAnimalTypes();
      setAnimalTypes(response.animalTypes);
    } catch (error: any) {
      toast.error('Hayvan türleri yüklenirken hata oluştu');
      console.error('Error loading animal types:', error);
    }
  };

  const loadAnimalColors = async (animalTypeId: string) => {
    try {
      const response = await animalTypesAPI.getAnimalColors({ animalTypeId });
      setAnimalColors(response.animalColors);
    } catch (error: any) {
      toast.error('Hayvan renkleri yüklenirken hata oluştu');
      console.error('Error loading animal colors:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Hayvan türü değiştiğinde renkleri temizle
    if (name === 'animalTypeId') {
      setSelectedTypeId(value);
      setFormData(prev => ({
        ...prev,
        animalColorId: ''
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.ringNumber || !formData.animalTypeId || !formData.animalColorId) {
      toast.error('Bilezik numarası, hayvan türü ve rengi zorunludur');
      return;
    }

    setLoading(true);
    try {
      await animalsAPI.createAnimal(formData);
      toast.success('Hayvan başarıyla kaydedildi!');
      
      // Formu temizle
      setFormData({
        ringNumber: '',
        name: '',
        gender: '',
        birthDate: '',
        animalTypeId: '',
        animalColorId: '',
        notes: ''
      });
      setSelectedTypeId('');
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Hayvan kaydedilirken hata oluştu');
      console.error('Error creating animal:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="simple-admin">
      <h1>Hayvan Kayıt Sistemi</h1>
      
      <div className="admin-section">
        <h2>Yeni Hayvan Kaydı</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="ringNumber">Bilezik Numarası *</label>
            <input
              type="text"
              id="ringNumber"
              name="ringNumber"
              value={formData.ringNumber}
              onChange={handleInputChange}
              placeholder="Örn: TR2024001"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="name">Hayvan Adı</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              placeholder="Hayvanın adı (isteğe bağlı)"
            />
          </div>

          <div className="form-group">
            <label htmlFor="gender">Cinsiyet</label>
            <select
              id="gender"
              name="gender"
              value={formData.gender}
              onChange={handleInputChange}
            >
              <option value="">Seçiniz</option>
              <option value="Erkek">Erkek</option>
              <option value="Dişi">Dişi</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="birthDate">Doğum Tarihi</label>
            <input
              type="date"
              id="birthDate"
              name="birthDate"
              value={formData.birthDate}
              onChange={handleInputChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="animalTypeId">Hayvan Türü *</label>
            <select
              id="animalTypeId"
              name="animalTypeId"
              value={formData.animalTypeId}
              onChange={handleInputChange}
              required
            >
              <option value="">Hayvan türü seçiniz</option>
              {animalTypes.map((type) => (
                <option key={type.id} value={type.id}>
                  {type.name} ({type.breed})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="animalColorId">Renk *</label>
            <select
              id="animalColorId"
              name="animalColorId"
              value={formData.animalColorId}
              onChange={handleInputChange}
              required
              disabled={!selectedTypeId}
            >
              <option value="">
                {selectedTypeId ? 'Renk seçiniz' : 'Önce hayvan türü seçiniz'}
              </option>
              {animalColors.map((color) => (
                <option key={color.id} value={color.id}>
                  {color.name}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="notes">Notlar</label>
            <textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              rows={3}
              placeholder="Ek bilgiler (isteğe bağlı)"
            />
          </div>

          <button type="submit" disabled={loading}>
            {loading ? 'Kaydediliyor...' : 'Hayvanı Kaydet'}
          </button>
        </form>
      </div>

      <div className="admin-section">
        <h2>Hayvan Cinsleri</h2>
        <div className="breed-info">
          <p>Sistemde kayıtlı hayvan cinsleri:</p>
          <ul>
            <li><strong>Tavuk:</strong> Çeşitli tavuk türleri</li>
            <li><strong>Horoz:</strong> Çeşitli horoz türleri</li>
            <li><strong>Güvercin:</strong> Çeşitli güvercin türleri</li>
            <li><strong>Kaz:</strong> Çeşitli kaz türleri</li>
            <li><strong>Ördek:</strong> Çeşitli ördek türleri</li>
            <li><strong>Hindi:</strong> Çeşitli hindi türleri</li>
            <li><strong>Tavşan:</strong> Çeşitli tavşan türleri</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AnimalRegistration;
