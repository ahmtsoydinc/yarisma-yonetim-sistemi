# 🚀 Vercel Deployment Rehberi

## 📋 Vercel Deployment Adımları

### 1. Vercel Hesabı Oluşturma
- [vercel.com](https://vercel.com) adresine gidin
- GitHub hesabınızla giriş yapın
- "Sign up" butonuna tıklayın

### 2. Proje Import Etme
1. Vercel dashboard'da "Add New Project" butonuna tıklayın
2. GitHub repository'nizi seçin: `ahmtsoydinc/yarisma-yonetim-sistemi`
3. "Import" butonuna tıklayın

### 3. Build Ayarları
```
Framework Preset: Create React App
Root Directory: . (ana dizin)
Build Command: cd frontend && npm run vercel-build
Output Directory: frontend/build
Install Command: cd frontend && npm install
```

**ÖNEMLİ:** Root Directory olarak `.` (ana dizin) seçin, `frontend` değil!

### 4. Environment Variables
```bash
REACT_APP_API_URL=https://your-backend-url.railway.app
REACT_APP_DEBUG=false
REACT_APP_VERSION=1.0.0
REACT_APP_NAME=TSHF Süs Tavukları Yarışma Sistemi
```

### 5. Deployment
1. "Deploy" butonuna tıklayın
2. Build sürecini bekleyin (2-5 dakika)
3. Deployment tamamlandığında URL alacaksınız

## 🔧 Vercel Deployment Hataları ve Çözümleri

### Build Hataları

#### 1. TypeScript Hataları
```bash
# Hata: TypeScript compilation errors
# Çözüm: CI=false environment variable ekleyin
CI=false npm run build
```

#### 2. Memory Limit Hataları
```bash
# Hata: JavaScript heap out of memory
# Çözüm: Node.js memory limit artırın
NODE_OPTIONS="--max-old-space-size=4096" npm run build
```

#### 3. Dependencies Hataları
```bash
# Hata: Module not found
# Çözüm: package-lock.json silin ve yeniden install
rm package-lock.json
npm install
```

### Runtime Hataları

#### 1. API Connection Hataları
```javascript
// Hata: Network request failed
// Çözüm: CORS ayarlarını kontrol edin
// Backend'te CORS middleware ekleyin
app.use(cors({
  origin: ['https://your-vercel-app.vercel.app'],
  credentials: true
}));
```

#### 2. Environment Variables Hataları
```bash
# Hata: REACT_APP_API_URL is undefined
# Çözüm: Vercel dashboard'da environment variables ekleyin
REACT_APP_API_URL=https://your-backend.railway.app
```

#### 3. 404 Routing Hataları
```json
// vercel.json routing ayarları
{
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/index.html"
    }
  ]
}
```

## 🛠️ Vercel Optimizasyonları

### 1. Build Optimizasyonu
```json
// package.json
{
  "scripts": {
    "vercel-build": "CI=false GENERATE_SOURCEMAP=false react-scripts build"
  }
}
```

### 2. Caching Ayarları
```json
// vercel.json
{
  "routes": [
    {
      "src": "/static/(.*)",
      "dest": "/static/$1",
      "headers": {
        "Cache-Control": "public, max-age=31536000, immutable"
      }
    }
  ]
}
```

### 3. Security Headers
```json
// vercel.json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        }
      ]
    }
  ]
}
```

## 🔍 Debug ve Monitoring

### 1. Vercel Analytics
- Vercel dashboard'da "Analytics" sekmesini kullanın
- Performance metriklerini izleyin

### 2. Function Logs
- "Functions" sekmesinde API endpoint loglarını görün
- Error tracking için Sentry entegrasyonu yapın

### 3. Build Logs
- Her deployment'ın build loglarını kontrol edin
- TypeScript hatalarını buradan takip edin

## 🚨 Yaygın Hatalar ve Çözümleri

### 1. Domain Hataları
```
Hata: Domain not found
Çözüm: Custom domain eklerken DNS ayarlarını kontrol edin
```

### 2. Build Timeout
```
Hata: Build timeout
Çözüm: Build command'ı optimize edin, gereksiz dependencies kaldırın
```

### 3. Environment Variables
```
Hata: Environment variables not loaded
Çözüm: REACT_APP_ prefix'ini kullandığınızdan emin olun
```

## 📊 Performance İpuçları

### 1. Bundle Size Optimization
```bash
# Bundle analyzer kullanın
npm install --save-dev @craco/craco
npx webpack-bundle-analyzer build/static/js/*.js
```

### 2. Image Optimization
```javascript
// Next.js Image component kullanın (React için)
import { Image } from 'next/image'

// Veya lazy loading
<img loading="lazy" src="..." alt="..." />
```

### 3. Code Splitting
```javascript
// React.lazy kullanın
const LazyComponent = React.lazy(() => import('./LazyComponent'));

// Suspense ile wrap edin
<Suspense fallback={<div>Loading...</div>}>
  <LazyComponent />
</Suspense>
```

## 🎯 Deployment Checklist

- [ ] GitHub repository hazır
- [ ] Backend Railway'de deploy edildi
- [ ] Environment variables ayarlandı
- [ ] vercel.json konfigürasyonu yapıldı
- [ ] Build script'leri optimize edildi
- [ ] CORS ayarları yapıldı
- [ ] Security headers eklendi
- [ ] Performance optimizasyonları yapıldı
- [ ] Test deployment yapıldı
- [ ] Production deployment tamamlandı

## 📞 Destek

Sorun yaşarsanız:
1. Vercel dashboard'daki build logs'u kontrol edin
2. Browser console'da JavaScript hatalarını kontrol edin
3. Network tab'ında API isteklerini kontrol edin
4. Vercel community forum'unda arama yapın

---

**Not:** Bu rehber Vercel deployment sırasında karşılaşılabilecek tüm yaygın hataları ve çözümlerini içermektedir.
