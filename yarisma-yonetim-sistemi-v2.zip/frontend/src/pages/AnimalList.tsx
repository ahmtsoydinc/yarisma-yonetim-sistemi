import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { animalsAPI } from '../services/api';
import toast from 'react-hot-toast';

const AnimalList: React.FC = () => {
  const { user } = useAuth();
  const [animals, setAnimals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    pages: 0
  });

  useEffect(() => {
    loadAnimals();
  }, [pagination.page]);

  const loadAnimals = async () => {
    try {
      setLoading(true);
      const response = await animalsAPI.getAnimals({
        page: pagination.page,
        limit: pagination.limit
      });
      setAnimals(response.animals);
      setPagination(response.pagination);
    } catch (error: any) {
      toast.error('Hayvanlar yüklenirken hata oluştu');
      console.error('Error loading animals:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAnimal = async (id: string, ringNumber: string) => {
    if (window.confirm(`${ringNumber} numaralı hayvanı silmek istediğinizden emin misiniz?`)) {
      try {
        await animalsAPI.deleteAnimal(id);
        toast.success('Hayvan başarıyla silindi');
        loadAnimals();
      } catch (error: any) {
        toast.error(error.response?.data?.error || 'Hayvan silinirken hata oluştu');
        console.error('Error deleting animal:', error);
      }
    }
  };

  const handlePageChange = (newPage: number) => {
    setPagination(prev => ({ ...prev, page: newPage }));
  };

  const getStatusBadge = (status: string) => {
    const statusMap: { [key: string]: { text: string; className: string } } = {
      'PENDING': { text: 'Beklemede', className: 'status-pending' },
      'APPROVED': { text: 'Onaylandı', className: 'status-approved' },
      'REJECTED': { text: 'Reddedildi', className: 'status-rejected' },
      'PARTICIPATING': { text: 'Katılıyor', className: 'status-participating' },
      'COMPLETED': { text: 'Tamamlandı', className: 'status-completed' }
    };
    
    const statusInfo = statusMap[status] || { text: status, className: 'status-unknown' };
    return <span className={`status-badge ${statusInfo.className}`}>{statusInfo.text}</span>;
  };

  if (loading) {
    return (
      <div className="simple-admin">
        <h1>Hayvan Listesi</h1>
        <div className="admin-section">
          <p>Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="simple-admin">
      <h1>Hayvan Listesi</h1>
      
      <div className="admin-section">
        <h2>Kayıtlı Hayvanlar</h2>
        
        {animals.length === 0 ? (
          <p>Henüz kayıtlı hayvan bulunmuyor.</p>
        ) : (
          <>
            <table>
              <thead>
                <tr>
                  <th>Bilezik No</th>
                  <th>Ad</th>
                  <th>Cinsiyet</th>
                  <th>Tür</th>
                  <th>Renk</th>
                  <th>Doğum Tarihi</th>
                  <th>Durum</th>
                  <th>Sahibi</th>
                  <th>İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {animals.map((animal) => (
                  <tr key={animal.id}>
                    <td><strong>{animal.ringNumber}</strong></td>
                    <td>{animal.name || '-'}</td>
                    <td>{animal.gender || '-'}</td>
                    <td>
                      {animal.animalType?.name}
                      <br />
                      <small>({animal.animalType?.breed})</small>
                    </td>
                    <td>{animal.animalColor?.name}</td>
                    <td>
                      {animal.birthDate 
                        ? new Date(animal.birthDate).toLocaleDateString('tr-TR')
                        : '-'
                      }
                    </td>
                    <td>{getStatusBadge(animal.registrationStatus)}</td>
                    <td>
                      {animal.owner?.firstName} {animal.owner?.lastName}
                      <br />
                      <small>{animal.owner?.email}</small>
                    </td>
                    <td>
                      <button 
                        onClick={() => alert(`Düzenle: ${animal.ringNumber}`)}
                        className="btn-edit"
                      >
                        Düzenle
                      </button>
                      <button 
                        onClick={() => handleDeleteAnimal(animal.id, animal.ringNumber)}
                        className="btn-delete"
                      >
                        Sil
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Pagination */}
            {pagination.pages > 1 && (
              <div className="pagination">
                <button 
                  onClick={() => handlePageChange(pagination.page - 1)}
                  disabled={pagination.page === 1}
                >
                  Önceki
                </button>
                
                <span>
                  Sayfa {pagination.page} / {pagination.pages} 
                  (Toplam {pagination.total} kayıt)
                </span>
                
                <button 
                  onClick={() => handlePageChange(pagination.page + 1)}
                  disabled={pagination.page === pagination.pages}
                >
                  Sonraki
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AnimalList;
