import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import * as XLSX from 'xlsx';
import { pagesAPI, usersAPI } from '../services/api';

const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'users' | 'animals' | 'types' | 'colors' | 'pages' | 'presidents' | 'competitions' | 'cages'>('users');
  
  // Load pages function
  const loadPages = async () => {
    try {
      const response = await pagesAPI.getPages();
      setPages(response.pages);
    } catch (error) {
      console.error('Sayfalar yüklenirken hata:', error);
    }
  };

  // Load pages on component mount
  React.useEffect(() => {
    if (activeTab === 'pages') {
      loadPages();
    }
  }, [activeTab]);

  // Pages state
  const [pages, setPages] = useState<any[]>([]);
  const [showPageModal, setShowPageModal] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [showRoleAssignmentModal, setShowRoleAssignmentModal] = useState(false);
  const [editingPage, setEditingPage] = useState<any>(null);
  const [selectedPage, setSelectedPage] = useState<any>(null);
  const [selectedRole, setSelectedRole] = useState('SUPERADMIN');
  const [rolePermissions, setRolePermissions] = useState<any>({});
  const [newPage, setNewPage] = useState({
    name: '',
    title: '',
    path: '',
    icon: '',
    color: '',
    shape: '',
    description: '',
    order: 0,
    isActive: true,
    isVisible: true
  });
  
  // User management states
  const [users] = useState<any[]>([]);
  
  // President management states
  const [newPresident, setNewPresident] = useState({
    email: '',
    firstName: '',
    lastName: '',
    phone: '',
    associationId: ''
  });
  
  // Competition management states
  const [newCompetition, setNewCompetition] = useState({
    name: '',
    date: '',
    location: '',
    maxParticipants: 0
  });
  
  // Cage management states
  const [cageAssignments] = useState<any[]>([]);
  const [approvedAnimals] = useState<any[]>([]);
  const [cageStatistics] = useState({
    totalCages: 0,
    occupiedCages: 0,
    availableCages: 0,
    assignedAnimals: 0,
    pendingAssignments: 0,
    completedAssignments: 0
  });
  const [newUser, setNewUser] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    role: 'MEMBER',
    phone: ''
  });

  // Animal management states
  const [animals] = useState<any[]>([]);
  const [newAnimal, setNewAnimal] = useState({
    ringNumber: '',
    name: '',
    gender: '',
    animalTypeId: '',
    color: '',
    age: '',
    weight: '',
    notes: ''
  });

  // Page management states
  const [pages] = useState<any[]>([
    { id: '1', name: 'Dashboard', title: 'Ana Sayfa', path: '/dashboard', icon: '🏠', color: '#667eea', isActive: true, isVisible: true, order: 1 },
    { id: '2', name: 'Admin Panel', title: 'Yönetici Paneli', path: '/admin', icon: '⚙️', color: '#f59e0b', isActive: true, isVisible: true, order: 2 },
    { id: '3', name: 'Federasyon', title: 'Federasyon Paneli', path: '/federation', icon: '🏛️', color: '#10b981', isActive: true, isVisible: true, order: 3 },
    { id: '4', name: 'Başkan', title: 'Başkan Paneli', path: '/president', icon: '👨‍💼', color: '#8b5cf6', isActive: true, isVisible: true, order: 4 },
    { id: '5', name: 'Hakem', title: 'Hakem Paneli', path: '/judge', icon: '⚖️', color: '#ef4444', isActive: true, isVisible: true, order: 5 },
    { id: '6', name: 'Üye', title: 'Üye Paneli', path: '/member', icon: '👤', color: '#06b6d4', isActive: true, isVisible: true, order: 6 },
    { id: '7', name: 'Hayvan Kayıt', title: 'Hayvan Kaydı', path: '/animal-registration', icon: '🐓', color: '#84cc16', isActive: true, isVisible: true, order: 7 },
    { id: '8', name: 'Hayvan Listesi', title: 'Hayvanlar', path: '/animals', icon: '📋', color: '#f97316', isActive: true, isVisible: true, order: 8 }
  ]);
  const [newPage, setNewPage] = useState({
    name: '',
    title: '',
    path: '',
    icon: '',
    color: '#667eea',
    shape: 'square',
    description: '',
    order: 0,
    isActive: true,
    isVisible: true
  });
  
  // Modal states for page management
  const [showPageModal, setShowPageModal] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [showRoleAssignmentModal, setShowRoleAssignmentModal] = useState(false);
  const [editingPage, setEditingPage] = useState<any>(null);
  const [selectedPage, setSelectedPage] = useState<any>(null);

  // President management states
  const [presidents] = useState<any[]>([]);
  const [newPresident, setNewPresident] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    phone: '',
    associationId: ''
  });

  // Competition management states
  const [competitions] = useState<any[]>([]);
  const [newCompetition, setNewCompetition] = useState({
    name: '',
    description: '',
    startDate: '',
    endDate: '',
    location: '',
    status: 'PLANNED',
    federationId: ''
  });

  // Cage assignment states
  const [approvedAnimals] = useState<any[]>([
    { id: '1', ringNumber: 'TR001', name: 'Altın Horoz', gender: 'ERKEK', type: 'Büyük Irk', breed: 'Cochin', owner: 'Ahmet Yılmaz', association: 'İstanbul Derneği', cage: null },
    { id: '2', ringNumber: 'TR002', name: 'Gümüş Tavuk', gender: 'DİŞİ', type: 'Orta Irk', breed: 'Leghorn', owner: 'Ayşe Demir', association: 'Ankara Derneği', cage: null },
    { id: '3', ringNumber: 'TR003', name: 'Kahverengi Civciv', gender: 'ERKEK', type: 'Küçük Irk', breed: 'Serama', owner: 'Mehmet Kaya', association: 'İzmir Derneği', cage: null },
    { id: '4', ringNumber: 'TR004', name: 'Beyaz Horoz', gender: 'ERKEK', type: 'Büyük Irk', breed: 'Brahma', owner: 'Fatma Öz', association: 'İstanbul Derneği', cage: null },
    { id: '5', ringNumber: 'TR005', name: 'Siyah Tavuk', gender: 'DİŞİ', type: 'Orta Irk', breed: 'Australorp', owner: 'Ali Veli', association: 'Ankara Derneği', cage: null }
  ]);
  
  const [cageAssignments] = useState<any[]>([
    { id: '1', cageNumber: 'K001', size: 'Büyük', capacity: 4, assignedAnimals: ['TR001', 'TR004'], status: 'DOLU' },
    { id: '2', cageNumber: 'K002', size: 'Orta', capacity: 6, assignedAnimals: ['TR002'], status: 'KISMEN' },
    { id: '3', cageNumber: 'K003', size: 'Küçük', capacity: 8, assignedAnimals: ['TR003'], status: 'KISMEN' },
    { id: '4', cageNumber: 'K004', size: 'Orta', capacity: 6, assignedAnimals: ['TR005'], status: 'KISMEN' }
  ]);

  const [cageStatistics] = useState({
    totalCages: 4,
    largeCages: 1,
    mediumCages: 2,
    smallCages: 1,
    totalAnimals: 5,
    assignedAnimals: 5,
    unassignedAnimals: 0
  });

  // Other states
  const [selectedRole, setSelectedRole] = useState('SUPERADMIN');
  const [availableAssociations] = useState<any[]>([
    { id: '1', name: 'İstanbul Süs Tavukları Derneği' },
    { id: '2', name: 'Ankara Süs Tavukları Derneği' },
    { id: '3', name: 'İzmir Süs Tavukları Derneği' }
  ]);

  // User management functions
  const handleAddUser = () => {
    if (!newUser.email || !newUser.firstName || !newUser.lastName) {
      alert('Lütfen tüm zorunlu alanları doldurun!');
      return;
    }
    
    const user = {
      id: Date.now().toString(),
      ...newUser,
      isActive: true,
      createdAt: new Date().toISOString()
    };
    
    alert(`Yeni kullanıcı eklendi: ${user.firstName} ${user.lastName} (${user.email})`);
    setNewUser({
      email: '',
      password: '',
      firstName: '',
      lastName: '',
      role: 'MEMBER',
      phone: ''
    });
  };

  const handleEditUser = (id: string) => {
    const user = users.find(u => u.id === id);
    if (user) {
      alert(`Kullanıcı düzenleme formu açılacak: ${user.firstName} ${user.lastName}`);
    } else {
      alert('Kullanıcı bulunamadı!');
    }
  };

  const handleDeleteUser = (id: string) => {
    if (window.confirm('Bu kullanıcıyı silmek istediğinizden emin misiniz?')) {
      alert(`Kullanıcı silindi: ${id}`);
    }
  };

  // Animal management functions
  const handleAddAnimal = () => {
    if (!newAnimal.ringNumber || !newAnimal.name || !newAnimal.gender) {
      alert('Lütfen tüm zorunlu alanları doldurun!');
      return;
    }
    
    const animal = {
      id: Date.now().toString(),
      ...newAnimal,
      isActive: true,
      createdAt: new Date().toISOString()
    };
    
    alert(`Yeni hayvan eklendi: ${animal.name} (${animal.ringNumber})`);
    setNewAnimal({
      ringNumber: '',
      name: '',
      gender: '',
      animalTypeId: '',
      color: '',
      age: '',
      weight: '',
      notes: ''
    });
  };

  const handleEditAnimal = (id: string) => {
    alert(`Hayvan düzenleme formu açılacak: ${id}`);
  };

  const handleDeleteAnimal = (id: string) => {
    if (window.confirm('Bu hayvanı silmek istediğinizden emin misiniz?')) {
      alert(`Hayvan silindi: ${id}`);
    }
  };

  // Page management functions
  const handleAddPage = () => {
    if (!newPage.name || !newPage.title || !newPage.path) {
      alert('Lütfen tüm zorunlu alanları doldurun!');
      return;
    }
    
    const page = {
      id: Date.now().toString(),
      ...newPage,
      createdAt: new Date().toISOString()
    };
    
    alert(`Yeni sayfa eklendi: ${page.title} (${page.path})`);
    setNewPage({
      name: '',
      title: '',
      path: '',
      icon: '',
      color: '#667eea',
      shape: 'square',
      description: '',
      order: 0,
      isActive: true,
      isVisible: true
    });
  };

  const handleEditPage = (id: string) => {
    const page = pages.find(p => p.id === id);
    if (page) {
      setNewPage(page);
      setEditingPage(page);
      setShowPageModal(true);
    }
  };

  const handleDeletePage = async (id: string) => {
    if (window.confirm('Bu sayfayı silmek istediğinizden emin misiniz?')) {
      try {
        await pagesAPI.deletePage(id);
        // Reload pages after deletion
        loadPages();
        alert('Sayfa başarıyla silindi!');
      } catch (error) {
        console.error('Sayfa silme hatası:', error);
        alert('Sayfa silinirken bir hata oluştu!');
      }
    }
  };

  const handlePagePermissions = (id: string) => {
    const page = pages.find(p => p.id === id);
    if (page) {
      setSelectedPage(page);
      setShowPermissionsModal(true);
    }
  };

  const handleRoleAssignment = () => {
    setShowRoleAssignmentModal(true);
  };

  const handleSavePage = async () => {
    if (!newPage.name || !newPage.title || !newPage.path) {
      alert('Lütfen zorunlu alanları doldurun!');
      return;
    }

    try {
      if (editingPage) {
        // Update existing page
        await pagesAPI.updatePage(editingPage.id, newPage);
        alert('Sayfa başarıyla güncellendi!');
      } else {
        // Add new page
        const newPageData = {
          ...newPage,
          order: pages.length + 1
        };
        await pagesAPI.createPage(newPageData);
        alert('Yeni sayfa başarıyla eklendi!');
      }
      
      // Reload pages and reset form
      loadPages();
      setNewPage({ name: '', title: '', path: '', icon: '', description: '', isActive: true });
      setEditingPage(null);
      setShowPageModal(false);
    } catch (error) {
      console.error('Sayfa kaydetme hatası:', error);
      alert('Sayfa kaydedilirken bir hata oluştu!');
    }
  };
    setEditingPage(null);
    setNewPage({
      name: '',
      title: '',
      path: '',
      icon: '',
      color: '#667eea',
      shape: 'square',
      description: '',
      order: 0,
      isActive: true,
      isVisible: true
    });
  };

  const handleSavePermissions = (pageId: string, rolePermissions: any) => {
    if (!selectedPage) return;
    
    try {
      const permissions = Object.keys(rolePermissions).map(role => ({
        role,
        canView: rolePermissions[role],
        canEdit: false,
        canDelete: false
      }));
      
      await pagesAPI.updatePagePermissions(selectedPage.id, permissions);
      alert('Sayfa izinleri başarıyla güncellendi!');
      setShowPermissionsModal(false);
      setSelectedPage(null);
    } catch (error) {
      console.error('İzin güncelleme hatası:', error);
      alert('İzinler güncellenirken bir hata oluştu!');
    }
  };

  const handleSaveRoleAssignment = async (role: string, pageIds: string[]) => {
    try {
      // Update page access for the selected role
      for (const pageId of pageIds) {
        await pagesAPI.updatePagePermissions(pageId, [{
          role,
          canView: true,
          canEdit: false,
          canDelete: false
        }]);
      }
      alert(`${role} rolü için sayfa erişimleri başarıyla güncellendi!`);
      setShowRoleAssignmentModal(false);
      setSelectedRole('SUPERADMIN');
      loadPages(); // Reload pages to reflect changes
    } catch (error) {
      console.error('Rol atama hatası:', error);
      alert('Rol ataması yapılırken bir hata oluştu!');
    }
  };

  // President management functions
  const handleAddPresident = () => {
    if (!newPresident.email || !newPresident.firstName || !newPresident.lastName) {
      alert('Lütfen tüm zorunlu alanları doldurun!');
      return;
    }
    
    const president = {
      id: Date.now().toString(),
      ...newPresident,
      role: 'PRESIDENT',
      isActive: true,
      createdAt: new Date().toISOString()
    };
    
    alert(`Yeni başkan eklendi: ${president.firstName} ${president.lastName} (${president.email})`);
    setNewPresident({
      email: '',
      password: '',
      firstName: '',
      lastName: '',
      phone: '',
      associationId: ''
    });
  };

  const handleEditPresident = (id: string) => {
    alert(`Başkan düzenleme formu açılacak: ${id}`);
  };

  const handleDeletePresident = (id: string) => {
    if (window.confirm('Bu başkanı silmek istediğinizden emin misiniz?')) {
      alert(`Başkan silindi: ${id}`);
    }
  };

  const handleTogglePresidentStatus = (id: string) => {
    alert(`Başkan durumu değiştirildi: ${id}`);
  };

  // Competition management functions
  const handleCreateCompetition = () => {
    if (!newCompetition.name || !newCompetition.startDate || !newCompetition.location) {
      alert('Lütfen tüm zorunlu alanları doldurun!');
      return;
    }
    
    const competition = {
      id: Date.now().toString(),
      ...newCompetition,
      createdAt: new Date().toISOString()
    };
    
    alert(`Yeni yarışma oluşturuldu: ${competition.name} (${competition.location})`);
    setNewCompetition({
      name: '',
      description: '',
      startDate: '',
      endDate: '',
      location: '',
      status: 'PLANNED',
      federationId: ''
    });
  };

  const handleEditCompetition = (id: string) => {
    alert(`Yarışma düzenleme formu açılacak: ${id}`);
  };

  const handleDeleteCompetition = (id: string) => {
    if (window.confirm('Bu yarışmayı silmek istediğinizden emin misiniz?')) {
      alert(`Yarışma silindi: ${id}`);
    }
  };

  const handleCompetitionStatus = (id: string) => {
    alert(`Yarışma durumu değiştirildi: ${id}`);
  };

  // Cage assignment functions
  const handleAutoAssignCages = () => {
    alert('Otomatik kafes ataması başlatıldı!');
  };

  const handleChangeCage = (id: string) => {
    alert(`Kafes değiştirme formu açılacak: ${id}`);
  };

  const handleAnimalDetails = (id: string) => {
    alert(`Hayvan detayları açılacak: ${id}`);
  };

  const handleEditCage = (id: string) => {
    alert(`Kafes düzenleme formu açılacak: ${id}`);
  };

  const handleManageAnimals = (id: string) => {
    alert(`Hayvan yönetimi açılacak: ${id}`);
  };

  // Excel export function
  const exportToExcel = () => {
    // Kafes atamaları verisi
    const cageData = cageAssignments.map(cage => ({
      'Kafes No': cage.cageNumber,
      'Kafes Boyutu': cage.size,
      'Kapasite': cage.capacity,
      'Atanan Hayvan Sayısı': cage.assignedAnimals.length,
      'Durum': cage.status,
      'Atanan Hayvanlar': cage.assignedAnimals.join(', ')
    }));

    // Hayvan verisi
    const animalData = approvedAnimals.map(animal => ({
      'Bilezik No': animal.ringNumber,
      'Hayvan Adı': animal.name,
      'Cinsiyet': animal.gender,
      'Irk Türü': animal.type,
      'Cins': animal.breed,
      'Sahibi': animal.owner,
      'Dernek': animal.association,
      'Atanan Kafes': animal.cage || 'Atanmamış'
    }));

    // İstatistik verisi
    const statsData = [{
      'Toplam Kafes': cageStatistics.totalCages,
      'Büyük Kafes': cageStatistics.largeCages,
      'Orta Kafes': cageStatistics.mediumCages,
      'Küçük Kafes': cageStatistics.smallCages,
      'Toplam Hayvan': cageStatistics.totalAnimals,
      'Atanmış Hayvan': cageStatistics.assignedAnimals,
      'Atanmamış Hayvan': cageStatistics.unassignedAnimals
    }];

    // Excel workbook oluştur
    const wb = XLSX.utils.book_new();
    
    // Sayfalar oluştur
    const cageSheet = XLSX.utils.json_to_sheet(cageData);
    const animalSheet = XLSX.utils.json_to_sheet(animalData);
    const statsSheet = XLSX.utils.json_to_sheet(statsData);

    // Sayfaları workbook'a ekle
    XLSX.utils.book_append_sheet(wb, cageSheet, 'Kafes Atamaları');
    XLSX.utils.book_append_sheet(wb, animalSheet, 'Hayvan Listesi');
    XLSX.utils.book_append_sheet(wb, statsSheet, 'İstatistikler');

    // Excel dosyasını indir
    const fileName = `kafes-atamalari-${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    alert('Excel dosyası başarıyla indirildi!');
  };

  if (user?.role !== 'SUPERADMIN') {
    return (
      <div className="admin-dashboard">
        <div className="access-denied">
          <h2>Erişim Reddedildi</h2>
          <p>Bu sayfaya erişim yetkiniz bulunmamaktadır.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      <div className="dashboard-header">
        <h1 className="dashboard-title">Süper Admin Paneli</h1>
        <p className="dashboard-subtitle">Sistem yönetimi ve konfigürasyon</p>
      </div>

      <div className="admin-tabs">
        <button
          className={`tab-button ${activeTab === 'users' ? 'active' : ''}`}
          onClick={() => setActiveTab('users')}
        >
          Kullanıcı Yönetimi
        </button>
        <button
          className={`tab-button ${activeTab === 'animals' ? 'active' : ''}`}
          onClick={() => setActiveTab('animals')}
        >
          Hayvan Yönetimi
        </button>
        <button
          className={`tab-button ${activeTab === 'pages' ? 'active' : ''}`}
          onClick={() => setActiveTab('pages')}
        >
          Sayfa Yönetimi
        </button>
        <button
          className={`tab-button ${activeTab === 'presidents' ? 'active' : ''}`}
          onClick={() => setActiveTab('presidents')}
        >
          Başkan Yönetimi
        </button>
        <button
          className={`tab-button ${activeTab === 'competitions' ? 'active' : ''}`}
          onClick={() => setActiveTab('competitions')}
        >
          Yarışma Yönetimi
        </button>
        <button
          className={`tab-button ${activeTab === 'cages' ? 'active' : ''}`}
          onClick={() => setActiveTab('cages')}
        >
          Kafes Ataması
        </button>
      </div>

      <div className="admin-content">
        {activeTab === 'users' && (
          <div className="tab-content">
            <h2>Kullanıcı Yönetimi</h2>
            
            <div className="feature-card">
              <h3>Yeni Kullanıcı Ekle</h3>
              <div className="form-grid">
                <input
                  type="text"
                  placeholder="Ad"
                  value={newUser.firstName}
                  onChange={(e) => setNewUser({...newUser, firstName: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="Soyad"
                  value={newUser.lastName}
                  onChange={(e) => setNewUser({...newUser, lastName: e.target.value})}
                />
                <input
                  type="email"
                  placeholder="E-posta"
                  value={newUser.email}
                  onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                />
                <input
                  type="password"
                  placeholder="Şifre"
                  value={newUser.password}
                  onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                />
                <input
                  type="tel"
                  placeholder="Telefon"
                  value={newUser.phone}
                  onChange={(e) => setNewUser({...newUser, phone: e.target.value})}
                />
                <select
                  value={newUser.role}
                  onChange={(e) => setNewUser({...newUser, role: e.target.value})}
                >
                  <option value="MEMBER">Üye</option>
                  <option value="PRESIDENT">Başkan</option>
                  <option value="JUDGE">Hakem</option>
                  <option value="FEDERATION">Federasyon</option>
                  <option value="SUPERADMIN">Süper Admin</option>
                </select>
              </div>
              <button 
                className="feature-button" 
                onClick={handleAddUser}
              >
                Kullanıcı Ekle
              </button>
            </div>

            <div className="feature-card">
              <h3>Mevcut Kullanıcılar</h3>
              <div className="user-list">
                {users.map((user) => (
                  <div key={user.id} className="user-item">
                    <div className="user-info">
                      <span className="user-name">{user.firstName} {user.lastName}</span>
                      <span className="user-email">{user.email}</span>
                      <span className={`user-role ${user.role.toLowerCase()}`}>{user.role}</span>
                    </div>
                    <div className="user-actions">
                      <button className="edit-btn" onClick={() => handleEditUser(user.id)}>Düzenle</button>
                      <button className="delete-btn" onClick={() => handleDeleteUser(user.id)}>Sil</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'animals' && (
          <div className="tab-content">
            <h2>Hayvan Yönetimi</h2>
            
            <div className="feature-card">
              <h3>Yeni Hayvan Ekle</h3>
              <div className="form-grid">
                <input
                  type="text"
                  placeholder="Bilezik Numarası"
                  value={newAnimal.ringNumber}
                  onChange={(e) => setNewAnimal({...newAnimal, ringNumber: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="Hayvan Adı"
                  value={newAnimal.name}
                  onChange={(e) => setNewAnimal({...newAnimal, name: e.target.value})}
                />
                <select
                  value={newAnimal.gender}
                  onChange={(e) => setNewAnimal({...newAnimal, gender: e.target.value})}
                >
                  <option value="">Cinsiyet Seçin</option>
                  <option value="ERKEK">Erkek</option>
                  <option value="DİŞİ">Dişi</option>
                </select>
                <input
                  type="text"
                  placeholder="Renk"
                  value={newAnimal.color}
                  onChange={(e) => setNewAnimal({...newAnimal, color: e.target.value})}
                />
                <input
                  type="number"
                  placeholder="Yaş"
                  value={newAnimal.age}
                  onChange={(e) => setNewAnimal({...newAnimal, age: e.target.value})}
                />
                <input
                  type="number"
                  placeholder="Ağırlık (kg)"
                  value={newAnimal.weight}
                  onChange={(e) => setNewAnimal({...newAnimal, weight: e.target.value})}
                />
              </div>
              <textarea
                placeholder="Notlar"
                value={newAnimal.notes}
                onChange={(e) => setNewAnimal({...newAnimal, notes: e.target.value})}
                rows={3}
              />
              <button 
                className="feature-button" 
                onClick={handleAddAnimal}
              >
                Hayvan Ekle
              </button>
            </div>

            <div className="feature-card">
              <h3>Mevcut Hayvanlar</h3>
              <div className="animal-list">
                {animals.map((animal) => (
                  <div key={animal.id} className="animal-item">
                    <div className="animal-info">
                      <span className="animal-ring">{animal.ringNumber}</span>
                      <span className="animal-name">{animal.name}</span>
                      <span className="animal-gender">{animal.gender}</span>
                      <span className="animal-color">{animal.color}</span>
                    </div>
                    <div className="animal-actions">
                      <button className="edit-btn" onClick={() => handleEditAnimal(animal.id)}>Düzenle</button>
                      <button className="delete-btn" onClick={() => handleDeleteAnimal(animal.id)}>Sil</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'pages' && (
          <div className="tab-content">
            <h2>Sayfa Yönetimi</h2>
            
            <div className="feature-card">
              <h3>Yeni Sayfa Ekle</h3>
              <div className="form-grid">
                <input
                  type="text"
                  placeholder="Sayfa Adı"
                  value={newPage.name}
                  onChange={(e) => setNewPage({...newPage, name: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="Başlık"
                  value={newPage.title}
                  onChange={(e) => setNewPage({...newPage, title: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="Yol (/sayfa)"
                  value={newPage.path}
                  onChange={(e) => setNewPage({...newPage, path: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="İkon"
                  value={newPage.icon}
                  onChange={(e) => setNewPage({...newPage, icon: e.target.value})}
                />
                <input
                  type="color"
                  value={newPage.color}
                  onChange={(e) => setNewPage({...newPage, color: e.target.value})}
                />
                <input
                  type="number"
                  placeholder="Sıra"
                  value={newPage.order}
                  onChange={(e) => setNewPage({...newPage, order: parseInt(e.target.value)})}
                />
              </div>
              <textarea
                placeholder="Açıklama"
                value={newPage.description}
                onChange={(e) => setNewPage({...newPage, description: e.target.value})}
                rows={3}
              />
              <div className="checkbox-group">
                <label>
                  <input
                    type="checkbox"
                    checked={newPage.isActive}
                    onChange={(e) => setNewPage({...newPage, isActive: e.target.checked})}
                  />
                  Aktif
                </label>
                <label>
                  <input
                    type="checkbox"
                    checked={newPage.isVisible}
                    onChange={(e) => setNewPage({...newPage, isVisible: e.target.checked})}
                  />
                  Görünür
                </label>
              </div>
              <button 
                className="feature-button" 
                onClick={() => {
                  setNewPage({
                    name: '',
                    title: '',
                    path: '',
                    icon: '',
                    color: '#667eea',
                    shape: 'square',
                    description: '',
                    order: 0,
                    isActive: true,
                    isVisible: true
                  });
                  setEditingPage(null);
                  setShowPageModal(true);
                }}
              >
                Sayfa Ekle
              </button>
            </div>

            <div className="feature-card">
              <h3>Mevcut Sayfalar</h3>
              <div className="page-list">
                {pages.map((page) => (
                  <div key={page.id} className="page-item">
                    <div className="page-info">
                      <span className="page-name">{page.name}</span>
                      <span className="page-title">{page.title}</span>
                      <span className="page-path">{page.path}</span>
                      <span className={`page-status ${page.isActive ? 'active' : 'inactive'}`}>
                        {page.isActive ? 'Aktif' : 'Pasif'}
                      </span>
                    </div>
                    <div className="page-actions">
                      <button className="edit-btn" onClick={() => handleEditPage(page.id)}>Düzenle</button>
                      <button className="permissions-btn" onClick={() => handlePagePermissions(page.id)}>İzinler</button>
                      <button className="delete-btn" onClick={() => handleDeletePage(page.id)}>Sil</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="feature-card">
              <h3>Rol Ataması</h3>
              <div className="role-assignment">
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                >
                  <option value="SUPERADMIN">Süper Admin</option>
                  <option value="FEDERATION">Federasyon</option>
                  <option value="PRESIDENT">Başkan</option>
                  <option value="JUDGE">Hakem</option>
                  <option value="MEMBER">Üye</option>
                </select>
                <button 
                  className="feature-button" 
                  onClick={handleRoleAssignment}
                >
                  Rol Ataması Yap
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'presidents' && (
          <div className="tab-content">
            <h2>Başkan Yönetimi</h2>
            
            <div className="feature-card">
              <h3>Yeni Başkan Ekle</h3>
              <div className="form-grid">
                <input
                  type="text"
                  placeholder="Ad"
                  value={newPresident.firstName}
                  onChange={(e) => setNewPresident({...newPresident, firstName: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="Soyad"
                  value={newPresident.lastName}
                  onChange={(e) => setNewPresident({...newPresident, lastName: e.target.value})}
                />
                <input
                  type="email"
                  placeholder="E-posta"
                  value={newPresident.email}
                  onChange={(e) => setNewPresident({...newPresident, email: e.target.value})}
                />
                <input
                  type="password"
                  placeholder="Şifre"
                  value={newPresident.password}
                  onChange={(e) => setNewPresident({...newPresident, password: e.target.value})}
                />
                <input
                  type="tel"
                  placeholder="Telefon"
                  value={newPresident.phone}
                  onChange={(e) => setNewPresident({...newPresident, phone: e.target.value})}
                />
                <select
                  value={newPresident.associationId}
                  onChange={(e) => setNewPresident({...newPresident, associationId: e.target.value})}
                >
                  <option value="">Dernek Seçin</option>
                  {availableAssociations.map((association) => (
                    <option key={association.id} value={association.id}>
                      {association.name}
                    </option>
                  ))}
                </select>
              </div>
              <button 
                className="feature-button" 
                onClick={handleAddPresident}
              >
                Başkan Ekle
              </button>
            </div>

            <div className="feature-card">
              <h3>Mevcut Başkanlar</h3>
              <div className="president-list">
                {presidents.map((president) => (
                  <div key={president.id} className="president-item">
                    <div className="president-info">
                      <span className="president-name">{president.firstName} {president.lastName}</span>
                      <span className="president-email">{president.email}</span>
                      <span className="president-association">{president.association?.name}</span>
                      <span className={`president-status ${president.isActive ? 'active' : 'inactive'}`}>
                        {president.isActive ? 'Aktif' : 'Pasif'}
                      </span>
                    </div>
                    <div className="president-actions">
                      <button className="edit-btn" onClick={() => handleEditPresident(president.id)}>Düzenle</button>
                      <button className="toggle-btn" onClick={() => handleTogglePresidentStatus(president.id)}>
                        {president.isActive ? 'Pasif Yap' : 'Aktif Yap'}
                      </button>
                      <button className="delete-btn" onClick={() => handleDeletePresident(president.id)}>Sil</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'competitions' && (
          <div className="tab-content">
            <h2>Yarışma Yönetimi</h2>
            
            <div className="feature-card">
              <h3>Yeni Yarışma Oluştur</h3>
              <div className="form-grid">
                <input
                  type="text"
                  placeholder="Yarışma Adı"
                  value={newCompetition.name}
                  onChange={(e) => setNewCompetition({...newCompetition, name: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="Lokasyon"
                  value={newCompetition.location}
                  onChange={(e) => setNewCompetition({...newCompetition, location: e.target.value})}
                />
                <input
                  type="date"
                  value={newCompetition.startDate}
                  onChange={(e) => setNewCompetition({...newCompetition, startDate: e.target.value})}
                />
                <input
                  type="date"
                  value={newCompetition.endDate}
                  onChange={(e) => setNewCompetition({...newCompetition, endDate: e.target.value})}
                />
                <select
                  value={newCompetition.status}
                  onChange={(e) => setNewCompetition({...newCompetition, status: e.target.value})}
                >
                  <option value="PLANNED">Planlandı</option>
                  <option value="OPEN">Açık</option>
                  <option value="ONGOING">Devam Ediyor</option>
                  <option value="CLOSED">Kapalı</option>
                  <option value="COMPLETED">Tamamlandı</option>
                  <option value="CANCELLED">İptal Edildi</option>
                </select>
              </div>
              <textarea
                placeholder="Açıklama"
                value={newCompetition.description}
                onChange={(e) => setNewCompetition({...newCompetition, description: e.target.value})}
                rows={3}
              />
              <button 
                className="feature-button" 
                onClick={handleCreateCompetition}
              >
                Yarışma Oluştur
              </button>
            </div>

            <div className="feature-card">
              <h3>Mevcut Yarışmalar</h3>
              <div className="competition-list">
                {competitions.map((competition) => (
                  <div key={competition.id} className="competition-item">
                    <div className="competition-info">
                      <span className="competition-name">{competition.name}</span>
                      <span className="competition-location">{competition.location}</span>
                      <span className="competition-dates">
                        {competition.startDate} - {competition.endDate}
                      </span>
                      <span className={`competition-status ${competition.status.toLowerCase()}`}>
                        {competition.status}
                      </span>
                      <span className="competition-registrations">
                        {competition.registrationCount || 0} kayıt
                      </span>
                    </div>
                    <div className="competition-actions">
                      <button className="edit-btn" onClick={() => handleEditCompetition(competition.id)}>Düzenle</button>
                      <button className="status-btn" onClick={() => handleCompetitionStatus(competition.id)}>Durum</button>
                      <button className="delete-btn" onClick={() => handleDeleteCompetition(competition.id)}>Sil</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'cages' && (
          <div className="tab-content">
            <h2>Kafes Ataması Sistemi</h2>
            
            {/* Kafes İstatistikleri */}
            <div className="feature-card">
              <h3>Kafes İstatistikleri</h3>
              <div className="statistics-grid">
                <div className="stat-item">
                  <span className="stat-number">{cageStatistics.totalCages}</span>
                  <span className="stat-label">Toplam Kafes</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{cageStatistics.largeCages}</span>
                  <span className="stat-label">Büyük Kafes</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{cageStatistics.mediumCages}</span>
                  <span className="stat-label">Orta Kafes</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{cageStatistics.smallCages}</span>
                  <span className="stat-label">Küçük Kafes</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{cageStatistics.totalAnimals}</span>
                  <span className="stat-label">Toplam Hayvan</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{cageStatistics.assignedAnimals}</span>
                  <span className="stat-label">Atanmış Hayvan</span>
                </div>
              </div>
              <div className="action-buttons">
                <button className="feature-button" onClick={handleAutoAssignCages}>
                  Otomatik Atama
                </button>
                <button className="feature-button" onClick={exportToExcel}>
                  Excel Çıktısı
                </button>
              </div>
            </div>

            {/* Onaylanmış Hayvanlar */}
            <div className="feature-card">
              <h3>Onaylanmış Hayvanlar</h3>
              <div className="animal-list">
                {approvedAnimals.map((animal) => (
                  <div key={animal.id} className="animal-item">
                    <div className="animal-info">
                      <span className="animal-ring">{animal.ringNumber}</span>
                      <span className="animal-name">{animal.name}</span>
                      <span className="animal-type">{animal.type}</span>
                      <span className="animal-breed">{animal.breed}</span>
                      <span className="animal-owner">{animal.owner}</span>
                      <span className="animal-association">{animal.association}</span>
                      <span className={`cage-status ${animal.cage ? 'assigned' : 'unassigned'}`}>
                        {animal.cage ? `Kafes: ${animal.cage}` : 'Atanmamış'}
                      </span>
                    </div>
                    <div className="animal-actions">
                      <button className="edit-btn" onClick={() => handleChangeCage(animal.id)}>Kafes Değiştir</button>
                      <button className="permissions-btn" onClick={() => handleAnimalDetails(animal.id)}>Detaylar</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Kafes Atamaları */}
            <div className="feature-card">
              <h3>Kafes Atamaları</h3>
              <div className="cage-list">
                {cageAssignments.map((cage) => (
                  <div key={cage.id} className="cage-item">
                    <div className="cage-info">
                      <span className="cage-number">{cage.cageNumber}</span>
                      <span className="cage-size">{cage.size} Kafes</span>
                      <span className="cage-capacity">Kapasite: {cage.capacity}</span>
                      <span className="cage-animals">
                        Hayvanlar: {cage.assignedAnimals.length}/{cage.capacity}
                      </span>
                      <span className={`cage-status ${cage.status.toLowerCase()}`}>
                        {cage.status}
                      </span>
                    </div>
                    <div className="cage-actions">
                      <button className="edit-btn" onClick={() => handleEditCage(cage.id)}>Düzenle</button>
                      <button className="status-btn" onClick={() => handleManageAnimals(cage.id)}>Hayvan Yönet</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Kafes Gereksinimleri */}
            <div className="feature-card">
              <h3>Kafes Gereksinimleri</h3>
              <div className="requirements-grid">
                <div className="requirement-item">
                  <h4>Büyük Irk Hayvanlar</h4>
                  <p>Toplam: {approvedAnimals.filter(a => a.type === 'Büyük Irk').length} hayvan</p>
                  <p>Gerekli Kafes: {Math.ceil(approvedAnimals.filter(a => a.type === 'Büyük Irk').length / 4)} adet</p>
                </div>
                <div className="requirement-item">
                  <h4>Orta Irk Hayvanlar</h4>
                  <p>Toplam: {approvedAnimals.filter(a => a.type === 'Orta Irk').length} hayvan</p>
                  <p>Gerekli Kafes: {Math.ceil(approvedAnimals.filter(a => a.type === 'Orta Irk').length / 6)} adet</p>
                </div>
                <div className="requirement-item">
                  <h4>Küçük Irk Hayvanlar</h4>
                  <p>Toplam: {approvedAnimals.filter(a => a.type === 'Küçük Irk').length} hayvan</p>
                  <p>Gerekli Kafes: {Math.ceil(approvedAnimals.filter(a => a.type === 'Küçük Irk').length / 8)} adet</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Page Edit/Add Modal */}
      {showPageModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>{editingPage ? 'Sayfa Düzenle' : 'Yeni Sayfa Ekle'}</h3>
              <button className="close-btn" onClick={() => setShowPageModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Sayfa Adı *</label>
                <input
                  type="text"
                  value={newPage.name}
                  onChange={(e) => setNewPage({...newPage, name: e.target.value})}
                  placeholder="Sayfa adını girin"
                />
              </div>
              <div className="form-group">
                <label>Başlık *</label>
                <input
                  type="text"
                  value={newPage.title}
                  onChange={(e) => setNewPage({...newPage, title: e.target.value})}
                  placeholder="Sayfa başlığını girin"
                />
              </div>
              <div className="form-group">
                <label>Yol *</label>
                <input
                  type="text"
                  value={newPage.path}
                  onChange={(e) => setNewPage({...newPage, path: e.target.value})}
                  placeholder="/sayfa-yolu"
                />
              </div>
              <div className="form-group">
                <label>İkon</label>
                <input
                  type="text"
                  value={newPage.icon}
                  onChange={(e) => setNewPage({...newPage, icon: e.target.value})}
                  placeholder="🏠"
                />
              </div>
              <div className="form-group">
                <label>Renk</label>
                <input
                  type="color"
                  value={newPage.color}
                  onChange={(e) => setNewPage({...newPage, color: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label>Sıra</label>
                <input
                  type="number"
                  value={newPage.order}
                  onChange={(e) => setNewPage({...newPage, order: parseInt(e.target.value) || 0})}
                />
              </div>
              <div className="form-group">
                <label>Açıklama</label>
                <textarea
                  value={newPage.description}
                  onChange={(e) => setNewPage({...newPage, description: e.target.value})}
                  placeholder="Sayfa açıklaması"
                  rows={3}
                />
              </div>
              <div className="checkbox-group">
                <label>
                  <input
                    type="checkbox"
                    checked={newPage.isActive}
                    onChange={(e) => setNewPage({...newPage, isActive: e.target.checked})}
                  />
                  Aktif
                </label>
                <label>
                  <input
                    type="checkbox"
                    checked={newPage.isVisible}
                    onChange={(e) => setNewPage({...newPage, isVisible: e.target.checked})}
                  />
                  Görünür
                </label>
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowPageModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={handleSavePage}>
                {editingPage ? 'Güncelle' : 'Kaydet'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Page Permissions Modal */}
      {showPermissionsModal && selectedPage && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Sayfa İzinleri: {selectedPage.title}</h3>
              <button className="close-btn" onClick={() => setShowPermissionsModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="page-info">
                <h4>{selectedPage.title}</h4>
                <p><strong>Yol:</strong> {selectedPage.path}</p>
                <p><strong>Durum:</strong> {selectedPage.isActive ? 'Aktif' : 'Pasif'}</p>
              </div>
              <div className="permissions-grid">
                {['SUPERADMIN', 'FEDERATION', 'PRESIDENT', 'JUDGE', 'MEMBER'].map(role => (
                  <div key={role} className="permission-item">
                    <label className="permission-label">
                      <input
                        type="checkbox"
                        defaultChecked={role === 'SUPERADMIN' || role === 'FEDERATION'}
                        onChange={(e) => console.log(`${role} permission changed:`, e.target.checked)}
                      />
                      <span>{role}</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowPermissionsModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={() => handleSavePermissions(selectedPage.id, {})}>
                Kaydet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Role Assignment Modal */}
      {showRoleAssignmentModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Rol Ataması</h3>
              <button className="close-btn" onClick={() => setShowRoleAssignmentModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Rol Seçin</label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                >
                  <option value="SUPERADMIN">Süper Admin</option>
                  <option value="FEDERATION">Federasyon</option>
                  <option value="PRESIDENT">Başkan</option>
                  <option value="JUDGE">Hakem</option>
                  <option value="MEMBER">Üye</option>
                </select>
              </div>
              <div className="form-group">
                <label>Sayfalar Seçin</label>
                <div className="page-selection">
                  {pages.map(page => (
                    <label key={page.id} className="checkbox-item">
                      <input
                        type="checkbox"
                        defaultChecked={page.id === '1' || page.id === '2'} // Default pages for all roles
                        onChange={(e) => console.log(`${page.name} selected for ${selectedRole}:`, e.target.checked)}
                      />
                      <span>{page.title} ({page.path})</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="cancel-btn" onClick={() => setShowRoleAssignmentModal(false)}>
                İptal
              </button>
              <button className="save-btn" onClick={() => handleSaveRoleAssignment(selectedRole, [])}>
                Atama Yap
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPage;
