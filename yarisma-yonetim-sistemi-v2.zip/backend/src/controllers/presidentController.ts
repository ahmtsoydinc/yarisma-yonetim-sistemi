import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';
import bcrypt from 'bcryptjs';

export const getPresidents = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, isActive, associationId } = req.query;
    
    const where: any = {
      role: 'PRESIDENT'
    };
    
    if (isActive !== undefined) where.isActive = isActive === 'true';
    if (associationId) where.associationId = associationId;

    const presidents = await prisma.user.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
        association: {
          select: {
            id: true,
            name: true,
            code: true,
            federation: {
              select: {
                id: true,
                name: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const total = await prisma.user.count({ where });

    res.json({
      presidents,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getPresidentById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const president = await prisma.user.findFirst({
      where: { 
        id,
        role: 'PRESIDENT'
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
        association: {
          select: {
            id: true,
            name: true,
            code: true,
            description: true,
            federation: {
              select: {
                id: true,
                name: true
              }
            }
          }
        }
      }
    });

    if (!president) {
      throw createError('Başkan bulunamadı', 404);
    }

    res.json({ president });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createPresident = async (req: Request, res: Response) => {
  try {
    const { 
      email, 
      password, 
      firstName, 
      lastName, 
      phone, 
      associationId,
      isActive = true 
    } = req.body;

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      throw createError('Bu e-posta adresi ile zaten bir kullanıcı mevcut', 400);
    }

    // Check if association exists
    const association = await prisma.association.findUnique({
      where: { id: associationId }
    });

    if (!association) {
      throw createError('Geçersiz dernek ID', 400);
    }

    // Check if association already has a president
    const existingPresident = await prisma.user.findFirst({
      where: {
        associationId,
        role: 'PRESIDENT',
        isActive: true
      }
    });

    if (existingPresident) {
      throw createError('Bu derneğin zaten aktif bir başkanı var', 400);
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create president
    const president = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        firstName,
        lastName,
        role: 'PRESIDENT',
        phone,
        associationId,
        isActive
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        isActive: true,
        createdAt: true,
        association: {
          select: {
            id: true,
            name: true,
            code: true
          }
        }
      }
    });

    // Update association president
    await prisma.association.update({
      where: { id: associationId },
      data: { presidentId: president.id }
    });

    res.status(201).json({
      message: 'Başkan başarıyla oluşturuldu',
      president
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updatePresident = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { 
      firstName, 
      lastName, 
      phone, 
      associationId,
      isActive 
    } = req.body;

    // Check if president exists
    const existingPresident = await prisma.user.findFirst({
      where: {
        id,
        role: 'PRESIDENT'
      }
    });

    if (!existingPresident) {
      throw createError('Başkan bulunamadı', 404);
    }

    // If changing association, check if new association already has a president
    if (associationId && associationId !== existingPresident.associationId) {
      const association = await prisma.association.findUnique({
        where: { id: associationId }
      });

      if (!association) {
        throw createError('Geçersiz dernek ID', 400);
      }

      const existingPresidentInNewAssociation = await prisma.user.findFirst({
        where: {
          associationId,
          role: 'PRESIDENT',
          isActive: true,
          id: { not: id }
        }
      });

      if (existingPresidentInNewAssociation) {
        throw createError('Bu derneğin zaten aktif bir başkanı var', 400);
      }

      // Update old association (remove president)
      await prisma.association.update({
        where: { id: existingPresident.associationId! },
        data: { presidentId: null }
      });

      // Update new association (set president)
      await prisma.association.update({
        where: { id: associationId },
        data: { presidentId: id }
      });
    }

    // Update president
    const president = await prisma.user.update({
      where: { id },
      data: {
        firstName,
        lastName,
        phone,
        associationId,
        isActive
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        isActive: true,
        updatedAt: true,
        association: {
          select: {
            id: true,
            name: true,
            code: true
          }
        }
      }
    });

    res.json({
      message: 'Başkan başarıyla güncellendi',
      president
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deletePresident = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Check if president exists
    const existingPresident = await prisma.user.findFirst({
      where: {
        id,
        role: 'PRESIDENT'
      }
    });

    if (!existingPresident) {
      throw createError('Başkan bulunamadı', 404);
    }

    // Remove president from association
    if (existingPresident.associationId) {
      await prisma.association.update({
        where: { id: existingPresident.associationId },
        data: { presidentId: null }
      });
    }

    // Delete president
    await prisma.user.delete({
      where: { id }
    });

    res.json({ message: 'Başkan başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const togglePresidentStatus = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const president = await prisma.user.findFirst({
      where: {
        id,
        role: 'PRESIDENT'
      }
    });

    if (!president) {
      throw createError('Başkan bulunamadı', 404);
    }

    const updatedPresident = await prisma.user.update({
      where: { id },
      data: {
        isActive: !president.isActive
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        isActive: true,
        updatedAt: true
      }
    });

    // If deactivating, remove from association
    if (!updatedPresident.isActive && president.associationId) {
      await prisma.association.update({
        where: { id: president.associationId },
        data: { presidentId: null }
      });
    }

    res.json({
      message: `Başkan ${updatedPresident.isActive ? 'aktifleştirildi' : 'pasifleştirildi'}`,
      president: updatedPresident
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getAvailableAssociations = async (req: Request, res: Response) => {
  try {
    const associations = await prisma.association.findMany({
      where: {
        president: null, // Associations without presidents
        isActive: true
      },
      select: {
        id: true,
        name: true,
        code: true,
        federation: {
          select: {
            id: true,
            name: true
          }
        }
      },
      orderBy: { name: 'asc' }
    });

    res.json({ associations });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};
