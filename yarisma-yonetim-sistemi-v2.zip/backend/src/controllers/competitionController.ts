import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { createError } from '../middleware/errorHandler';

export const getCompetitions = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, status, federationId } = req.query;
    
    const where: any = {};
    
    if (status) where.status = status;
    if (federationId) where.federationId = federationId;

    const competitions = await prisma.competition.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        federation: {
          select: {
            id: true,
            name: true
          }
        },
        _count: {
          select: {
            registrations: true,
          }
        }
      },
      orderBy: { startDate: 'desc' }
    });

    const total = await prisma.competition.count({ where });

    res.json({
      competitions,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getCompetitionById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const competition = await prisma.competition.findUnique({
      where: { id },
      include: {
        federation: {
          select: {
            id: true,
            name: true
          }
        },
        registrations: {
          select: {
            id: true,
            animalId: true,
            registrationDate: true,
            status: true,
            notes: true
          }
        },
        cages: {
          include: {
            animalType: true,
            registrations: {
              include: {
                animal: {
                  include: {
                    animalType: true,
                    owner: {
                      select: {
                        firstName: true,
                        lastName: true
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    });

    if (!competition) {
      throw createError('Yarışma bulunamadı', 404);
    }

    res.json({ competition });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const createCompetition = async (req: Request, res: Response) => {
  try {
    const { 
      name, 
      description, 
      location, 
      startDate, 
      endDate, 
      maxAnimals,
      federationId,
      status = 'PLANNED'
    } = req.body;

    // Check if federation exists
    const federation = await prisma.federation.findUnique({
      where: { id: federationId }
    });

    if (!federation) {
      throw createError('Geçersiz federasyon ID', 400);
    }

    // Validate dates
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (start >= end) {
      throw createError('Bitiş tarihi başlangıç tarihinden sonra olmalıdır', 400);
    }

    if (start < new Date()) {
      throw createError('Başlangıç tarihi geçmişte olamaz', 400);
    }

    // Create competition
    const competition = await prisma.competition.create({
      data: {
        name,
        description,
        location,
        startDate: start,
        endDate: end,
        maxAnimals: maxAnimals || 100,
        status,
        federationId
      },
      include: {
        federation: {
          select: {
            id: true,
            name: true
          }
        }
      }
    });

    res.status(201).json({
      message: 'Yarışma başarıyla oluşturuldu',
      competition
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateCompetition = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { 
      name, 
      description, 
      location, 
      startDate, 
      endDate, 
      maxAnimals,
      status 
    } = req.body;

    // Check if competition exists
    const existingCompetition = await prisma.competition.findUnique({
      where: { id }
    });

    if (!existingCompetition) {
      throw createError('Yarışma bulunamadı', 404);
    }

    // Validate dates if provided
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      if (start >= end) {
        throw createError('Bitiş tarihi başlangıç tarihinden sonra olmalıdır', 400);
      }
    }

    // Update competition
    const competition = await prisma.competition.update({
      where: { id },
      data: {
        name,
        description,
        location,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
        maxAnimals,
        status
      },
      include: {
        federation: {
          select: {
            id: true,
            name: true
          }
        }
      }
    });

    res.json({
      message: 'Yarışma başarıyla güncellendi',
      competition
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const deleteCompetition = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Check if competition exists
    const existingCompetition = await prisma.competition.findUnique({
      where: { id }
    });

    if (!existingCompetition) {
      throw createError('Yarışma bulunamadı', 404);
    }

    // Check if competition has registrations
    const registrationsCount = await prisma.competitionRegistration.count({
      where: { competitionId: id }
    });

    if (registrationsCount > 0) {
      throw createError('Kayıtlı hayvanları olan yarışma silinemez', 400);
    }

    // Delete competition (cages will be deleted automatically due to cascade)
    await prisma.competition.delete({
      where: { id }
    });

    res.json({ message: 'Yarışma başarıyla silindi' });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const updateCompetitionStatus = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['PLANNED', 'OPEN', 'CLOSED', 'ONGOING', 'COMPLETED', 'CANCELLED'];
    
    if (!validStatuses.includes(status)) {
      throw createError('Geçersiz durum', 400);
    }

    const competition = await prisma.competition.findUnique({
      where: { id }
    });

    if (!competition) {
      throw createError('Yarışma bulunamadı', 404);
    }

    const updatedCompetition = await prisma.competition.update({
      where: { id },
      data: { status },
      include: {
        federation: {
          select: {
            id: true,
            name: true
          }
        }
      }
    });

    res.json({
      message: `Yarışma durumu ${status} olarak güncellendi`,
      competition: updatedCompetition
    });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getCompetitionStats = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const competition = await prisma.competition.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            registrations: true,
          }
        }
      }
    });

    if (!competition) {
      throw createError('Yarışma bulunamadı', 404);
    }

    // Get animal type distribution
    const animalTypeStats = await prisma.competitionRegistration.groupBy({
      by: ['animalId'],
      where: { competitionId: id },
      _count: {
        animalId: true
      }
    });

    // Get association participation
    const associationStats = await prisma.competitionRegistration.groupBy({
      by: ['animalId'],
      where: { competitionId: id },
      _count: {
        animalId: true
      }
    });

    const stats = {
      totalRegistrations: competition._count?.registrations || 0,
      totalCages: 0, // cages field removed from schema
      maxAnimals: competition.maxAnimals,
      remainingCapacity: competition.maxAnimals - (competition._count?.registrations || 0),
      animalTypeDistribution: animalTypeStats.length,
      associationParticipation: associationStats.length
    };

    res.json({ stats });
  } catch (error: any) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
};

export const getAvailableFederations = async (req: Request, res: Response) => {
  try {
    const federations = await prisma.federation.findMany({
      where: { isActive: true },
      select: {
        id: true,
        name: true
      },
      orderBy: { name: 'asc' }
    });

    res.json({ federations });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};