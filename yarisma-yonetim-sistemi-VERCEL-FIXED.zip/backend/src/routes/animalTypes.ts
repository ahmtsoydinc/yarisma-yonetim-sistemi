import { Router } from 'express';
import { body } from 'express-validator';
import { 
  getAnimalTypes, 
  getAnimalTypeById, 
  createAnimalType, 
  updateAnimalType, 
  deleteAnimalType,
  getAnimalColors,
  createAnimalColor,
  updateAnimalColor,
  deleteAnimalColor
} from '../controllers/animalTypeController';
import { authenticateToken, requireSuperAdmin } from '../middleware/auth';
import { validateRequest } from '../middleware/validateRequest';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Validation rules
const createAnimalTypeValidation = [
  body('name').notEmpty().withMessage('Hayvan türü adı zorunludur'),
  body('breed').notEmpty().withMessage('Hayvan cinsi zorunludur'),
  body('description').optional().trim()
];

const createAnimalColorValidation = [
  body('name').notEmpty().withMessage('Renk adı zorunludur'),
  body('animalTypeId').isUUID().withMessage('Geçerli bir hayvan türü ID giriniz'),
  body('code').optional().trim(),
  body('description').optional().trim()
];

// Public routes (authenticated users can view)
router.get('/types', getAnimalTypes);
router.get('/types/:id', getAnimalTypeById);
router.get('/colors', getAnimalColors);

// Admin only routes
router.post('/types', createAnimalTypeValidation, validateRequest, requireSuperAdmin, createAnimalType);
router.put('/types/:id', createAnimalTypeValidation, validateRequest, requireSuperAdmin, updateAnimalType);
router.delete('/types/:id', requireSuperAdmin, deleteAnimalType);

router.post('/colors', createAnimalColorValidation, validateRequest, requireSuperAdmin, createAnimalColor);
router.put('/colors/:id', createAnimalColorValidation, validateRequest, requireSuperAdmin, updateAnimalColor);
router.delete('/colors/:id', requireSuperAdmin, deleteAnimalColor);

module.exports = router;
