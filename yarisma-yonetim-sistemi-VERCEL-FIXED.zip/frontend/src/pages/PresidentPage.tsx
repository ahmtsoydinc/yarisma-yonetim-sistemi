import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const PresidentPage: React.FC = () => {
  const { user: _user } = useAuth();
  const [activeTab, setActiveTab] = useState('members');
  
  // Mock data for members
  const [members, setMembers] = useState([
    {
      id: '1',
      name: 'Ahmet Yılmaz',
      email: 'ahmet@example.com',
      phone: '0532 123 45 67',
      registrationDate: '2024-01-15',
      status: 'pending',
      animalsCount: 3
    },
    {
      id: '2',
      name: 'Fatma Demir',
      email: 'fatma@example.com',
      phone: '0533 987 65 43',
      registrationDate: '2024-01-20',
      status: 'approved',
      animalsCount: 5
    },
    {
      id: '3',
      name: 'Mehmet Kaya',
      email: 'mehmet@example.com',
      phone: '0534 555 44 33',
      registrationDate: '2024-02-01',
      status: 'pending',
      animalsCount: 2
    }
  ]);

  // Mock data for animals
  const [animals, setAnimals] = useState([
    {
      id: '1',
      ringNumber: 'IST-2024-001',
      name: 'Sultan',
      type: 'Büyük Irk',
      color: 'Beyaz',
      owner: 'Ahmet Yılmaz',
      status: 'pending',
      registrationDate: '2024-01-15'
    },
    {
      id: '2',
      ringNumber: 'IST-2024-002',
      name: 'Altın',
      type: 'Orta Irk',
      color: 'Sarı',
      owner: 'Fatma Demir',
      status: 'approved',
      registrationDate: '2024-01-20'
    },
    {
      id: '3',
      ringNumber: 'IST-2024-003',
      name: 'Gümüş',
      type: 'Küçük Irk',
      color: 'Gri',
      owner: 'Mehmet Kaya',
      status: 'pending',
      registrationDate: '2024-02-01'
    }
  ]);

  // Mock data for ring orders
  const [ringOrders, setRingOrders] = useState([
    {
      id: '1',
      orderNumber: 'RO-2024-001',
      memberName: 'Ahmet Yılmaz',
      quantity: 10,
      status: 'ordered',
      orderDate: '2024-01-15',
      expectedDelivery: '2024-02-15'
    },
    {
      id: '2',
      orderNumber: 'RO-2024-002',
      memberName: 'Fatma Demir',
      quantity: 15,
      status: 'delivered',
      orderDate: '2024-01-10',
      expectedDelivery: '2024-02-10'
    }
  ]);

  // Modal states
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [newMember, setNewMember] = useState({
    name: '',
    email: '',
    phone: '',
    password: ''
  });

  // Member management functions
  const handleApproveMember = (id: string) => {
    setMembers(members.map(member => 
      member.id === id ? { ...member, status: 'approved' } : member
    ));
    alert('Üye başarıyla onaylandı!');
  };

  const handleRejectMember = (id: string) => {
    if (window.confirm('Bu üyeyi reddetmek istediğinizden emin misiniz?')) {
      setMembers(members.filter(member => member.id !== id));
      alert('Üye reddedildi!');
    }
  };

  const handleAddMember = () => {
    if (!newMember.name || !newMember.email || !newMember.phone || !newMember.password) {
      alert('Lütfen tüm alanları doldurun!');
      return;
    }

    // Email format kontrolü
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newMember.email)) {
      alert('Lütfen geçerli bir e-posta adresi girin!');
      return;
    }

    // Telefon format kontrolü (en az 10 karakter)
    if (newMember.phone.length < 10) {
      alert('Lütfen geçerli bir telefon numarası girin!');
      return;
    }

    // Şifre kontrolü (en az 6 karakter)
    if (newMember.password.length < 6) {
      alert('Şifre en az 6 karakter olmalıdır!');
      return;
    }

    const member = {
      id: Date.now().toString(),
      name: newMember.name,
      email: newMember.email,
      phone: newMember.phone,
      registrationDate: new Date().toISOString().split('T')[0],
      status: 'approved', // Başkan tarafından eklenen üyeler otomatik onaylanır
      animalsCount: 0
    };

    setMembers([...members, member]);
    setNewMember({ name: '', email: '', phone: '', password: '' });
    setShowAddMemberModal(false);
    alert(`Yeni üye başarıyla eklendi: ${member.name} (${member.email})`);
  };

  // Animal management functions
  const handleApproveAnimal = (id: string) => {
    setAnimals(animals.map(animal => 
      animal.id === id ? { ...animal, status: 'approved' } : animal
    ));
    alert('Hayvan başarıyla onaylandı!');
  };

  const handleRejectAnimal = (id: string) => {
    if (window.confirm('Bu hayvanı reddetmek istediğinizden emin misiniz?')) {
      setAnimals(animals.filter(animal => animal.id !== id));
      alert('Hayvan reddedildi!');
    }
  };

  // Ring order functions
  const handleCreateRingOrder = () => {
    alert('Yeni bilezik siparişi oluşturma formu açılacak!');
  };

  const handleUpdateOrderStatus = (id: string, status: string) => {
    setRingOrders(ringOrders.map(order => 
      order.id === id ? { ...order, status } : order
    ));
    alert(`Sipariş durumu ${status} olarak güncellendi!`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return '#10b981';
      case 'pending': return '#f59e0b';
      case 'rejected': return '#ef4444';
      case 'ordered': return '#3b82f6';
      case 'delivered': return '#10b981';
      case 'cancelled': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved': return 'Onaylandı';
      case 'pending': return 'Beklemede';
      case 'rejected': return 'Reddedildi';
      case 'ordered': return 'Sipariş Edildi';
      case 'delivered': return 'Teslim Edildi';
      case 'cancelled': return 'İptal Edildi';
      default: return status;
    }
  };

  return (
    <div className="president-page">
      <div className="page-header">
        <h1>Başkan Yönetim Paneli</h1>
        <p>İstanbul Süs Tavukları Derneği Yönetim İşlemleri</p>
      </div>

      <div className="admin-tabs">
        <button 
          className={`tab-button ${activeTab === 'members' ? 'active' : ''}`}
          onClick={() => setActiveTab('members')}
        >
          Üye Yönetimi
        </button>
        <button 
          className={`tab-button ${activeTab === 'animals' ? 'active' : ''}`}
          onClick={() => setActiveTab('animals')}
        >
          Hayvan Onayları
        </button>
        <button 
          className={`tab-button ${activeTab === 'rings' ? 'active' : ''}`}
          onClick={() => setActiveTab('rings')}
        >
          Bilezik Siparişleri
        </button>
      </div>

      <div className="admin-content">
        {/* Members Tab */}
        {activeTab === 'members' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Üye Yönetimi</h2>
              <div className="header-actions">
                <div className="stats">
                  <span className="stat-item">
                    <strong>Toplam Üye:</strong> {members.length}
                  </span>
                  <span className="stat-item">
                    <strong>Onay Bekleyen:</strong> {members.filter(m => m.status === 'pending').length}
                  </span>
                  <span className="stat-item">
                    <strong>Onaylanan:</strong> {members.filter(m => m.status === 'approved').length}
                  </span>
                </div>
                <button 
                  className="add-button"
                  onClick={() => setShowAddMemberModal(true)}
                >
                  + Yeni Üye Ekle
                </button>
              </div>
            </div>

            <div className="members-list">
              {members.map(member => (
                <div key={member.id} className="member-item">
                  <div className="member-info">
                    <h3>{member.name}</h3>
                    <p><strong>E-posta:</strong> {member.email}</p>
                    <p><strong>Telefon:</strong> {member.phone}</p>
                    <p><strong>Kayıt Tarihi:</strong> {new Date(member.registrationDate).toLocaleDateString('tr-TR')}</p>
                    <p><strong>Hayvan Sayısı:</strong> {member.animalsCount}</p>
                  </div>
                  <div className="member-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(member.status) }}
                    >
                      {getStatusText(member.status)}
                    </span>
                    <div className="action-buttons">
                      {member.status === 'pending' && (
                        <>
                          <button 
                            className="approve-btn"
                            onClick={() => handleApproveMember(member.id)}
                          >
                            Onayla
                          </button>
                          <button 
                            className="reject-btn"
                            onClick={() => handleRejectMember(member.id)}
                          >
                            Reddet
                          </button>
                        </>
                      )}
                      <button className="edit-btn">
                        Düzenle
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Animals Tab */}
        {activeTab === 'animals' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Hayvan Onayları</h2>
              <div className="stats">
                <span className="stat-item">
                  <strong>Toplam Hayvan:</strong> {animals.length}
                </span>
                <span className="stat-item">
                  <strong>Onay Bekleyen:</strong> {animals.filter(a => a.status === 'pending').length}
                </span>
                <span className="stat-item">
                  <strong>Onaylanan:</strong> {animals.filter(a => a.status === 'approved').length}
                </span>
              </div>
            </div>

            <div className="animals-list">
              {animals.map(animal => (
                <div key={animal.id} className="animal-item">
                  <div className="animal-info">
                    <h3>{animal.name} ({animal.ringNumber})</h3>
                    <p><strong>Tür:</strong> {animal.type}</p>
                    <p><strong>Renk:</strong> {animal.color}</p>
                    <p><strong>Sahibi:</strong> {animal.owner}</p>
                    <p><strong>Kayıt Tarihi:</strong> {new Date(animal.registrationDate).toLocaleDateString('tr-TR')}</p>
                  </div>
                  <div className="animal-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(animal.status) }}
                    >
                      {getStatusText(animal.status)}
                    </span>
                    <div className="action-buttons">
                      {animal.status === 'pending' && (
                        <>
                          <button 
                            className="approve-btn"
                            onClick={() => handleApproveAnimal(animal.id)}
                          >
                            Onayla
                          </button>
                          <button 
                            className="reject-btn"
                            onClick={() => handleRejectAnimal(animal.id)}
                          >
                            Reddet
                          </button>
                        </>
                      )}
                      <button className="edit-btn">
                        Detaylar
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Ring Orders Tab */}
        {activeTab === 'rings' && (
          <div className="tab-content">
            <div className="section-header">
              <h2>Bilezik Siparişleri</h2>
              <button className="add-button" onClick={handleCreateRingOrder}>
                + Yeni Sipariş Oluştur
              </button>
            </div>

            <div className="rings-list">
              {ringOrders.map(order => (
                <div key={order.id} className="ring-item">
                  <div className="ring-info">
                    <h3>{order.orderNumber}</h3>
                    <p><strong>Üye:</strong> {order.memberName}</p>
                    <p><strong>Miktar:</strong> {order.quantity} adet</p>
                    <p><strong>Sipariş Tarihi:</strong> {new Date(order.orderDate).toLocaleDateString('tr-TR')}</p>
                    <p><strong>Teslim Tarihi:</strong> {new Date(order.expectedDelivery).toLocaleDateString('tr-TR')}</p>
                  </div>
                  <div className="ring-actions">
                    <span 
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(order.status) }}
                    >
                      {getStatusText(order.status)}
                    </span>
                    <div className="action-buttons">
                      <button className="edit-btn">
                        Düzenle
                      </button>
                      {order.status === 'ordered' && (
                        <button 
                          className="deliver-btn"
                          onClick={() => handleUpdateOrderStatus(order.id, 'delivered')}
                        >
                          Teslim Et
                        </button>
                      )}
                      <button className="delete-btn">
                        İptal Et
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Add Member Modal */}
      {showAddMemberModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Yeni Üye Ekle</h3>
              <button 
                className="modal-close"
                onClick={() => setShowAddMemberModal(false)}
              >
                ×
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Ad Soyad *</label>
                <input
                  type="text"
                  value={newMember.name}
                  onChange={(e) => setNewMember({...newMember, name: e.target.value})}
                  placeholder="Üye adını girin"
                  required
                />
              </div>
              <div className="form-group">
                <label>E-posta *</label>
                <input
                  type="email"
                  value={newMember.email}
                  onChange={(e) => setNewMember({...newMember, email: e.target.value})}
                  placeholder="ornek@email.com"
                  required
                />
              </div>
              <div className="form-group">
                <label>Telefon *</label>
                <input
                  type="tel"
                  value={newMember.phone}
                  onChange={(e) => setNewMember({...newMember, phone: e.target.value})}
                  placeholder="0532 123 45 67"
                  required
                />
              </div>
              <div className="form-group">
                <label>Şifre *</label>
                <input
                  type="password"
                  value={newMember.password}
                  onChange={(e) => setNewMember({...newMember, password: e.target.value})}
                  placeholder="En az 6 karakter"
                  minLength={6}
                  required
                />
              </div>
              <div className="form-info">
                <p><strong>Not:</strong> Başkan tarafından eklenen üyeler otomatik olarak onaylanır ve sisteme giriş yapabilir.</p>
              </div>
            </div>
            <div className="modal-footer">
              <button 
                className="cancel-btn"
                onClick={() => setShowAddMemberModal(false)}
              >
                İptal
              </button>
              <button 
                className="save-btn"
                onClick={handleAddMember}
              >
                Üye Ekle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PresidentPage;
