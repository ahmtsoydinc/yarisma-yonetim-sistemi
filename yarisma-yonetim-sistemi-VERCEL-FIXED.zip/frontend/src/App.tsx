import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import DataUpload from './pages/DataUpload';
import AnimalRegistration from './pages/AnimalRegistration';
import AnimalList from './pages/AnimalList';
import FederationPage from './pages/FederationPage';
import PresidentPage from './pages/PresidentPage';
import JudgePage from './pages/JudgePage';
import MemberPage from './pages/MemberPage';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#363636',
                color: '#fff',
              },
              success: {
                duration: 3000,
                style: {
                  background: '#10B981',
                },
              },
              error: {
                duration: 5000,
                style: {
                  background: '#EF4444',
                },
              },
            }}
          />
                  <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route
                      path="/dashboard"
                      element={
                        <ProtectedRoute>
                          <Layout>
                            <Dashboard />
                          </Layout>
                        </ProtectedRoute>
                      }
                    />
                            <Route
                              path="/data-upload"
                              element={
                                <ProtectedRoute>
                                  <Layout>
                                    <DataUpload />
                                  </Layout>
                                </ProtectedRoute>
                              }
                            />
                            <Route
                              path="/animal-registration"
                              element={
                                <ProtectedRoute>
                                  <Layout>
                                    <AnimalRegistration />
                                  </Layout>
                                </ProtectedRoute>
                              }
                            />
                            <Route
                              path="/animals"
                              element={
                                <ProtectedRoute>
                                  <Layout>
                                    <AnimalList />
                                  </Layout>
                                </ProtectedRoute>
                              }
                            />
                            <Route
                              path="/federation"
                              element={
                                <ProtectedRoute>
                                  <Layout>
                                    <FederationPage />
                                  </Layout>
                                </ProtectedRoute>
                              }
                            />
                            <Route
                              path="/president"
                              element={
                                <ProtectedRoute>
                                  <Layout>
                                    <PresidentPage />
                                  </Layout>
                                </ProtectedRoute>
                              }
                            />
                            <Route
                              path="/judge"
                              element={
                                <ProtectedRoute>
                                  <Layout>
                                    <JudgePage />
                                  </Layout>
                                </ProtectedRoute>
                              }
                            />
                            <Route
                              path="/member"
                              element={
                                <ProtectedRoute>
                                  <Layout>
                                    <MemberPage />
                                  </Layout>
                                </ProtectedRoute>
                              }
                            />
                            <Route path="/" element={<Navigate to="/dashboard" replace />} />
                            <Route path="*" element={<Navigate to="/dashboard" replace />} />
                  </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
